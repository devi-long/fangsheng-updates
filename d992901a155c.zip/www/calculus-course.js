import { saveTask } from './tasks.js';

const titles = [
  "函数极限与连续",
  "数列极限",
  "一元函数微分学的概念",
  "一元函数微分学的计算",
  "一元函数微分学的应用（一）",
  "一元函数微分学的应用（二）",
  "一元函数微分学的应用（三）",
  "一元函数积分学的概念与性质",
  "一元函数积分学的计算",
  "一元函数积分学的应用（一）",
  "一元函数积分学的应用（二）",
  "一元函数积分学的应用（三）",
  "多元函数微分学",
  "二重积分",
  "微分方程",
  "无穷级数",
  "多元函数积分学的预备知识（仅数学一）",
  "多元函数积分学（仅数学一）"
];
const actions = [
  '听课｜跟着本讲视频学习，标出没听懂的地方。',
  '手推例题和课后题｜合上答案手推例题，再独立做课后题。',
  '复习错题和整理笔记公式｜重做错题，整理本讲笔记、公式和适用条件。'
].join('\n');

export function addCalculusLectures(state, now) {
  if (!state.goals.some(goal => goal[0] === 'g1')) throw new Error('请先确认考研目标，再添加高数卡片');
  const existing = new Set(state.tasks.map(task => task.id));
  if (titles.every((_, i) => existing.has(lectureId(i)))) return state;
  const skillId = 'calculus-basic';
  let next = state.skills.some(skill => skill[0] === skillId) ? state : {
    ...state, skills: [...state.skills, [skillId, '高数：基础18讲', '数学']]
  };
  for (const [i, title] of titles.entries()) {
    const id = lectureId(i);
    if (existing.has(id)) continue;
    next = saveTask(next, {
      title: `第 ${i + 1} 讲 · ${title}`,
      goalIds: ['g1'], skillId, minutes: 1,
      resource: '张宇 · 高数基础18讲', position: '从本讲起点开始，继续时按学习记录接续',
      action: actions, stopCondition: '完成本讲三项'
    }, id, now);
    next.tasks[next.tasks.length - 1].courseCard = true;
  }
  return next;
}

function lectureId(index) {
  return 'calculus-basic-' + String(index + 1).padStart(2, '0');
}

export function currentCourseCard(tasks) {
  return tasks.find(task => task.courseCard === true &&
    ['planned', 'in_progress', 'blocked'].includes(task.status));
}

export function visibleCourseTasks(tasks, selected) {
  const current = currentCourseCard(tasks);
  return selected.filter(task => task.courseCard !== true || task.id === current?.id ||
    ['done', 'cancelled', 'skipped'].includes(task.status));
}
