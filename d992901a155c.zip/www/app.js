import { dailyQueuePlan, reviewBudgetForDay, scheduleReview, dailyCapacity, dueReviews, isActiveReview } from './planner.js';
import { createEvidenceFromSession, evidenceForSkill } from './evidence.js';
import { recordReview, rescheduleReview, todayKey } from './review.js';
import { saveTask, saveQuickTask, taskBindings, hasTaskHistory, needsTaskReview, archiveTask, selectTasks } from './tasks.js';
import { buildTrialReport } from './trial.js';
import { createBackup, parseBackup, stateForRestore, serializeBackup } from './backup.js';
import { goalSettings, saveGoalSettings, createGoal } from './goals.js';
import { handoffForSkill, saveHandoff, handoffTaskInput } from './handoffs.js';
import { openRepository } from './repository.js';
import { createInitialState } from './initial-state.js';
import { startOfflineSupport } from './offline.js';
import { fingerprintState, formatBytes, compareBackup, getStorageHealth } from './data-health.js';
import { MAX_BACKUP_BYTES } from './limits.js';
import { createDraftController } from './draft-controller.js';
import { correctionFields, CORRECTION_FIELD_LABELS } from './correction-input.js';
import { applySessionCorrection, correctionsForSession } from './corrections.js';
import { evidenceLevelLabel, normalizeEvidenceLevel } from './evidence-levels.js';
import { SOURCE_TYPES, saveSource, sourceLabel, validateSourceReferences } from './sources.js';
import { createSubjectIndex } from './subjects.js';
import { addCalculusLectures, currentCourseCard, visibleCourseTasks } from './calculus-course.js';
const KEY='study-app-v1';
const seed = createInitialState();
let state;
let persistedRaw = null;
let repository = null;
let restoreLegacyRaw = null;
let view = location.hash.slice(1) || 'home';
let saving = false;
let appReady = false;
let taskFilter = 'active';
let lifecycleTarget = null;
let healthRequest = 0;
let draftSupport = null;
let resumingDraft = false;

async function loadState() {
  const saved = await repository.read();
  persistedRaw = saved.raw;
  const loaded = persistedRaw === null ? structuredClone(seed) : JSON.parse(persistedRaw);
  if (!loaded || !['goals', 'skills', 'tasks', 'reviews', 'sessions'].every(key => Array.isArray(loaded[key]))) {
    throw new Error('本地记录格式异常，已保留原始数据，请导出后检查');
  }
  loaded.evidence ??= [];
  loaded.corrections ??= [];
  if (!Array.isArray(loaded.evidence)) throw new Error('证据数据格式异常');
  validateSourceReferences(loaded);
  loaded.sources ??= [];
  dailyCapacity(loaded, today(), capacityForToday(loaded));
  reviewBudgetForDay(loaded, today());
  return loaded;
}

function capacityForToday(value = state) {
  return value.capacityByDate?.[today()] ?? value.capacity;
}

function message(text = '') {
  const element = document.querySelector('#app-message');
  element.textContent = text;
  element.hidden = !text;
}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function commit(next, options = {}) {
  const saved = await repository.commit(JSON.stringify(next), options);
  persistedRaw = saved.raw;
  state = next;
}

const NAV_GROUPS = [
  ['学习', [
    ['home','首页','M3 10 12 3l9 7v10H3z M9 20v-6h6v6'],
    ['tasks','任务池','M4 5h16v14H4z M4 10h16 M10 10v9'],
    ['reviews','复习库','M5 11a7 7 0 1 1 2 6 M5 5v6h6 M12 8v4l3 2']
  ]],
  ['进度', [
    ['records','记录','M6 4h12v16H6z M9 9h6 M9 13h6'],
    ['trial','试运行报告','M4 19h16 M7 15v-3 M12 15V8 M17 15V5'],
    ['skills','能力地图','M12 4v5 M6 15l6-6 6 6 M4 15h4v5H4z M16 15h4v5h-4z']
  ]],
  ['设置', [
    ['goals','目标','M20 12a8 8 0 1 1-8-8 8 8 0 0 1 8 8Z M12 8v8 M8 12h8'],
    ['data','数据','M5 7h14v12H5z M4 4h16v3H4z M10 11h4']
  ]]
];
function nav() {
  return `<aside class="sidebar"><div class="brand"><img class="brand-icon" src="./icon.svg" alt="" width="38" height="38">
    <div><b>方生方死</b><small>个人学习工作台</small></div></div>
    <nav aria-label="主导航">${NAV_GROUPS.map(([label, links]) =>
      `<div class="nav-group"><p>${label}</p>${links.map(([id, name, path]) =>
        `<a href="#${id}"${view === id ? ' class="active" aria-current="page"' : ''}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg><span>${name}</span></a>`
      ).join('')}</div>`).join('')}</nav>
    <p class="sidebar-note"><span></span>本机工作区</p></aside>`;
}
function pageHeader(section, title, description, action = '') {
  return `<header class="page-header"><div><p class="eyebrow">${section}</p><h1>${title}</h1>
    <p class="sub">${description}</p></div>${action}</header>`;
}
function home() {
  const date = today();
  const trialDays = buildTrialReport(state, date).days.length;
  const budget = dailyCapacity(state, date, capacityForToday());
  const plan = dailyQueuePlan(state, date, budget.capacity);
  const queue = plan.queue;
  const planned = queue.reduce((sum, item) => sum + item.minutes, 0);
  const due = dueReviews(state, date);
  const queuedReviews = queue.filter(item => item.kind === 'review').length;
  const lastSession = state.sessions.at(-1);
  const blocked = state.tasks.filter(task => task.status === 'blocked').length;
  const empty = !state.tasks.length && !state.reviews.length ? '任务池还没有待做的卡片。确认一项内容后，就能从这里接着学。' : budget.remaining === 0 ? '这段可用时间已用完。可以调整容量，或直接去任务池选择。'
    : '当前没有能放入剩余容量的行动，请查看任务池或调整今日容量。';
  return `<header class="home-hero"><div class="hero-copy">
    <p class="eyebrow"><time datetime="${esc(date)}">${esc(date)}</time> · 学习工作台</p>
    <h1>今天，向前一步<span>。</span></h1>
    <p>从你想学的那一科挑一张卡，留下一点看得见的进展。</p>
    <div class="hero-actions"><a class="button-link" href="#tasks">打开任务池 <span aria-hidden="true">↗</span></a>
      <a class="button-link secondary" href="#reviews">去复习${due.length ? ' · ' + due.length : ''}</a></div>
    </div><div class="hero-art" aria-hidden="true"><i></i><i></i><img src="./icon.svg" alt="" width="124" height="124"></div></header>
    <div class="home-metrics">
      <section class="card metric"><h2>实际投入</h2>
        <strong>${budget.actual} <small>分钟</small></strong>
        <p class="muted">可用 ${budget.remaining} 分钟 · 今日净学习容量 ${budget.capacity} 分钟</p>
        ${budget.overload ? `<p class="metric-warning">已超出 ${budget.overload} 分钟</p>` : ''}
        <button class="secondary" data-capacity>调整今日容量</button></section>
      <section class="card metric"><h2>到期复习</h2><strong>${due.length} <small>项</small></strong>
        <p class="muted">已放入队列 ${queuedReviews} 项 · 待另行安排 ${plan.deferredReviews} 项</p>
        <p class="muted">今日复习预算 ${plan.reviewBudget} 分钟 · 已用 ${plan.actualReview} 分钟</p></section>
      <section class="card metric"><h2>五天试运行</h2><strong>${trialDays} <small>/ 5 个学习日</small></strong>
        <div class="trial-marks" aria-hidden="true">${Array.from({length:5}, (_, i) => `<span${i < trialDays ? ' class="observed"' : ''}></span>`).join('')}</div>
        <a href="#trial">查看试运行报告</a></section>
    </div>
    <div class="home-layout">
      <section class="card queue-card"><header class="section-heading"><div><p class="eyebrow">现在可以开始</p><h2>今日队列</h2></div>
        <span class="tag">${queue.length} 项 · ${planned} 分钟</span></header>
        ${state.tasks.some(task => needsTaskReview(state, task)) ? '<p class="muted">旧版预置任务保留在任务池，等待规划复核。</p>' : ''}
        ${plan.pauseNew ? '<p class="form-error">到期复习尚未全部安排，暂缓新增学习任务，保留续学与补练习。</p>' : ''}
        <div class="stack">${queue.length ? queue.map(item => item.kind === 'review'
          ? `<article class="task"><div class="task-top"><span class="tag warning">到期复习</span><span class="task-time">${item.minutes} 分钟</span></div>
              <h3>${esc(item.title)}</h3><div class="card-actions"><button data-open-review="${esc(item.reviewId)}">开始回忆</button></div></article>`
          : taskCard(item, true)).join('') : `<p class="empty-state">${empty}</p>`}</div></section>
      <section class="card progress-card"><p class="eyebrow">学习足迹</p><h2>上一次，做到了哪里</h2>
        ${lastSession ? `<div class="progress-entry"><p class="muted">${esc(lastSession.date)} · ${esc(lastSession.minutes)} 分钟</p>
          <h3>${esc(lastSession.activity)}</h3><p class="progress-result">${esc(lastSession.result || lastSession.note || '已保存本次投入。')}</p></div>
          <a href="#records">查看学习记录</a>` : '<p class="empty-state">保存一次学习后，这里会显示你的实际投入和收获。</p>'}
        ${blocked ? `<p class="blocked-note">还有 ${blocked} 项卡住的任务 <a href="#tasks">去查看</a></p>` : ''}
      </section>
    </div>`;
}
function taskCard(task, action = false) {
  const status = { planned: '待开始', in_progress: '继续处理', done: '本项已结束', blocked: '遇到阻碍', cancelled: '已归档', skipped: '已跳过' }[task.status] || task.status;
  const source = task.sourceId ? state.sources.find(item => item.id === task.sourceId) : null;
  const checkpoint = task.courseCard === true ? state.sessions.findLast(item => item.taskId === task.id && item.position)?.position : null;
  return `<article class="task${task.courseCard ? ' course-card' : ''}"><div class="task-top"><span class="tag ${task.status === 'blocked' ? 'warning' : task.status === 'in_progress' ? 'in-progress' : ''}">${esc(status)}</span>
      ${task.courseCard || task.quickTask ? '' : `<span class="task-time">${esc(task.minutes)} 分钟</span>`}</div><h3>${esc(task.title)}</h3>
    ${needsTaskReview(state, task) ? '<p class="tag warning">旧版预置项 · 待复核</p>' : ''}
    ${task.courseCard || task.quickTask ? '' : `<p class="muted">${esc(task.goal)} · ${esc(task.skill)}</p>`}
    ${checkpoint ? `<p class="muted">上次停在 · ${esc(checkpoint)}</p>` : task.position && task.courseCard !== true ? `<p class="muted">实际起点 · ${esc(task.position)}</p>` : ''}
    ${task.resource && !task.courseCard ? `<p class="muted">资料 · ${esc(task.resource)}</p>` : ''}
    ${source ? `<p class="muted">来源 · ${esc(sourceLabel(source))}</p>` : ''}
    ${task.action ? (task.courseCard === true ? `<ol>${task.action.split('\n').map(line => `<li>${esc(line)}</li>`).join('')}</ol>` : `<p>${esc(task.action)}</p>`) : ''}
    ${task.stopCondition && !task.courseCard ? `<p class="muted">停止条件 · ${esc(task.stopCondition)}</p>` : ''}
    ${task.sourceReviewId ? `<details><summary>查看补练习来源</summary><div class="evidence-content">${esc(sourceText(state.reviews.find(item => item.id === task.sourceReviewId) || {}))}</div></details>` : ''}
    ${action ? `<div class="card-actions">${!['done', 'cancelled', 'skipped'].includes(task.status)
      ? `<button data-start="${esc(task.id)}">记录本次学习</button>` : ''}
    ${task.courseCard !== true && !task.sourceReviewId && !needsTaskReview(state, task) && ['planned', 'in_progress', 'blocked'].includes(task.status) ? `<button class="secondary" data-edit-task="${esc(task.id)}">调整任务</button>` : ''}
    ${task.courseCard !== true ? `<button class="secondary" data-task-lifecycle="${task.status === 'cancelled' ? 'restore' : 'archive'}" data-id="${esc(task.id)}">${task.status === 'cancelled' ? '恢复任务' : '归档任务'}</button>` : ''}</div>` : ''}
    </article>`;
}
function goals() {
  return `${pageHeader('方向', '目标', '把长期方向和眼前行动连起来。', '<button data-new-goal>新建目标</button>')}
    <div class="cards">${state.goals.map(goal => {
      const detail = goalSettings(state, goal[0]);
      const related = state.tasks.filter(task => taskBindings(state, task).goalIds.includes(goal[0]));
      const count = related.length;
      return `<section class="card"><span class="tag">${esc({critical:'长期主线',high:'阶段重点',medium:'持续推进',low:'待补信息'}[goal[3]] || goal[3])}</span>
        <h2>${esc(goal[1])}</h2><p>${esc(detail.window)}</p>
        <p class="muted">${detail.targetDate ? '确定日期 ' + esc(detail.targetDate) : '精确日期待核对'} · 关联任务 ${count} 项</p>
        <p class="muted">每周参考投入 ${detail.weeklyTargetMinutes === null ? '待测' : detail.weeklyTargetMinutes + ' 分钟'}</p>
        <details><summary>目标内容与说明</summary><p class="evidence-content">${esc(detail.notes || goal[2])}</p></details>
        <button class="secondary" data-edit-goal="${esc(goal[0])}">调整目标设置</button>
        <button data-new-task data-goal="${esc(goal[0])}">为此目标创建任务</button></section>`;
    }).join('')}</div>`;
}
function skills() {
  return `${pageHeader('能力', '能力地图', '看看哪些内容已经有产出，哪些还需要一次独立核验。')}
    <div class="cards">${state.skills.map(skill => {
      const list = evidenceForSkill(state, skill[0]);
      const handoff = handoffForSkill(state, skill[0]);
      const kinds = [...new Set(list.map(item => item.kind))];
      const levels = [...new Set(list.map(item => evidenceLevelLabel(item.level)))];
      return `<section class="card"><span class="muted">${esc(skill[2])}</span><h2>${esc(skill[1])}</h2>
        <p class="muted">${esc(handoff.position || '实际起点待核对')}</p>
        <p class="tag">${esc({confirmed:'起点已核对',unconfirmed:'起点待核对',deferred:'暂缓启动'}[handoff.status])}</p>
        <p class="tag ${list.length ? '' : 'warning'}">${list.length ? '已有学习证据' : '未核验'}</p>
        <p class="muted">证据 ${list.length} 条${kinds.length ? ' · ' + kinds.map(kind => esc(evidenceLabel(kind))).join('、') : ''}</p>
        <p class="muted">核验 ${levels.length ? levels.map(level => esc(level)).join('、') : '待核验'}</p>
        <div class="card-actions"><button data-edit-handoff="${esc(skill[0])}">学习交接</button><button data-skill-evidence="${esc(skill[0])}">查看证据</button>
        <button data-new-task data-skill="${esc(skill[0])}" ${handoff.status === 'deferred' ? 'disabled' : ''}>按交接创建任务</button></div></section>`;
    }).join('')}</div>`;
}
function subjectSections(groups, renderItem, emptyMessage) {
  if (!groups.length) return `<p class="empty-state">${esc(emptyMessage)}</p>`;
  const headingId = index => 'subject-heading-' + index;
  const jumps = groups.length > 1 ? `<nav class="subject-jumps" aria-label="跳到学科">${groups.map(({ subject, items }, index) =>
    `<button type="button" data-jump-subject="${headingId(index)}">${esc(subject)} <span>${items.length}</span></button>`
  ).join('')}</nav>` : '';
  return `<div class="stack subject-view">${jumps}${groups.map(({ subject, items }, index) =>
    `<section class="card subject-group"><header><h2 id="${headingId(index)}" tabindex="-1">${esc(subject)}</h2>
      <span class="muted">${items.length} 项</span></header><div class="subject-cards">${items.map(renderItem).join('')}</div></section>`
  ).join('')}</div>`;
}
function taskResults() {
  const selected = visibleCourseTasks(state.tasks, selectTasks(state, taskFilter));
  const groups = createSubjectIndex(state).tasks(selected);
  const waiting = state.tasks.filter(task => task.courseCard === true && ['planned', 'in_progress', 'blocked'].includes(task.status)).length - 1;
  return `<p class="muted">显示 ${selected.length} / ${state.tasks.length} 项${waiting > 0 ? ` · 高数还有 ${waiting} 讲按顺序接续` : ''}</p>
    ${subjectSections(groups, task => taskCard(task, true), '当前筛选下暂无任务。')}`;
}
function tasks() {
  const labels = { active: '待处理', all: '全部', planned: '待开始', in_progress: '继续处理', blocked: '遇到阻碍', done: '已完成', cancelled: '已归档', skipped: '已跳过' };
  return `${pageHeader('学科任务', '任务池', '按学科挑一张卡，看看从哪开始、做到哪里。', '<button data-new-task>新建任务</button>')}
    <div class="task-controls">
      <label>状态<select data-task-filter>${Object.entries(labels).map(([value,label]) => `<option value="${value}" ${taskFilter === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label>
    </div><div id="task-results">${taskResults()}</div>`;
}
function refreshTaskResults() {
  const target = document.querySelector('#task-results');
  if (target) target.innerHTML = taskResults();
}
function reviewResults() {
  const date = today();
  const groups = createSubjectIndex(state).reviews(state.reviews.filter(isActiveReview));
  const reviewCounts = new Map();
  for (const session of state.sessions) {
    if (session.reviewId) reviewCounts.set(session.reviewId, (reviewCounts.get(session.reviewId) || 0) + 1);
  }
  return subjectSections(groups, item => {
    const due = item.due <= date;
    return `<article class="task"><div class="task-top"><span class="tag${due ? ' warning' : ''}">${due ? '已到期' : '未到期'}</span>
      <span class="task-time">${esc(item.due)}</span></div>
      <h3>${esc(item.title)}</h3>
      <p class="muted">间隔 ${esc(item.interval || 1)} 天 · 已复习 ${esc(item.reviewCount ?? reviewCounts.get(item.id) ?? 0)} 次</p>
      ${due ? `<div class="card-actions"><button data-open-review="${esc(item.id)}">开始回忆</button></div>` : ''}</article>`;
  }, '复习库还没有卡片。');
}
function reviews() {
  return `${pageHeader('回忆练习', '复习库', '在对应的学科里，试着先想起来，再核对来源。')}
    <div id="review-results">${reviewResults()}</div>`;
}
function evidenceLabel(kind) {
  return { question: '题目', code: '代码', note: '笔记', oral: '口述', quiz: '测验' }[kind] || kind;
}
function renderEvidenceList(list) {
  if (!Array.isArray(list) || !list.length) return '<p class="muted">暂无独立证据。完成学习记录后，可以在这里查看产出。</p>';
  return `<div class="evidence-list">${list.slice().reverse().map(evidence => {
    const session = state.sessions.find(item => item.id === evidence.sessionId);
    return `<article class="evidence-item"><span class="tag">${esc(evidenceLabel(evidence.kind))}</span>
      <h3>${esc(evidence.title)}</h3><p>${esc(evidence.content)}</p>
      <small>能力 · ${esc(evidence.skill)} · ${esc(evidenceLevelLabel(evidence.level))}</small>
      <p class="muted">${session ? esc(session.date) + ' · ' + esc(session.minutes) + ' 分钟 · ' + esc(session.result) : '旧证据的来源学习记录待核对'}</p>
    </article>`;
  }).join('')}</div>`;
}
function records() {
  return `${pageHeader('学习足迹', '记录', '回看每一次实际投入、独立产出与回忆结果。')}
    <section class="card"><h2>学习与复习记录</h2>
    ${state.sessions.slice().reverse().map(session => `<article class="record-item">
      <p><b>${esc(session.activity)}</b> · ${esc(session.minutes)} 分钟</p>
      <p class="muted">${esc(session.date)} · ${esc(session.result || '未写结果')}</p>
      ${session.nextDue ? `<p>下次复习 ${esc(session.nextDue)}</p>` : ''}
      ${session.repairTaskId ? '<p>连续回忆失败，已生成补理解或补练习任务。</p>' : ''}
      ${session.note ? `<p class="evidence-content">${esc(session.note)}</p>` : ''}
      ${session.startupMinutes !== undefined ? `<p class="muted">启动等待 ${esc(session.startupMinutes)} 分钟（另记）</p>` : ''}
      ${session.blocker ? `<small>卡住原因 · ${esc(session.blocker)}</small>` : ''}
      ${correctionHistory(session)}
      <button class="secondary" data-correct-session="${esc(session.id)}">纠正这条记录</button>
    </article>`).join('') || '<p class="muted">还没有学习记录。</p>'}</section>
    <section class="card"><h2>独立证据</h2>${renderEvidenceList(state.evidence)}</section>`;
}
function correctionHistory(session) {
  const history = correctionsForSession(state, session.id);
  if (!history.length) return '';
  return `<details class="correction-history"><summary>已纠正 ${history.length} 次</summary>${history.slice().reverse().map(item =>
    `<article><p>${esc(item.createdAt)} · ${esc(item.reason)}</p><p class="muted">${Object.keys(item.after).map(key => `${esc(CORRECTION_FIELD_LABELS[key] || key)}：${esc(String(item.before[key] ?? '未填写'))} → ${esc(String(item.after[key] ?? '未填写'))}`).join(' · ')}</p></article>`).join('')}</details>`;
}

function trial() {
  const report = buildTrialReport(state, today());
  const activityLabel = { lecture: '听课', practice: '练习', review: '复习', project: '项目', quiz: '测验', organize: '整理', unknown: '未分类' };
  const review = report.review;
  const rate = review.independentRate === null ? '待测' : Math.round(review.independentRate * 100) + '%';
  const missingStartup = report.startup.eligibleCount - report.startup.knownCount;
  const warnings = [];
  if (report.diagnostics.invalid) warnings.push('无效学习记录 ' + report.diagnostics.invalid + ' 条');
  if (report.diagnostics.duplicate) warnings.push('重复记录 ' + report.diagnostics.duplicate + ' 条');
  if (report.diagnostics.future) warnings.push('未来日期记录 ' + report.diagnostics.future + ' 条');
  if (report.diagnostics.invalidStartup) warnings.push('启动等待数据无效 ' + report.diagnostics.invalidStartup + ' 条');
  const start = report.days[0]?.date;
  const end = report.days.at(-1)?.date;
  return `${pageHeader('投入观察', '五天试运行报告', '用最近 5 个有记录的学习日，看看时间花在哪、哪些内容还能想起来。')}
    ${warnings.length ? `<p class="form-error">统计已跳过以下数据，原始记录可从数据页导出核对。${esc(warnings.join('，'))}</p>` : ''}
    <div class="grid report-overview">
      <section class="card"><h2>观察进度</h2><strong>${report.days.length} <small>/ 5 个学习日</small></strong>
        <p>${start ? esc(start) + ' — ' + esc(end) : '还没有实际学习记录'}</p>
        <p class="muted">${report.remainingDays ? '还需 ' + report.remainingDays + ' 个学习日，当前结果可随时查看。' : '已形成一个观察窗口，可结合样本与卡点调整任务。'}</p>
      </section>
      <section class="card"><h2>窗口内实际投入</h2><strong>${report.totalMinutes} <small>分钟</small></strong>
        <p>${report.sessionCount} 次学习与复习 · ${report.evidenceCount} 条关联证据</p>
        <p class="muted">每条记录只计一次，多目标任务共享同一份投入。</p>
      </section>
      <section class="card"><h2>复习时独立想起</h2><strong>${rate}</strong>
        <p>${review.success} / ${review.rated} 次已评分回忆 · 部分想起 ${review.partial} 次 · 完全不会 ${review.fail} 次</p>
        <p class="muted">另有 ${review.attempts - review.rated} 次复习未评分。结果来自实际回忆记录。</p>
      </section>
      <section class="card"><h2>启动等待中位数</h2><strong>${report.startup.medianMinutes ?? '待测'} <small>${report.startup.knownCount ? '分钟' : ''}</small></strong>
        <p>${report.startup.knownCount} / ${report.startup.eligibleCount} 次学习已填写 · 合计 ${report.startup.totalMinutes} 分钟</p>
        <p class="muted">等待时间另记，净学习投入单独计算。</p>
      </section>
    </div>
    <section class="card"><h2>每日实际投入</h2>
      ${report.days.length ? `<div class="report-table-wrap"><table class="report-table"><thead><tr><th>学习日</th><th>实际分钟</th><th>记录次数</th><th>当日填写容量</th></tr></thead>
      <tbody>${report.days.map(day => `<tr><td>${esc(day.date)}</td><td>${day.minutes}</td><td>${day.sessions}</td>
        <td>${day.capacity === null ? '未填写' : day.capacity + ' 分钟' + (day.overload ? ' · 超出 ' + day.overload + ' 分钟' : '')}</td></tr>`).join('')}</tbody></table></div>`
        : '<p class="muted">保存一次学习记录后，这里会出现第一个学习日。</p>'}
    </section>
    <section class="card"><h2>各内容的实际投入</h2><p class="muted">每次投入中位数用于观察时段大小，完整行动耗时可查看下方结束记录。</p>
      <div class="report-table-wrap"><table class="report-table"><thead><tr><th>学习内容</th><th>累计分钟</th><th>记录次数</th><th>每次投入中位数</th></tr></thead>
      <tbody>${report.skills.map(skill => `<tr><td>${esc(skill.name)}</td><td>${skill.count ? skill.minutes : '待测'}</td>
        <td>${skill.count}</td><td>${skill.medianMinutes === null ? '待测' : skill.medianMinutes + ' 分钟'}</td></tr>`).join('')}</tbody></table></div>
    </section>
    <section class="card"><h2>活动分布</h2>
      ${report.activities.map(activity => `<p>${esc(activityLabel[activity.name] || activity.name)} · ${activity.minutes} 分钟 · ${activity.count} 次</p>`).join('') || '<p class="muted">活动分布待测。</p>'}
    </section>
    <section class="card"><h2>观察窗口内已结束的行动</h2>
      <p class="muted">依据保存时的结束状态，显示窗口内累计已记录投入。</p>
      ${report.completedActions.map(task => `<article class="record-item"><h3>${esc(task.title)}</h3><p>${task.minutes} 分钟 · ${task.count} 次记录</p></article>`).join('') || '<p class="muted">尚无带明确结束记录的行动。</p>'}
      <p class="muted">另有 ${report.unresolvedActions} 项行动仍待继续或缺少当时的结束状态。</p>
    </section>
    <section class="card"><h2>实际卡点</h2>
      ${report.blockers.map(blocker => `<article class="record-item"><p>${esc(blocker.date)} · ${esc(blocker.title)}</p><p class="evidence-content">${esc(blocker.reason)}</p></article>`).join('') || '<p class="muted">当前窗口没有填写卡住原因的记录。</p>'}
    </section>
    <section class="card"><h2>接下来补足的观察</h2>
      <p>${report.remainingDays ? '继续记录 ' + report.remainingDays + ' 个实际学习日。' : '下一步可从任务池核对行动大小与停止条件，再观察一个窗口。'}</p>
      ${missingStartup ? `<p>有 ${missingStartup} 次学习的启动等待仍待测，后续记录时可选填。</p>` : ''}
      ${!review.rated ? '<p>还缺少实际回忆评分，复习到期后记录独立想起、部分想起或完全不会。</p>' : ''}
      <p class="muted">用不同日期、不同活动和结束证据交叉核对，再逐步确定稳定容量。</p>
      <div class="card-actions"><a href="#tasks">查看任务池</a><a href="#reviews">查看到期复习</a></div>
    </section>`;
}

function data() {
  return `${pageHeader('本机工作区', '数据', '管理资料、备份和保存在这台设备上的学习记录。')}
    <section class="card"><h2>当前记录</h2><p class="muted">本地数据库 · 保存版本 ${repository.status().revision}</p><p>目标 ${state.goals.length} · 能力 ${state.skills.length} · 任务 ${state.tasks.length} · 记录 ${state.sessions.length} · 资料来源 ${state.sources.length}</p>
      <p class="muted">未完成的表单草稿可从草稿入口单独导出。</p>
      <div class="card-actions"><button data-export>导出完整备份</button><button data-import>导入备份</button><button data-verify-backup>核对备份文件</button></div>
    </section>
    <section class="card"><h2>资料库</h2>
      <p class="muted">记录课程、教材和题目的出处，之后可以按章节、页码或题号找回。</p>
      <div class="card-actions"><button data-new-source>新增资料来源</button></div>
      ${state.sources.length ? `<div class="stack">${state.sources.map(source => `<article class="record-item">
        <h3>${esc(sourceLabel(source))}</h3><p class="muted">${esc(SOURCE_TYPES[source.type])}</p>
        ${source.notes ? `<p class="evidence-content">${esc(source.notes)}</p>` : ''}
        <div class="card-actions">
          <button class="secondary" data-edit-source="${esc(source.id)}">编辑来源</button>
          ${source.url?.trim() ? `<a href="${esc(new URL(source.url).href)}" target="_blank" rel="noopener noreferrer">打开原资料</a>` : ''}
        </div>
      </article>`).join('')}</div>` : '<p class="muted">还没有保存资料。</p>'}
    </section>
    ${repository.status().legacyAvailable || repository.status().legacyChanged ? `<section class="card"><h2>旧版存储副本</h2>
      <p>${!repository.status().legacyAvailable ? '旧版副本已被清除，当前数据库记录仍保留。请导出当前备份，核对后恢复以确认版本。'
        : repository.status().legacyChanged ? '检测到旧版记录变化，先导出两份记录，再选择备份恢复。' : '保留迁移时的原文副本，便于核对。'}</p>
      ${repository.status().legacyAvailable ? '<button data-export-legacy>导出旧版原文</button>' : ''}</section>` : ''}
    <section class="card"><h2>存储与备份状态</h2><div id="data-health"><p class="muted">正在读取状态…</p></div></section>
    <section class="card"><h2>恢复前快照</h2><p>${state.recovery ? '已有上次恢复前的完整快照。' : '恢复备份时会自动保留当前记录。'}</p>
      ${state.recovery ? '<div class="card-actions"><button data-export-previous>导出恢复前快照</button>' +
        (state.recovery.state ? '<button data-restore-previous>恢复到这份快照</button>' : '') + '</div>' : ''}
    </section>`;
}
function stamp(value) {
  return value ? new Date(value).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }) : '暂无';
}
async function refreshDataHealth() {
  const target = document.querySelector('#data-health');
  if (!target) return;
  const request = ++healthRequest;
  const health = await getStorageHealth(repository);
  if (request !== healthRequest || target !== document.querySelector('#data-health')) return;
  const comparisonLabels = { current: '核对时与当时保存内容一致', 'last-export': '核对时与最近导出内容一致', different: '核对时内容与当时记录不同', unavailable: '完成结构校验，内容指纹比较不可用' };
  target.innerHTML = `<p>站点估算占用 ${esc(formatBytes(health.usage))} / ${esc(formatBytes(health.quota))}（含离线资源）</p>
    <p>数据库最新保存版本 ${health.revision ?? '未读取'}</p>
    <p>持久存储 · ${health.persistent === null ? '浏览器未提供状态' : health.persistent ? '已获授予' : '尽力保存'}</p>
    <p>最近发起导出 · ${esc(stamp(health.receipt?.exportedAt))}</p>
    ${health.receipt ? `<p class="muted">导出版本 ${health.receipt.revision} · ${esc(formatBytes(health.receipt.bytes))} · ${health.revision === health.receipt.revision ? '当前版本号相同' : '当前保存版本已不同'}</p>` : ''}
    <p>最近文件核对 · ${esc(stamp(health.verification?.checkedAt))}</p>
    ${health.verification ? `<p class="muted">${esc(comparisonLabels[health.verification.comparison])}</p>` : ''}
    <p class="muted">导出标记表示已发起下载，选回保存的文件可核对学习数据内容。持久存储由浏览器决定，备份仍可另行留存。</p>
    ${health.errors.length ? `<p class="form-error">${esc(health.errors.join('；'))}</p>` : ''}
    <div class="card-actions"><button data-refresh-health>刷新状态</button><button data-persist-storage ${!health.canPersist || health.persistent ? 'disabled' : ''}>申请持久存储</button></div>`;
}
function today() { return todayKey(); }
function render(){document.querySelector('#app').innerHTML=`<div class="shell">${nav()}<main>${view==='goals'?goals():view==='skills'?skills():view==='tasks'?tasks():view==='reviews'?reviews():view==='records'?records():view==='trial'?trial():view==='data'?data():home()}</main></div>`;if(view==='data')refreshDataHealth();}

let activeTaskId = null;
let editingTaskId = null;
let draftTaskId = null;
let activeReviewId = null;
let editingHandoffId = null;
let editingGoalId = null;
let editingSourceId = null;
let newSourceId = null;
let newGoalId = null;
let pendingRestore = null;
let openedDate = null;
let correctionSessionId = null;
const studyForm = document.querySelector('#study-log-form');
const correctionForm = document.querySelector('#correction-form');
const sourceForm = document.querySelector('#source-form');

function prepareForm(form) {
  form.reset();
  form.querySelector('.form-error').hidden = true;
  openedDate = today();
}

function sourceText(review) {
  if (review.evidenceId) {
    const evidence = state.evidence.find(item => item.id === review.evidenceId);
    if (evidence) return [evidence.title, evidence.content].filter(Boolean).join('\n\n');
  }
  // Older versions copied evidence text into the review or its source session.
  if (typeof review.evidence === 'string' && review.evidence.trim()) return review.evidence;
  const session = state.sessions.find(item => item.id === review.sessionId);
  if (session?.evidence) return session.evidence;
  if (session?.taskSnapshot?.courseCard === true) {
    return [review.title, session.position ? '学习断点 · ' + session.position : '',
      '先回忆本讲内容，再对照本讲例题、错题和公式笔记。'].filter(Boolean).join('\n\n');
  }
  return '这条旧复习没有可定位的证据，请对照原题、代码或笔记核对。';
}

function showEditor(form) {
  form.closest('dialog').showModal();
  if (resumingDraft) return;
  const context = {
    'study-log-form': {targetId:activeTaskId,entityId:null},
    'review-form': {targetId:activeReviewId,entityId:null},
    'capacity-form': {targetId:null,entityId:null},
    'task-form': {targetId:editingTaskId,entityId:draftTaskId},
    'handoff-form': {targetId:editingHandoffId,entityId:null},
    'goal-form': {targetId:editingGoalId,entityId:newGoalId},
    'source-form': {targetId:editingSourceId,entityId:newSourceId}
  };
  draftSupport?.begin(form, context[form.id]);
}

function openHandoff(id) {
  const skill = state.skills.find(item => item[0] === id);
  if (!skill) throw new Error('能力已不存在，请查看草稿内容');
  editingHandoffId = id;
  const handoff = handoffForSkill(state, id), form = document.querySelector('#handoff-form');
  prepareForm(form);
  document.querySelector('#handoff-title').textContent = skill[1] + ' · 学习交接';
  for (const name of ['resource','position','action','stopCondition','note','status']) form.elements[name].value = handoff[name];
  showEditor(form);
}
function openGoal(id = null) {
  const goal = state.goals.find(item => item[0] === id);
  if (id && !goal) throw new Error('目标已不存在，请查看草稿内容');
  editingGoalId = id;
  newGoalId = id || crypto.randomUUID();
  const detail = goal ? goalSettings(state, id) : {priority:'medium',window:'待核对',notes:'',targetDate:'',weeklyTargetMinutes:null};
  const form = document.querySelector('#goal-form');
  prepareForm(form);
  document.querySelector('#goal-title').textContent = goal ? goal[1] + ' · 设置' : '新建目标';
  form.elements.title.value = goal?.[1] || '';
  form.elements.title.readOnly = !!goal;
  for (const name of ['priority','window','notes','targetDate','weeklyTargetMinutes']) form.elements[name].value = detail[name] ?? '';
  showEditor(form);
}
function openSource(id = null) {
  const source = state.sources.find(item => item.id === id);
  if (id && !source) throw new Error('资料来源已不存在，请刷新后重试');
  editingSourceId = id;
  newSourceId = id || crypto.randomUUID();
  prepareForm(sourceForm);
  document.querySelector('#source-title').textContent = source ? '编辑资料来源' : '新增资料来源';
  sourceForm.elements.type.value = source?.type || 'course';
  sourceForm.elements.title.value = source?.title || '';
  sourceForm.elements.locator.value = source?.locator || '';
  sourceForm.elements.url.value = source?.url || '';
  sourceForm.elements.notes.value = source?.notes || '';
  showEditor(sourceForm);
}
function openStudy(id) {
  const task = state.tasks.find(item => item.id === id);
  if (!task || ['done','cancelled','skipped'].includes(task.status)) throw new Error('任务状态已变化，请重新核对');
  activeTaskId = task.id;
  prepareForm(studyForm);
  const course = task.courseCard === true;
  studyForm.classList.toggle('course-study', course);
  studyForm.querySelector('[data-complete-course]').hidden = !course;
  studyForm.elements.result.required = !course;
  const source = task.sourceId ? state.sources.find(item => item.id === task.sourceId) : null;
  document.querySelector('#study-log-task').textContent = task.title + ' · ' + task.goal;
  document.querySelector('#study-context').textContent = [
    task.position ? '实际起点 · ' + task.position : '', task.resource ? '资料 · ' + task.resource : '',
    source ? '来源 · ' + sourceLabel(source) : '',
    task.action ? '下一步 · ' + task.action : '', task.stopCondition ? '停止条件 · ' + task.stopCondition : ''
  ].filter(Boolean).join('\n');
  studyForm.elements.minutes.value = '';
  studyForm.elements.evidence.disabled = false;
  studyForm.elements.evidence.required = !course;
  showEditor(studyForm);
}
function openReview(id) {
  const review = dueReviews(state, today()).find(item => item.id === id);
  if (!review) throw new Error('复习日期已变化，请刷新队列');
  activeReviewId = review.id;
  const form = document.querySelector('#review-form');
  prepareForm(form);
  document.querySelector('#review-task').textContent = review.title;
  document.querySelector('#review-source').open = false;
  document.querySelector('#review-evidence').textContent = sourceText(review);
  document.querySelector('#review-preview').textContent = '选择结果后显示下一次复习日期。';
  showEditor(form);
}
function openCapacity() {
  const form = document.querySelector('#capacity-form');
  prepareForm(form);
  form.elements.minutes.value = capacityForToday();
  form.elements.reviewBudget.value = reviewBudgetForDay(state, today());
  showEditor(form);
}
function openCorrection(id) {
  const session = state.sessions.find(item => item.id === id);
  if (!session) throw new Error('学习记录已不存在，请刷新后重试');
  correctionSessionId = id;
  prepareForm(correctionForm);
  document.querySelector('#correction-title').textContent = '纠正记录 · ' + session.activity;
  document.querySelector('#correction-session').textContent = session.date + ' · 原记录会保留在纠正历史中';
  const label = name => CORRECTION_FIELD_LABELS[name] || name;
  document.querySelector('#correction-fields').innerHTML = correctionFields(session).map(name => {
    const value = Object.hasOwn(session, name) && session[name] !== null ? String(session[name]) : '';
    if (name === 'minutes' || name === 'startupMinutes') return `<label>${esc(label(name))}${name === 'startupMinutes' ? '（可清空）' : ''}<input name="${name}" type="number" min="${name === 'minutes' ? 1 : 0}" max="720" step="1" value="${esc(value)}" ${name === 'minutes' ? 'required' : ''}></label>`;
    return `<label>${esc(label(name))}<textarea name="${name}" maxlength="8000" ${name === 'result' ? 'required' : ''}>${esc(value)}</textarea></label>`;
  }).join('') + '<label>纠正原因<textarea name="reason" maxlength="1000" required placeholder="说明为什么这次修改可信，例如核对原始计时或回忆记录"></textarea></label>';
  correctionForm.closest('dialog').showModal();
}
function describeDraft(draft) {
  if (['task-form','study-log-form'].includes(draft.formId)) return state.tasks.find(item => item.id === draft.targetId)?.title || draft.fields.title || '新任务';
  if (draft.formId === 'review-form') return state.reviews.find(item => item.id === draft.targetId)?.title || '原复习';
  if (draft.formId === 'handoff-form') return state.skills.find(item => item[0] === draft.targetId)?.[1] || '原能力';
  if (draft.formId === 'goal-form') return draft.fields.title || '新目标';
  if (draft.formId === 'source-form') return draft.fields.title || '新资料来源';
  return draft.openedDate;
}
function resumeDraft(draft) {
  resumingDraft = true;
  try {
    if (draft.formId === 'task-form') {
      openTaskEditor({dataset:draft.targetId ? {editTask:draft.targetId} : {}});
      draftTaskId = draft.entityId;
    } else if (draft.formId === 'goal-form') { openGoal(draft.targetId); newGoalId = draft.entityId; }
    else if (draft.formId === 'study-log-form') openStudy(draft.targetId);
    else if (draft.formId === 'review-form') openReview(draft.targetId);
    else if (draft.formId === 'handoff-form') openHandoff(draft.targetId);
    else if (draft.formId === 'capacity-form') openCapacity();
    else if (draft.formId === 'source-form') { openSource(draft.targetId); newSourceId = draft.entityId; }
    const form = document.getElementById(draft.formId);
    if (!form.closest('dialog').open) throw new Error('草稿对应的表单暂不可编辑，请查看内容');
    return form;
  } finally { resumingDraft = false; }
}

function openTaskEditor(trigger) {
  const task = trigger.dataset.editTask ? state.tasks.find(item => item.id === trigger.dataset.editTask) : null;
  if (trigger.dataset.editTask && (!task || !['planned', 'in_progress', 'blocked'].includes(task.status))) {
    message('这项任务已结束，请创建下一步任务'); return;
  }
  editingTaskId = task?.id || null;
  draftTaskId = task?.id || crypto.randomUUID();
  const form = document.querySelector('#task-form');
  prepareForm(form);
  const details = form.querySelector('#task-details');
  details.hidden = !!task?.quickTask;
  details.open = !!(task && !task.quickTask || trigger.dataset.goal || trigger.dataset.skill);
  for (const name of ['skillId','minutes','position','action','stopCondition']) form.elements[name].required = false;
  const binding = task ? taskBindings(state, task) : { goalIds: trigger.dataset.goal ? [trigger.dataset.goal] : [], skillId: trigger.dataset.skill || '' };
  let handoffDraft = null;
  if (!task && trigger.dataset.skill) {
    try { handoffDraft = handoffTaskInput(state, trigger.dataset.skill, handoffForSkill(state, trigger.dataset.skill), binding.goalIds); }
    catch (error) { message(error.message); return; }
  }
  const locked = task && hasTaskHistory(state, task.id);
  document.querySelector('#task-editor-title').textContent = task ? '调整任务' : '新建下一步任务';
  document.querySelector('#task-goals').innerHTML = state.goals.map(goal =>
    `<label><input type="checkbox" name="goalIds" value="${esc(goal[0])}" ${binding.goalIds.includes(goal[0]) ? 'checked' : ''} ${locked ? 'disabled' : ''}>${esc(goal[1])}</label>`).join('');
  form.elements.skillId.innerHTML = '<option value="">请选择对应能力</option>' + state.skills.map(skill =>
    `<option value="${esc(skill[0])}">${esc(skill[1])}</option>`).join('');
  form.elements.skillId.value = binding.skillId;
  form.elements.skillId.disabled = !!locked;
  form.elements.sourceId.innerHTML = '<option value="">暂不关联独立来源</option>' + state.sources.map(source =>
    `<option value="${esc(source.id)}">${esc(sourceLabel(source))}</option>`).join('');
  document.querySelector('#task-binding-hint').textContent = locked
    ? '已有学习记录，保留原来的目标与能力归属。需要换方向时可另建任务。'
    : '一个任务可以服务多个目标，投入时间只计算一次。';
  for (const field of ['title', 'minutes', 'resource', 'position', 'action', 'stopCondition']) {
    form.elements[field].value = task?.[field] ?? handoffDraft?.[field] ?? (field === 'minutes' ? 30 : '');
  }
  form.elements.sourceId.value = task?.sourceId || '';
  showEditor(form);
}

function downloadData(text, prefix) {
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = prefix + '-' + today() + '.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function openRestore(incoming, name) {
  pendingRestore = incoming;
  restoreLegacyRaw = repository.legacyRawNow();
  const form = document.querySelector('#restore-form');
  prepareForm(form);
  document.querySelector('#restore-preview').textContent = name + ' · ' +
    incoming.goals.length + ' 个目标 · ' + incoming.tasks.length + ' 个任务 · ' + incoming.sessions.length + ' 条学习记录 · ' +
    (incoming.sources?.length ?? 0) + ' 项资料来源';
  document.querySelector('#restore-dialog').showModal();
}

document.addEventListener('change', event => {
  if (event.target.matches('[data-task-filter]')) { taskFilter = event.target.value; refreshTaskResults(); }
});

document.addEventListener('click', async event => {
  const subjectJump = event.target.closest('.subject-jumps button[data-jump-subject]');
  if (subjectJump) {
    const heading = document.getElementById(subjectJump.dataset.jumpSubject);
    if (heading && subjectJump.closest('.subject-view').contains(heading)) {
      heading.focus({ preventScroll: true });
      heading.scrollIntoView({ block: 'start' });
    }
    return;
  }
  const lifecycle = event.target.closest('[data-task-lifecycle]');
  if (lifecycle) {
    const task = state.tasks.find(item => item.id === lifecycle.dataset.id);
    if (!task) return;
    lifecycleTarget = { id: task.id, archive: lifecycle.dataset.taskLifecycle === 'archive' };
    const form = document.querySelector('#task-lifecycle-form');
    prepareForm(form);
    document.querySelector('#task-lifecycle-title').textContent = lifecycleTarget.archive ? '归档任务' : '恢复任务';
    document.querySelector('#task-lifecycle-summary').textContent = task.title + (lifecycleTarget.archive ? ' · 归档后退出待处理列表。' : ' · 恢复后回到归档前状态。');
    document.querySelector('#task-lifecycle-confirm').textContent = lifecycleTarget.archive ? '确认归档' : '确认恢复';
    document.querySelector('#task-lifecycle-dialog').showModal();
  }
  if (event.target.closest('[data-refresh-health]')) refreshDataHealth();
  if (event.target.closest('[data-persist-storage]')) {
    try {
      if (!navigator.storage?.persist) throw new Error('当前浏览器暂不支持申请');
      const granted = await navigator.storage.persist();
      message(granted ? '浏览器已授予持久存储' : '浏览器尚未授予持久存储，仍可使用本地记录并另存备份');
      refreshDataHealth();
    } catch (error) { message('持久存储申请未完成：' + error.message); }
  }
  const correctionButton = event.target.closest('[data-correct-session]');
  if (correctionButton) { try { openCorrection(correctionButton.dataset.correctSession); } catch (error) { message(error.message); } }
  if (event.target.closest('[data-verify-backup]')) document.querySelector('#verify-backup-file').click();
  const handoffButton = event.target.closest('[data-edit-handoff]');
  if (handoffButton) openHandoff(handoffButton.dataset.editHandoff);
  const goalButton = event.target.closest('[data-edit-goal], [data-new-goal]');
  if (goalButton) openGoal(goalButton.dataset.editGoal || null);
  if (event.target.closest('[data-export-legacy]')) {
    try {
      const raw = repository.legacyRawNow();
      if (raw === null) throw new Error('没有旧版存储副本');
      downloadData(raw, 'study-app-legacy');
    } catch (error) { message(error.message); }
  }
  if (event.target.closest('[data-import]')) document.querySelector('#backup-file').click();
  if (event.target.closest('[data-restore-previous]') && state?.recovery?.state) {
    openRestore(structuredClone(state.recovery.state), '恢复前快照');
  }
  if (event.target.closest('[data-export-previous]') && state?.recovery) {
    try {
      const recovery = state.recovery;
      const text = recovery.raw ?? JSON.stringify(createBackup(recovery.state, new Date().toISOString()), null, 2);
      downloadData(text, 'study-app-before-restore');
    } catch (error) { message(error.message); }
  }
  const taskEditor = event.target.closest('[data-new-task], [data-edit-task]');
  if (taskEditor) openTaskEditor(taskEditor);
  const sourceEditor = event.target.closest('[data-new-source], [data-edit-source]');
  if (sourceEditor) openSource(sourceEditor.dataset.editSource || null);
  const skillButton = event.target.closest('[data-skill-evidence]');
  if (skillButton) {
    const skill = state.skills.find(item => item[0] === skillButton.dataset.skillEvidence);
    if (!skill) return;
    document.querySelector('#skill-evidence-title').textContent = skill[1] + ' · 学习证据';
    document.querySelector('#skill-evidence-list').innerHTML = renderEvidenceList(evidenceForSkill(state, skill[0]));
    document.querySelector('#skill-evidence-dialog').showModal();
  }
  const start = event.target.closest('[data-start]');
  if (start) openStudy(start.dataset.start);
  const reviewButton = event.target.closest('[data-open-review]');
  if (reviewButton) { try { openReview(reviewButton.dataset.openReview); } catch(error) { message(error.message); } }
  if (event.target.closest('[data-capacity]')) openCapacity();
  if (event.target.closest('[data-close]') && !saving) event.target.closest('dialog').close();
  if (event.target.closest('[data-export]')) {
    let raw = persistedRaw;
    try {
      const snapshot = repository ? await repository.snapshot() : null;
      raw = snapshot ? snapshot.raw : localStorage.getItem(KEY);
      const current = raw === null ? state : JSON.parse(raw);
      if (!current) { downloadData(raw || '{}', 'study-app-raw'); return; }
      const exportedAt = new Date().toISOString();
      const text = serializeBackup(current, exportedAt);
      const sha256 = await fingerprintState(current);
      downloadData(text, 'study-app-backup');
      try {
        await repository.recordMetadata('backup-receipt', {
          revision: snapshot?.revision ?? 0, sha256, exportedAt, bytes: new TextEncoder().encode(text).byteLength
        });
      } catch (error) { message('导出已发起，导出标记未保存：' + error.message); }
      refreshDataHealth();
    } catch (error) {
      message(error.message + '，已导出原始内容供核对');
      downloadData(raw || '{}', 'study-app-raw');
    }
  }
});

document.querySelector('#backup-file').addEventListener('change', async event => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    if (file.size > MAX_BACKUP_BYTES) throw new Error('备份文件超过大小上限');
    openRestore(parseBackup(await file.text()), file.name);
  } catch (error) { pendingRestore = null; message(error.message); }
  finally { event.target.value = ''; }
});

document.querySelector('#verify-backup-file').addEventListener('change', async event => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    if (file.size > MAX_BACKUP_BYTES) throw new Error('备份文件超过大小上限');
    const candidate = parseBackup(await file.text());
    const hash = await fingerprintState(candidate);
    const snapshot = await repository.snapshot();
    let currentHash = null;
    try { currentHash = await fingerprintState(snapshot.raw === null ? state : JSON.parse(snapshot.raw)); }
    catch (error) { console.warn('当前记录暂不能参与备份比较', error); }
    const receipt = await repository.readMetadata('backup-receipt');
    const comparison = compareBackup(hash, currentHash, receipt);
    const descriptions = {
      current: '核对通过，学习数据与当前已保存内容一致。',
      'last-export': '核对通过，与最近发起导出的学习数据一致。当前记录请另行核对。',
      different: '结构与引用校验通过，学习数据与当前保存内容不同。',
      unavailable: '结构与引用校验通过，当前环境或记录状态暂不能进行指纹比较。'
    };
    message(descriptions[comparison]);
    try {
      await repository.recordMetadata('backup-verification', { sha256: hash, checkedAt: new Date().toISOString(), comparison });
    } catch (error) { message(descriptions[comparison] + ' 状态标记未保存：' + error.message); }
    refreshDataHealth();
  } catch (error) { message('备份核对失败：' + error.message); }
  finally { event.target.value = ''; }
});

studyForm.elements.evidenceType.addEventListener('change', () => {
  const none = studyForm.elements.evidenceType.value === 'none';
  studyForm.elements.evidence.required = !none;
  studyForm.elements.evidence.disabled = none;
});

document.querySelector('#review-form').elements.outcome.addEventListener('change', event => {
  const review = state.reviews.find(item => item.id === activeReviewId);
  const preview = document.querySelector('#review-preview');
  if (!review || !event.target.value) { preview.textContent = '请选择回忆结果。'; return; }
  const next = rescheduleReview(review, event.target.value, today());
  preview.textContent = '下次复习 ' + next.due + '，间隔 ' + next.interval + ' 天。';
});

function bindSave(form, buildNext) {
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (saving || !form.reportValidity()) return;
    const error = form.querySelector('.form-error');
    error.hidden = true;
    saving = true;
    const controls = [...form.elements].map(element => ({element,disabled:element.disabled}));
    controls.filter(({element}) => element.tagName === 'BUTTON').forEach(({element}) => { element.disabled = true; });
    try {
      if (openedDate !== today()) throw new Error('日期已经变化，请重新打开表单');
      const fields = Object.fromEntries(new FormData(form));
      if (form === studyForm && event.submitter?.hasAttribute('data-complete-course')) fields.completeCourse = true;
      if (form.id === 'task-form') {
        fields.goalIds = [...form.querySelectorAll('[name="goalIds"]:checked')].map(input => input.value);
        fields.skillId = form.elements.skillId.value;
      }
      controls.forEach(({element}) => { element.disabled = true; });
      const draft = await draftSupport?.beforeSave(form);
      const next = buildNext(fields);
      await commit(next, { ...(form.id === 'restore-form' ? {acceptLegacyRaw:restoreLegacyRaw} : {}), ...(draft ? {draft} : {}) });
      draftSupport?.saved(form);
      form.closest('dialog').close();
      if (form.id === 'task-form' && editingTaskId === null) taskFilter = 'active';
      if (form.id === 'task-lifecycle-form' && !lifecycleTarget.archive) {
        const restored = state.tasks.find(item => item.id === lifecycleTarget.id);
        taskFilter = ['done', 'skipped'].includes(restored.status) ? restored.status : 'active';
      }
      render();
      message('已保存在本机');
    } catch (failure) {
      draftSupport?.saveFailed(form, failure);
      error.textContent = failure.message;
      error.hidden = false;
    } finally {
      saving = false;
      controls.forEach(({element,disabled}) => { element.disabled = disabled; });
      offlineSupport.retryUpdate();
    }
  });
}

bindSave(document.querySelector('#task-lifecycle-form'), () => {
  if (!lifecycleTarget) throw new Error('请重新选择任务');
  return archiveTask(state, lifecycleTarget.id, lifecycleTarget.archive, new Date().toISOString());
});
bindSave(document.querySelector('#handoff-form'), fields => saveHandoff(state, editingHandoffId, fields, new Date().toISOString()));
bindSave(document.querySelector('#goal-form'), fields => {
  const settings = {
    priority: fields.priority, window: fields.window, notes: fields.notes, targetDate: fields.targetDate,
    weeklyTargetMinutes: fields.weeklyTargetMinutes.trim() ? Number(fields.weeklyTargetMinutes) : null
  };
  return editingGoalId ? saveGoalSettings(state, editingGoalId, settings) : createGoal(state, fields.title, newGoalId, settings);
});
bindSave(document.querySelector('#restore-form'), () => {
  if (!pendingRestore) throw new Error('请重新选择备份文件');
  return stateForRestore(state, pendingRestore, persistedRaw);
});
bindSave(correctionForm, fields => applySessionCorrection(
  state, correctionSessionId, fields, fields.reason, new Date().toISOString(), crypto.randomUUID()
));

bindSave(document.querySelector('#task-form'), fields => {
  const now = new Date().toISOString();
  const current = state.tasks.find(task => task.id === editingTaskId);
  if (current?.quickTask || (!current && !fields.goalIds.length && !fields.skillId &&
      ![fields.resource, fields.sourceId, fields.position, fields.action, fields.stopCondition].some(value => value?.trim()))) {
    return saveQuickTask(state, fields, draftTaskId, now, editingTaskId);
  }
  return saveTask(state, {
    title: fields.title, goalIds: fields.goalIds, skillId: fields.skillId, minutes: Number(fields.minutes),
    resource: fields.resource, sourceId: fields.sourceId, position: fields.position, action: fields.action, stopCondition: fields.stopCondition
  }, draftTaskId, now, editingTaskId);
});

bindSave(sourceForm, fields => saveSource(
  state, { type: fields.type, title: fields.title, locator: fields.locator, url: fields.url, notes: fields.notes },
  newSourceId, new Date().toISOString(), editingSourceId
));

bindSave(studyForm, fields => {
  const task = state.tasks.find(item => item.id === activeTaskId);
  if (!task || ['done', 'cancelled', 'skipped'].includes(task.status)) throw new Error('任务状态已变化，请重新选择');
  const minutes = Number(fields.minutes);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 720) throw new Error('请输入 1—720 的整数分钟');
  if (task.courseCard === true) {
    if (currentCourseCard(state.tasks)?.id !== task.id) throw new Error('请先完成当前讲');
    const labels = { lecture: '听课', practice: '练习', review: '复习', project: '项目', quiz: '测验', organize: '整理' };
    if (!Object.hasOwn(labels, fields.activity)) throw new Error('请选择学习类型');
    const position = (fields.positionNext || '').trim();
    if (position.length > 1000) throw new Error('实际断点最多 1000 字');
    const completed = fields.completeCourse === true;
    const status = completed ? 'done' : 'in_progress';
    const session = {
      id: crypto.randomUUID(), date: today(), createdAt: new Date().toISOString(), minutes,
      activityType: fields.activity, activity: labels[fields.activity] + ' · ' + task.title,
      position, taskId: task.id, taskSnapshot: structuredClone(task), taskStatusAfter: status
    };
    const reviewId = 'course-review-' + task.id;
    const reviews = completed && !state.reviews.some(review => review.id === reviewId) ?
      [...state.reviews, { id: reviewId, title: task.title, taskId: task.id, sessionId: session.id,
        ...scheduleReview(session, today()) }] : state.reviews;
    return { ...state, sessions: [...state.sessions, session], reviews,
      tasks: state.tasks.map(item => item.id === task.id ? { ...item, status } : item) };
  }
  const startupMinutes = fields.startupMinutes?.trim() ? Number(fields.startupMinutes) : undefined;
  if (startupMinutes !== undefined && (!Number.isInteger(startupMinutes) || startupMinutes < 0 || startupMinutes > 720)) {
    throw new Error('启动等待须为 0—720 的整数分钟，也可以留空');
  }
  const result = fields.result.trim();
  const content = (fields.evidence || '').trim();
  const blocker = fields.blocker.trim();
  if (!result) throw new Error('请填写实际学习结果');
  if (!['in_progress', 'done', 'blocked'].includes(fields.taskStatus)) throw new Error('任务状态无效');
  if (!['question', 'code', 'note', 'oral', 'quiz', 'none'].includes(fields.evidenceType)) throw new Error('证据类型无效');
  const evidenceLevel = normalizeEvidenceLevel(fields.evidenceLevel || 'unknown');
  if (fields.evidenceType === 'none' && evidenceLevel !== 'unknown') throw new Error('没有证据时核验等级应为待核验');
  if (fields.evidenceType !== 'none' && !content) throw new Error('请填写证据内容');
  if (fields.taskStatus === 'done' && fields.evidenceType === 'none') throw new Error('完成本项行动前请留下证据，或选择还需继续');
  if (fields.taskStatus === 'blocked' && !blocker) throw new Error('请填写卡住原因');
  const activityLabels = { lecture: '听课', practice: '练习', review: '复习', project: '项目', quiz: '测验', organize: '整理' };
  if (!Object.hasOwn(activityLabels, fields.activity)) throw new Error('活动类型无效');
  const session = {
    id: crypto.randomUUID(), date: today(), createdAt: new Date().toISOString(), minutes,
    activityType: fields.activity, activity: activityLabels[fields.activity] + ' · ' + task.title,
    result, evidenceType: fields.evidenceType, evidenceLevel, evidence: content, blocker, taskId: task.id,
    plannedMinutes: task.minutes, taskSnapshot: structuredClone(task), taskStatusAfter: fields.taskStatus,
    ...(startupMinutes !== undefined ? { startupMinutes } : {})
  };
  const positionNext = (fields.positionNext || '').trim();
  if (positionNext.length > 1000) throw new Error('实际断点最多 1000 字');
  if (positionNext) session.position = positionNext;
  const next = structuredClone(state);
  next.sessions.push(session);
  const binding = taskBindings(state, task);
  if (positionNext && binding.skillId) {
    const handoff = handoffForSkill(state, binding.skillId);
    next.skillHandoffs = { ...next.skillHandoffs, [binding.skillId]: {
      ...handoff, position: positionNext, lastSessionId: session.id, updatedAt: session.createdAt
    } };
  }
  next.tasks.find(item => item.id === task.id).status = fields.taskStatus;
  const evidence = createEvidenceFromSession(session, task);
  if (evidence) {
    next.evidence.push(evidence);
    next.reviews.push({
      id: crypto.randomUUID(), title: task.title, taskId: task.id,
      ...scheduleReview(session, today()), evidenceId: evidence.id
    });
  }
  return next;
});

bindSave(document.querySelector('#review-form'), fields => recordReview(
  state, activeReviewId, { minutes: Number(fields.minutes), outcome: fields.outcome, note: fields.note },
  today(), crypto.randomUUID(), new Date().toISOString()
));

bindSave(document.querySelector('#capacity-form'), fields => {
  const minutes = Number(fields.minutes);
  if (!Number.isInteger(minutes) || minutes < 0 || minutes > 600) throw new Error('今日容量须为 0—600 的整数分钟');
  const reviewBudget = Number(fields.reviewBudget);
  if (!Number.isInteger(reviewBudget) || reviewBudget < 0 || reviewBudget > 600) throw new Error('复习预算须为 0—600 的整数分钟');
  return {
    ...state, capacityByDate: { ...state.capacityByDate, [today()]: minutes },
    reviewBudgetByDate: { ...state.reviewBudgetByDate, [today()]: reviewBudget }
  };
});

document.querySelectorAll('dialog').forEach(element => element.addEventListener('cancel', event => {
  if (saving) event.preventDefault();
}));
document.querySelectorAll('dialog').forEach(element => element.addEventListener('close', () => offlineSupport.retryUpdate()));
async function prepareCalculusCards() {
  if (view !== 'tasks' || !state || saving || location.origin !== 'https://fangsheng.invalid' ||
      !window.chrome?.webview || !state.goals.some(goal => goal[0] === 'g1')) return;
  try {
    const next = addCalculusLectures(state, new Date().toISOString());
    if (next === state) return;
    saving = true;
    try { await commit(next); } finally { saving = false; }
  } catch (error) { message('高数卡片未能添加：' + error.message); }
}
window.addEventListener('hashchange', async () => {
  view = location.hash.slice(1) || 'home';
  await prepareCalculusCards();
  if (state) render();
});
window.addEventListener('storage', event => {
  if (event.key === KEY) message('其他窗口更新了记录，请刷新后继续');
});
document.querySelector('#dismiss-update').addEventListener('click', () => {
  document.querySelector('#update-notice').hidden = true;
  try { localStorage.setItem('study-app-release', '2026-11-03-form-drafts'); }
  catch (error) { console.warn('进度通知偏好未保存', error); }
});
async function startApp() {
  try {
    repository = await openRepository();
    repository.subscribe(kind => message(kind === 'version'
      ? '本地数据库已升级，请刷新后继续'
      : '其他窗口更新了记录，请刷新后继续'));
    state = await loadState();
    await prepareCalculusCards();
    render();
    draftSupport = createDraftController({repository,getDate:today,getSaving:()=>saving,onMessage:message,onResume:resumeDraft,describe:describeDraft});
    if (repository.status().legacyChanged) message('旧版记录已变化，请在数据页导出当前记录并核对旧副本，再选择备份恢复');
    document.querySelector('#update-notice').hidden = localStorage.getItem('study-app-release') === '2026-11-03-form-drafts';
  } catch (error) {
    state = null;
    message(error.message);
    document.querySelector('#app').innerHTML = '<main><h1>需要检查本地记录</h1><p>原始数据已保留，可以先导出或选择有效备份恢复。</p><button data-export>导出原始数据</button><button data-import>选择备份恢复</button></main>';
  } finally {
    appReady = true;
    offlineSupport.retryUpdate();
  }
}
const offlineSupport = startOfflineSupport({
  canUpdate: () => appReady && !saving && !document.querySelector('dialog[open]'),
  onStatus: text => { document.querySelector('#offline-status').textContent = text; },
  onUpdate: ready => { document.querySelector('#apply-update').hidden = !ready; },
  onInstall: ready => { document.querySelector('#install-app').hidden = !ready; }
});
document.querySelector('#install-app').addEventListener('click', async () => {
  try { await offlineSupport.install(); } catch (error) { message('安装入口暂不可用：' + error.message); }
});
document.querySelector('#apply-update').addEventListener('click', () => {
  if (saving || document.querySelector('dialog[open]')) { message('新版本已准备好，保存或关闭当前表单后会自动更新'); return; }
  try { if (!offlineSupport.applyUpdate()) message('当前已是可用版本'); }
  catch (error) { message('更新暂不可用：' + error.message); }
});
startApp();
