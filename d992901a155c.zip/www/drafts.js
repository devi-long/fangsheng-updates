export const DRAFT_FIELDS = {
  'study-log-form': { minutes:32, startupMinutes:32, activity:40, result:4000, positionNext:1000, taskStatus:40, evidenceType:40, evidenceLevel:40, evidence:8000, blocker:4000 },
  'review-form': { minutes:32, outcome:40, note:4000 },
  'capacity-form': { minutes:32, reviewBudget:32 },
  'task-form': { title:160, goalIds:128, skillId:160, minutes:32, resource:1000, sourceId:200, position:1000, action:2000, stopCondition:2000 },
  'source-form': { type:40, title:200, locator:400, url:2048, notes:4000 },
  'handoff-form': { status:40, resource:1000, position:1000, action:2000, stopCondition:2000, note:4000 },
  'goal-form': { title:160, priority:40, window:400, targetDate:32, weeklyTargetMinutes:32, notes:4000 }
};
export const DRAFT_LABELS = {
  'study-log-form':'学习记录', 'review-form':'回忆与核对', 'capacity-form':'今日容量',
  'task-form':'任务', 'source-form':'资料来源', 'handoff-form':'学习交接', 'goal-form':'目标设置'
};
export const FIELD_LABELS = {
  minutes:'分钟数', startupMinutes:'启动等待', activity:'活动类型', result:'学习结果', positionNext:'本次停在',
  taskStatus:'任务状态', evidenceType:'证据类型', evidenceLevel:'证据核验等级', evidence:'证据内容', blocker:'卡住原因', outcome:'回忆结果',
  note:'备注', reviewBudget:'复习预算', title:'标题', goalIds:'目标 ID', skillId:'能力 ID', resource:'资料位置',
  position:'实际起点', action:'下一步动作', stopCondition:'停止条件', sourceId:'资料来源', type:'资料类型', locator:'资料定位', url:'资料链接',
  status:'起点状态', priority:'优先级',
  window:'目标窗口', targetDate:'目标日期', weeklyTargetMinutes:'每周参考投入', notes:'目标说明'
};
const KEYS = ['version','id','ownerId','formId','targetId','entityId','baseRevision','openedDate','updatedAt','sequence','fields'];
const LEGACY_FIELDS = {
  'task-form': { sourceId: '' },
  'study-log-form': { evidenceLevel: 'unknown' }
};
const token = value => typeof value === 'string' && /^[A-Za-z0-9-]{1,80}$/.test(value);
function exactObject(value, keys, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)) ||
      Object.keys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value, key))) {
    throw new Error(label + '字段不完整或格式无效');
  }
}
function validDate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0,10) === value;
}
export function draftKey(id) {
  if (!token(id)) throw new Error('草稿 ID 无效');
  return 'draft:' + id;
}
export function validateDraft(value) {
  exactObject(value, KEYS, '草稿');
  if (value.version !== 1 || !token(value.id) || !token(value.ownerId)) throw new Error('草稿版本或 ID 无效');
  if (!Object.hasOwn(DRAFT_FIELDS, value.formId)) throw new Error('草稿表单类型无效');
  const maxIdLength = value.formId === 'source-form' ? 200 : 160;
  for (const key of ['targetId','entityId']) {
    if (value[key] !== null && (typeof value[key] !== 'string' || !value[key].trim() || value[key].length > maxIdLength)) throw new Error('草稿关联 ID 无效');
  }
  if (!Number.isSafeInteger(value.baseRevision) || value.baseRevision < 0 ||
      !Number.isSafeInteger(value.sequence) || value.sequence < 1) throw new Error('草稿保存版本无效');
  if (!validDate(value.openedDate)) throw new Error('草稿日期无效');
  if (typeof value.updatedAt !== 'string' || !Number.isFinite(Date.parse(value.updatedAt)) ||
      new Date(value.updatedAt).toISOString() !== value.updatedAt) throw new Error('草稿保存时间无效');
  const fields = DRAFT_FIELDS[value.formId];
  const keys = Object.keys(fields);
  const legacy = LEGACY_FIELDS[value.formId] ?? {};
  exactObject(value.fields, keys.filter(key => !Object.hasOwn(legacy, key) || Object.hasOwn(value.fields ?? {}, key)), '草稿内容');
  const normalizedFields = { ...legacy, ...value.fields };
  for (const [key, maximum] of Object.entries(fields)) {
    const field = normalizedFields[key];
    if (key === 'goalIds') {
      if (!Array.isArray(field) || field.length > maximum || new Set(field).size !== field.length ||
          Array.from(field).some(item => typeof item !== 'string' || !item.trim() || item.length > 160)) throw new Error('草稿目标列表无效');
    } else if (typeof field !== 'string' || field.length > maximum) throw new Error('草稿内容 ' + key + ' 类型无效或过长');
  }
  const normalized = { ...value, fields: normalizedFields };
  if (JSON.stringify(normalized).length > 64000) throw new Error('草稿内容超过大小上限');
  return structuredClone(normalized);
}
export function assertDraftMatch(current, expected) {
  if (!expected || !token(expected.id) || !token(expected.ownerId) || !Number.isSafeInteger(expected.sequence) || expected.sequence < 1 ||
      !current || current.id !== expected.id || current.ownerId !== expected.ownerId || current.sequence !== expected.sequence) {
    const error = new Error('草稿已在其他窗口变化，请保留输入后重试');
    error.code = 'DRAFT_CONFLICT';
    throw error;
  }
}
export function draftResumeReason(draft, revision, today) {
  validateDraft(draft);
  if (!Number.isSafeInteger(revision) || revision < 0 || !validDate(today)) throw new Error('当前草稿核对条件无效');
  if (draft.baseRevision !== revision) return '正式记录版本已变化，请查看或导出草稿，再重新打开表单核对。';
  if (['study-log-form','review-form','capacity-form'].includes(draft.formId) && draft.openedDate !== today) {
    return '草稿属于其他日期，请查看或导出后核对，避免记入今天。';
  }
  return '';
}
