import { saveTask } from './tasks.js';

const titles = [
  "函数极限与连续",
  "数列极限",
  "一元函数微分学的概念",
  "一元函数微分学的计算",
  "一元函数微分学的应用（一）",
  "一元函数微分学的应用（二）",
  "一元函数微分学的应用（三）",
  "一元函数积分学的概念与性质",
  "一元函数积分学的计算",
  "一元函数积分学的应用（一）",
  "一元函数积分学的应用（二）",
  "一元函数积分学的应用（三）",
  "多元函数微分学",
  "二重积分",
  "微分方程",
  "无穷级数",
  "多元函数积分学的预备知识（仅数学一）",
  "多元函数积分学（仅数学一）"
];
const actions = [
  '听课｜跟着本讲视频学习，标出没听懂的地方。',
  '手推例题和课后题｜合上答案手推例题，再独立做课后题。',
  '复习错题和整理笔记公式｜重做错题，整理本讲笔记、公式和适用条件。'
].join('\n');

// Titles follow the verified local 强化36讲 course index.
const advancedTitles = [
  "强化36讲 · 高数第1讲 · 函数极限与连续",
  "强化36讲 · 高数第2讲 · 数列极限",
  "强化36讲 · 高数第3讲 · 一元微分·概念",
  "强化36讲 · 高数第4讲 · 一元微分·计算",
  "强化36讲 · 高数第5讲 · 一元微分·应用一",
  "强化36讲 · 高数第6讲 · 一元微分·应用二·中值定理",
  "强化36讲 · 高数第7讲 · 一元微分·应用三",
  "强化36讲 · 高数第8讲 · 一元积分·概念与性质",
  "强化36讲 · 高数第9讲 · 一元积分·计算",
  "强化36讲 · 高数第10讲 · 一元积分·应用一",
  "强化36讲 · 高数第11讲 · 一元积分·应用二",
  "强化36讲 · 高数第12讲 · 一元积分·应用三",
  "强化36讲 · 高数第13讲 · 多元函数微分学",
  "强化36讲 · 高数第14讲 · 二重积分",
  "强化36讲 · 高数第15讲 · 微分方程",
  "强化36讲 · 高数第16讲 · 无穷级数",
  "强化36讲 · 高数第17讲 · 多元积分·预备",
  "强化36讲 · 高数第18讲 · 多元函数积分学",
  "强化36讲 · 线代第1讲 · 行列式",
  "强化36讲 · 线代第2讲 · 余子式与代数余子式",
  "强化36讲 · 线代第3讲 · 矩阵运算",
  "强化36讲 · 线代第4讲 · 矩阵的秩",
  "强化36讲 · 线代第5讲 · 线性方程组",
  "强化36讲 · 线代第6讲 · 向量组",
  "强化36讲 · 线代第7讲 · 特征值与特征向量",
  "强化36讲 · 线代第8讲 · 相似理论",
  "强化36讲 · 线代第9讲 · 二次型",
  "强化36讲 · 概率第1讲 · 随机事件和概率",
  "强化36讲 · 概率第2讲 · 一维随机变量及其分布",
  "强化36讲 · 概率第3讲 · 一维随机变量函数的分布",
  "强化36讲 · 概率第4讲 · 多维随机变量及其分布",
  "强化36讲 · 概率第5讲 · 多维随机变量函数的分布",
  "强化36讲 · 概率第6讲 · 数字特征",
  "强化36讲 · 概率第7讲 · 大数定律与中心极限定理",
  "强化36讲 · 概率第8讲 · 统计量及其分布",
  "强化36讲 · 概率第9讲 · 参数估计与假设检验"
];
const practiceId = 'math-1000-practice';

export function addCalculusLectures(state, now) {
  if (!state.goals.some(goal => goal[0] === 'g1')) throw new Error('请先确认考研目标，再添加高数卡片');
  const existing = new Set(state.tasks.map(task => task.id));
  const cards = [
    ...titles.map((title, i) => ({ id: lectureId(i), title: `第 ${i + 1} 讲 · ${title}`,
      resource: '张宇 · 高数基础18讲', action: actions })),
    { id: practiceId, title: '刷题', resource: '张宇《1000题》· 基础篇到拔高篇',
      action: '刷题｜分批独立作答，记下题号、做题数和答对数。', practiceCard: true },
    ...advancedTitles.map((title, i) => ({ id: 'math-advanced-' + String(i + 1).padStart(2, '0'), title,
      resource: '张宇 · 强化36讲', action: actions }))
  ];
  if (cards.every(card => existing.has(card.id))) return state;
  const skillId = 'calculus-basic';
  let next = state.skills.some(skill => skill[0] === skillId) ? state : {
    ...state, skills: [...state.skills, [skillId, '高数：基础18讲', '数学']]
  };
  for (const { id, title, resource, action, practiceCard } of cards) {
    if (existing.has(id)) continue;
    next = saveTask(next, {
      title,
      goalIds: ['g1'], skillId, minutes: 1,
      resource, position: '按上次记录的断点接续',
      action, stopCondition: practiceCard ? '完成这轮刷题' : '完成本讲三项'
    }, id, now);
    next.tasks[next.tasks.length - 1].courseCard = true;
    if (practiceCard) next.tasks[next.tasks.length - 1].practiceCard = true;
  }
  return next;
}

export function parsePracticeCounts(attempted, correct) {
  if (!/^\d+$/.test(attempted ?? '') || !/^\d+$/.test(correct ?? '')) throw new Error('请填写做题数和答对数');
  return validatePracticeCounts({ attempted: Number(attempted), correct: Number(correct) });
}

export function validatePracticeCounts(counts) {
  if (!counts || !Number.isInteger(counts.attempted) || counts.attempted < 1 || counts.attempted > 500 ||
      !Number.isInteger(counts.correct) || counts.correct < 0 || counts.correct > counts.attempted)
    throw new Error('做题数须为 1–500，答对数不能超过做题数');
  return { attempted: counts.attempted, correct: counts.correct };
}

export function summarizePractice(sessions, taskId) {
  return sessions.reduce((total, session) => {
    if (session.taskId === taskId && session.practiceCounts) {
      total.attempted += session.practiceCounts.attempted;
      total.correct += session.practiceCounts.correct;
    }
    return total;
  }, { attempted: 0, correct: 0 });
}

function lectureId(index) {
  return 'calculus-basic-' + String(index + 1).padStart(2, '0');
}

export function currentCourseCard(tasks) {
  return tasks.find(task => task.courseCard === true &&
    ['planned', 'in_progress', 'blocked'].includes(task.status));
}

export function visibleCourseTasks(tasks, selected) {
  const current = currentCourseCard(tasks);
  return selected.filter(task => task.courseCard !== true || task.id === current?.id ||
    ['done', 'cancelled', 'skipped'].includes(task.status));
}
