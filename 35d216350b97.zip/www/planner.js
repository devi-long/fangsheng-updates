import { addDays, assertDate, isDate } from './review.js';
import { taskBindings, needsTaskReview } from './tasks.js';

const PRIORITY = { critical: 0, high: 1, medium: 2, low: 3 };
const CLOSED = new Set(['completed', 'skipped', 'cancelled']);
const validMinutes = value => Number.isInteger(value) && value > 0;

export function dailyCapacity(state, today, capacityMinutes) {
  assertDate(today);
  if (!Number.isInteger(capacityMinutes) || capacityMinutes < 0) {
    throw new Error('今日容量须为非负整数分钟');
  }
  let actual = 0;
  for (const session of state.sessions || []) {
    if (session.date !== today) continue;
    if (!Number.isFinite(session.minutes) || session.minutes < 0) {
      throw new Error('学习记录的实际分钟数无效，请先检查原记录');
    }
    actual += session.minutes;
  }
  return {
    capacity: capacityMinutes, actual,
    remaining: Math.max(0, capacityMinutes - actual),
    overload: Math.max(0, actual - capacityMinutes)
  };
}

function goalPriority(state, task) {
  const binding = taskBindings(state, task);
  const matched = (state.goals || []).filter(goal => binding.goalIds.includes(goal[0]));
  return Math.min(3, ...matched.map(goal => PRIORITY[goal[3]] ?? 3));
}

export function isActiveReview(review) {
  return isDate(review.due) && !CLOSED.has(review.status);
}

export function dueReviews(state, today) {
  assertDate(today);
  return (state.reviews || []).filter(review => isActiveReview(review) && review.due <= today)
    .sort((a, b) => a.due.localeCompare(b.due) || String(a.id).localeCompare(String(b.id)));
}

// budget is already the remaining capacity. Never deduct sessions twice.
function fitTasks(state, budget, pauseNew = false) {
  const candidates = (state.tasks || []).filter(task =>
    ['planned', 'in_progress'].includes(task.status) && !task.courseCard && !task.quickTask && validMinutes(task.minutes) && !needsTaskReview(state, task) &&
    (!pauseNew || task.status === 'in_progress' || task.kind === 'repair') &&
    state.skillHandoffs?.[taskBindings(state, task).skillId]?.status !== 'deferred');
  candidates.sort((a, b) => goalPriority(state, a) - goalPriority(state, b));
  const selected = [];
  for (const task of candidates) {
    if (task.minutes > budget) continue;
    selected.push(task);
    budget -= task.minutes;
  }
  return selected;
}

export function generateDailyTasks(state, today, capacityMinutes) {
  return fitTasks(state, dailyCapacity(state, today, capacityMinutes).remaining);
}

export function generateDailyQueue(state, today, capacityMinutes) {
  return dailyQueuePlan(state, today, capacityMinutes).queue;
}

export function reviewBudgetForDay(state, today) {
  assertDate(today);
  const minutes = state.reviewBudgetByDate?.[today] ?? state.reviewBudgetMinutes ?? 60;
  if (!Number.isInteger(minutes) || minutes < 0 || minutes > 600) throw new Error('复习预算须为 0—600 的整数分钟');
  return minutes;
}

export function dailyQueuePlan(state, today, capacityMinutes) {
  let remaining = dailyCapacity(state, today, capacityMinutes).remaining;
  const reviewBudget = reviewBudgetForDay(state, today);
  const actualReview = (state.sessions || []).filter(session => session.date === today &&
    (session.activityType === 'review' || session.reviewId)).reduce((sum, session) => sum + session.minutes, 0);
  let reviewRemaining = Math.max(0, reviewBudget - actualReview);
  const due = dueReviews(state, today);
  const queue = [];
  for (const review of due) {
    const minutes = review.minutes === undefined ? 15 : review.minutes;
    if (!validMinutes(minutes) || minutes > remaining || minutes > reviewRemaining) continue;
    queue.push({ id: 'review:' + review.id, kind: 'review', title: review.title, minutes, reviewId: review.id });
    remaining -= minutes;
    reviewRemaining -= minutes;
  }
  const deferredReviews = due.length - queue.length;
  return {
    queue: [...queue, ...fitTasks(state, remaining, deferredReviews > 0)],
    reviewBudget, actualReview, reviewRemaining, deferredReviews, pauseNew: deferredReviews > 0
  };
}

export function scheduleReview(session, today) {
  // Free-text wording cannot establish mastery. Use explicit self-report.
  const interval = { success: 7, partial: 3, fail: 1 }[session.recall] || 1;
  return { sessionId: session.id, due: addDays(today, interval), interval, status: 'scheduled' };
}
