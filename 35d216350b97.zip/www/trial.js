export function summarizeTrialRows(rows) {
  const daysSet = new Set();
  const skillMap = new Map();
  const activityMap = new Map();
  let totalMinutes = 0;
  let sessionCount = 0;
  let attempts = 0;
  let rated = 0;
  let success = 0;
  let partial = 0;
  let fail = 0;
  let startupKnownCount = 0;
  let startupTotalMinutes = 0;
  const startupValues = [];

  for (const row of rows) {
    const minutes = row.minutes;
    totalMinutes += minutes;
    sessionCount += 1;
    daysSet.add(row.date);

    let skill = skillMap.get(row.skill);
    if (!skill) {
      skill = { name: row.skill, minutes: 0, count: 0, values: [] };
      skillMap.set(row.skill, skill);
    }
    skill.minutes += minutes;
    skill.count += 1;
    skill.values.push(minutes);

    let activity = activityMap.get(row.activity);
    if (!activity) {
      activity = { name: row.activity, minutes: 0, count: 0 };
      activityMap.set(row.activity, activity);
    }
    activity.minutes += minutes;
    activity.count += 1;

    if (row.isReview) {
      attempts += 1;
      const recall = row.recall;
      if (recall === 'success' || recall === 'partial' || recall === 'fail') {
        rated += 1;
        if (recall === 'success') success += 1;
        else if (recall === 'partial') partial += 1;
        else fail += 1;
      }
    }

    if (row.startupMinutes !== undefined && row.startupMinutes !== null) {
      startupKnownCount += 1;
      startupTotalMinutes += row.startupMinutes;
      startupValues.push(row.startupMinutes);
    }
  }

  const days = Array.from(daysSet).sort();

  const skills = Array.from(skillMap.values())
    .map((s) => ({
      name: s.name,
      minutes: s.minutes,
      count: s.count,
      medianMinutes: median(s.values),
    }))
    .sort((a, b) => b.minutes - a.minutes || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));

  const activities = Array.from(activityMap.values())
    .map((a) => ({ name: a.name, minutes: a.minutes, count: a.count }))
    .sort((a, b) => b.minutes - a.minutes || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));

  return {
    totalMinutes,
    sessionCount,
    days,
    skills,
    activities,
    review: {
      attempts,
      rated,
      success,
      partial,
      fail,
      independentRate: rated === 0 ? null : success / rated,
    },
    startup: {
      knownCount: startupKnownCount,
      totalMinutes: startupTotalMinutes,
      medianMinutes: startupValues.length === 0 ? null : median(startupValues),
    },
  };
}

function median(values) {
  const sorted = values.slice().sort((a, b) => a - b);
  const n = sorted.length;
  if (n === 0) return null;
  const mid = Math.floor(n / 2);
  return n % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

import { assertDate, isDate } from './review.js';

const ACTIVITIES = new Set(['lecture', 'practice', 'review', 'project', 'quiz', 'organize']);

function rowForSession(state, session) {
  const review = (state.reviews || []).find(item => item.id === session.reviewId);
  const evidence = (state.evidence || []).find(item => item.id === (session.evidenceId || review?.evidenceId));
  const origin = (state.sessions || []).find(item => item.id === review?.sessionId);
  const task = (state.tasks || []).find(item => item.id === (session.taskId || review?.taskId || evidence?.taskId || origin?.taskId));
  const snapshot = session.taskSnapshot;
  const skillId = snapshot?.skillId || evidence?.skillId || task?.skillId;
  const skill = snapshot?.skill || evidence?.skill || task?.skill ||
    (state.skills || []).find(item => item[0] === skillId)?.[1] || '待归属';
  const isReview = session.activityType === 'review' || !!session.reviewId;
  const startupMinutes = !isReview && Number.isInteger(session.startupMinutes) &&
    session.startupMinutes >= 0 && session.startupMinutes <= 720 ? session.startupMinutes : undefined;
  return {
    id: session.id, date: session.date, minutes: session.minutes, skill, isReview,
    activity: isReview ? 'review' : ACTIVITIES.has(session.activityType) ? session.activityType : 'unknown',
    recall: session.recall, startupMinutes
  };
}

export function buildTrialReport(state, today) {
  assertDate(today);
  const diagnostics = { invalid: 0, duplicate: 0, future: 0, invalidStartup: 0 };
  const seen = new Set();
  const valid = [];
  for (const session of state.sessions || []) {
    if (!session || typeof session.id !== 'string' || !session.id ||
      !isDate(session.date) || !Number.isInteger(session.minutes) || session.minutes < 1 || session.minutes > 720) {
      diagnostics.invalid++;
      continue;
    }
    if (session.date > today) { diagnostics.future++; continue; }
    if (seen.has(session.id)) { diagnostics.duplicate++; continue; }
    seen.add(session.id);
    valid.push(session);
  }
  const allDays = [...new Set(valid.map(session => session.date))].sort();
  const windowDays = allDays.slice(-5);
  const sessions = valid.filter(session => windowDays.includes(session.date))
    .sort((a, b) => a.date.localeCompare(b.date) ||
      String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
  const rows = sessions.map(session => rowForSession(state, session));
  const summary = summarizeTrialRows(rows);
  const skills = [...summary.skills];
  for (const skill of state.skills || []) {
    if (!skills.some(item => item.name === skill[1])) {
      skills.push({ name: skill[1], minutes: 0, count: 0, medianMinutes: null });
    }
  }
  const days = windowDays.map(date => {
    const items = rows.filter(row => row.date === date);
    const actual = items.reduce((sum, row) => sum + row.minutes, 0);
    const recorded = state.capacityByDate?.[date];
    const capacity = Number.isInteger(recorded) && recorded >= 0 ? recorded : null;
    return {
      date, minutes: actual, sessions: items.length, capacity,
      overload: capacity === null ? null : Math.max(0, actual - capacity)
    };
  });
  const tasks = new Map();
  const blockers = [];
  for (const session of sessions) {
    const row = rows.find(item => item.id === session.id);
    if (!row.isReview && session.startupMinutes !== undefined && row.startupMinutes === undefined) {
      diagnostics.invalidStartup++;
    }
    const title = session.taskSnapshot?.title || session.activity || '旧记录';
    if (typeof session.blocker === 'string' && session.blocker.trim()) {
      blockers.push({ date: session.date, title, reason: session.blocker.trim() });
    }
    if (row.isReview || !session.taskId) continue;
    const item = tasks.get(session.taskId) || {
      id: session.taskId, title, minutes: 0, count: 0, result: undefined
    };
    item.minutes += session.minutes;
    item.count++;
    item.result = session.taskStatusAfter;
    item.title = title;
    tasks.set(session.taskId, item);
  }
  const selectedIds = new Set(rows.map(row => row.id));
  const completedActions = [...tasks.values()].filter(task => task.result === 'done');
  return {
    ...summary, skills, days, diagnostics, totalObservedDays: allDays.length,
    completedActions, unresolvedActions: tasks.size - completedActions.length, blockers,
    evidenceCount: (state.evidence || []).filter(item => selectedIds.has(item.sessionId)).length,
    startup: { ...summary.startup, eligibleCount: rows.filter(row => !row.isReview).length },
    remainingDays: Math.max(0, 5 - windowDays.length)
  };
}
