import { saveTask } from './tasks.js';

const books = [
  ['ds', '数据结构', ['绪论', '线性表', '栈、队列和数组', '串', '树与二叉树', '图', '查找', '排序']],
  ['co', '计算机组成原理', ['计算机系统概述', '数据的表示和运算', '存储系统', '指令系统', '中央处理器', '总线', '输入/输出系统']],
  ['os', '操作系统', ['计算机系统概述', '进程与线程', '内存管理', '文件管理', '输入/输出管理']],
  ['net', '计算机网络', ['计算机网络体系结构', '物理层', '数据链路层', '网络层', '传输层', '应用层']]
];

export function addWangdaoChapters(state, now) {
  if (!state.goals.some(goal => goal[0] === 'g1')) return state;
  const existing = new Set(state.tasks.map(task => task.id));
  let next = state;
  for (const [code, subject, titles] of books) {
    const skillId = 'wangdao-27-' + code;
    for (const [index, title] of titles.entries()) {
      const chapter = index + 1;
      const id = skillId + '-' + chapter;
      if (existing.has(id)) continue;
      if (!next.skills.some(skill => skill[0] === skillId)) {
        next = { ...next, skills: [...next.skills, [skillId, subject + '：王道基础', subject]] };
      }
      next = saveTask(next, {
        title: `第 ${chapter} 章 · ${title}`, goalIds: ['g1'], skillId, minutes: 1,
        resource: `2027 王道《${subject}考研复习指导》第 ${chapter} 章`,
        position: '从本章开始，分次学习时按上次断点接续',
        action: [
          '听课或看书｜按本章目录推进，标出还不清楚的概念。',
          '手推例题和做题｜先独立做，再核对教材习题解析。',
          '复习错题和整理笔记｜重做代表性错题，记下本章易混点。'
        ].join('\n'),
        stopCondition: '完成本章三项'
      }, id, now);
      Object.assign(next.tasks.at(-1), { courseCard: true, courseLane: '408' });
    }
  }
  return next;
}
