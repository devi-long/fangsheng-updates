const TEXT_LIMITS = { resource: 1000, position: 1000, action: 2000, stopCondition: 2000, note: 4000 };
const STATUSES = ['unconfirmed', 'confirmed', 'deferred'];

function skillFor(state, skillId) {
  const skill = state.skills.find(item => item[0] === skillId);
  if (!skill) throw new Error('能力不存在');
  return skill;
}

export function handoffForSkill(state, skillId) {
  const skill = skillFor(state, skillId);
  const names = { s1: '数学：概率第4讲', s2: '英语：主语', s3: '408：图', s4: '离散：主析取范式', s5: 'Java：面向对象', s6: 'C++：面向对象', s7: '物理：电磁、光、量子', s8: 'Python：启动练习', s9: '算法：快速排序' };
  const known = names[skillId] === skill[1];
  const positions = {
    s1: '数学听到第4讲；现有线路暂按概率定位，分科和具体视频断点待核对。',
    s2: '语法应该学到主语；课程版本和视频断点待核对。',
    s3: '数据结构学到图；实际小节和视频断点待核对。',
    s4: '离散数学学到主析取范式。',
    s5: 'Java 面向对象差不多学完，具体练习位置待核对。',
    s6: 'C++ 准备进入面向对象。',
    s7: '大学物理尚未开始；范围是电磁学、光学、量子物理。',
    s8: 'Python 尚未开始。',
    s9: '本轮算法学习尚未开始。'
  };
  return state.skillHandoffs?.[skillId] || {
    resource: '', position: known ? positions[skillId] : '', action: '核对当前资料与实际断点',
    stopCondition: '保存课节、题号、代码位置或访问阻碍',
    note: known ? '起点根据本人在本次规划中的说明保留，课程可访问性与细节待本人核对。' : '实际起点待本人填写与核对。',
    status: 'unconfirmed'
  };
}

export function saveHandoff(state, skillId, input, now) {
  skillFor(state, skillId);
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('交接内容格式无效');
  for (const key of Object.keys(input)) {
    if (![...Object.keys(TEXT_LIMITS), 'status'].includes(key)) throw new Error('不允许修改交接字段 ' + key);
  }
  if (!STATUSES.includes(input.status)) throw new Error('交接状态无效');
  const next = {};
  for (const [key, limit] of Object.entries(TEXT_LIMITS)) {
    if (typeof input[key] !== 'string' || input[key].length > limit) throw new Error('交接字段 ' + key + ' 类型或长度无效');
    next[key] = input[key].trim();
    if (input.status === 'confirmed' && key !== 'note' && !next[key]) throw new Error('确认起点前请填写资料、位置、动作和停止条件');
  }
  const old = state.skillHandoffs?.[skillId];
  return {
    ...state, skillHandoffs: { ...state.skillHandoffs, [skillId]: {
      ...next, status: input.status, updatedAt: now,
      ...(old?.lastSessionId ? { lastSessionId: old.lastSessionId } : {})
    } }
  };
}

export function handoffTaskInput(state, skillId, handoff, goalIds = []) {
  const skill = skillFor(state, skillId);
  if (!STATUSES.includes(handoff.status)) throw new Error('交接状态无效');
  if (handoff.status === 'deferred') throw new Error('此项暂缓启动，需要先调整交接状态');
  const confirmed = handoff.status === 'confirmed';
  return {
    title: (confirmed ? '继续 · ' : '核对起点 · ') + skill[1],
    goalIds: [...goalIds], skillId, minutes: 30, resource: handoff.resource,
    position: handoff.position || '待核对',
    action: confirmed ? handoff.action : '核对实际课程资料、访问情况和本人断点',
    stopCondition: confirmed ? handoff.stopCondition : '保存真实课节、题号、视频位置或访问阻碍'
  };
}
