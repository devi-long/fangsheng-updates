// Application-shell caching is independent of learning records and assignments.
export function startOfflineSupport({ onStatus, onUpdate, onInstall, canUpdate = () => true }) {
  let registration = null;
  let installPrompt = null;
  let activating = false;
  let pendingReload = false;
  let reloading = false;
  let hadController = !!navigator.serviceWorker?.controller;
  const watchedWorkers = new WeakSet();
  function retryUpdate() {
    if (reloading || !canUpdate()) return false;
    if (pendingReload) {
      reloading = true;
      onUpdate(false);
      location.reload();
      return true;
    }
    if (activating || !registration?.waiting) return false;
    activating = true;
    try { registration.waiting.postMessage({ type: 'ACTIVATE_UPDATE' }); }
    catch (error) { activating = false; throw error; }
    return true;
  }
  function tryAutomaticUpdate() {
    try { retryUpdate(); }
    catch (error) {
      onStatus('更新暂未完成，可稍后重试');
      console.warn('自动更新失败', error);
    }
  }
  const api = {
    async install() {
      if (!installPrompt) return false;
      const prompt = installPrompt;
      installPrompt = null;
      onInstall(false);
      await prompt.prompt();
      await prompt.userChoice;
      return true;
    },
    applyUpdate: retryUpdate,
    retryUpdate: tryAutomaticUpdate
  };
  if (!('serviceWorker' in navigator) || !globalThis.isSecureContext) {
    onStatus('此环境暂不支持离线打开');
    return api;
  }
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
    onInstall(true);
  });
  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    onInstall(false);
  });
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    // Other tabs may activate an update too. Never reload an open editor.
    if (hadController) {
      pendingReload = true;
      onUpdate(true);
      tryAutomaticUpdate();
    }
    hadController = true;
  });
  function announceUpdate() {
    if (registration?.waiting) {
      onUpdate(true);
      tryAutomaticUpdate();
    }
  }
  function watch(worker) {
    if (!worker || watchedWorkers.has(worker)) return;
    watchedWorkers.add(worker);
    worker.addEventListener('statechange', () => {
      if (worker.state === 'installed' && navigator.serviceWorker.controller) announceUpdate();
      if (worker.state === 'redundant') activating = false;
    });
  }
  async function connect() {
    try {
      let updateUnavailable = false;
      onStatus(navigator.onLine ? '正在准备离线资源' : '正在读取离线资源');
      try {
        registration = navigator.onLine
          ? await navigator.serviceWorker.register('./service-worker.js', { updateViaCache: 'none' })
          : await navigator.serviceWorker.getRegistration();
      } catch (error) {
        registration = await navigator.serviceWorker.getRegistration();
        if (!registration?.active) throw error;
        updateUnavailable = true;
      }
      if (!registration) { onStatus('请联网打开一次，以准备离线资源'); return; }
      announceUpdate();
      watch(registration.installing);
      registration.addEventListener('updatefound', () => watch(registration.installing));
      if (navigator.onLine && !updateUnavailable) {
        try { await registration.update(); }
        catch (error) { updateUnavailable = true; console.warn('检查应用更新失败', error); }
      }
      await navigator.serviceWorker.ready;
      onStatus(!navigator.onLine ? '当前离线，本地记录仍可使用'
        : updateUnavailable ? '离线缓存可用，暂时无法检查更新' : '离线资源已就绪');
    } catch (error) {
      onStatus('离线资源准备失败，当前页面仍可使用');
      console.warn('离线外壳初始化失败', error);
    }
  }
  window.addEventListener('offline', () => onStatus('当前离线，本地记录仍可使用'));
  window.addEventListener('online', () => {
    onStatus('已恢复连接');
    if (registration) registration.update().catch(error => console.warn('检查应用更新失败', error));
    else connect();
  });
  connect();
  return api;
}
