import { normalizeEvidenceLevel } from './evidence-levels.js';

export function createEvidenceFromSession(session, task) {
  if (!session || !task || session.evidenceType === 'none' || !String(session.evidence || '').trim()) return null;
  const now = new Date().toISOString();
  return { id: `evidence-${session.id}-${Date.now()}`, createdAt: now, updatedAt: now, kind: session.evidenceType, level: normalizeEvidenceLevel(session.evidenceLevel || 'unknown'), title: task.title, content: session.evidence, skill: task.skill, skillId: task.skillId, goalIds: task.goalIds ? [...task.goalIds] : undefined, taskId: task.id, sessionId: session.id };
}

export function evidenceForSkill(state, skillId) {
  const skill = state.skills.find(item => item[0] === skillId);
  if (!skill) throw new Error('能力不存在');
  return (state.evidence || []).filter(item => item.skillId ? item.skillId === skillId : item.skill === skill[1]);
}

export function skillEvidenceSummary(skills, evidence) {
  const result = {};
  for (const skill of Array.isArray(skills) ? skills : []) if (typeof skill === 'string') result[skill] = { count: 0, kinds: [] };
  for (const item of Array.isArray(evidence) ? evidence : []) {
    if (!item || typeof item.skill !== 'string') continue;
    result[item.skill] ||= { count: 0, kinds: [] };
    result[item.skill].count += 1;
    if (item.kind && !result[item.skill].kinds.includes(item.kind)) result[item.skill].kinds.push(item.kind);
  }
  return result;
}
