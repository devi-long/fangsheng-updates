import { createBackup } from './backup.js';

export function canonicalStateJson(state) {
  const copy = createBackup(state, '2000-01-01T00:00:00.000Z').state;
  if (copy.sources?.length === 0) delete copy.sources;
  return JSON.stringify(copy, (key, value) => {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const sorted = {};
      for (const k of Object.keys(value).sort()) sorted[k] = value[k];
      return sorted;
    }
    return value;
  });
}

export async function fingerprintState(state, subtle = globalThis.crypto?.subtle) {
  if (!subtle) return null;
  const bytes = new TextEncoder().encode(canonicalStateJson(state));
  const digest = await subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, '0')).join('');
}


export function formatBytes(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return '未提供';
  const units = ['B', 'KiB', 'MiB', 'GiB'];
  let size = value, index = 0;
  while (size >= 1024 && index < units.length - 1) { size /= 1024; index++; }
  return (index === 0 ? Math.round(size) : Number(size.toFixed(1))) + ' ' + units[index];
}

export function compareBackup(hash, currentHash, receipt) {
  if (!hash) return 'unavailable';
  if (hash === currentHash) return 'current';
  if (hash === receipt?.sha256) return 'last-export';
  return currentHash ? 'different' : 'unavailable';
}

export async function getStorageHealth(repository, manager = globalThis.navigator?.storage) {
  const labels = ['读取保存版本', '读取导出标记', '读取核对标记', '读取站点占用', '读取持久存储状态'];
  const results = await Promise.allSettled([
    () => repository.snapshot(), () => repository.readMetadata('backup-receipt'),
    () => repository.readMetadata('backup-verification'),
    () => manager?.estimate ? manager.estimate() : null,
    () => manager?.persisted ? manager.persisted() : null
  ].map(read => Promise.resolve().then(read)));
  const value = index => results[index].status === 'fulfilled' ? results[index].value : null;
  const estimate = value(3);
  return {
    revision: value(0)?.revision ?? null, receipt: value(1), verification: value(2),
    usage: Number.isFinite(estimate?.usage) && estimate.usage >= 0 ? estimate.usage : null,
    quota: Number.isFinite(estimate?.quota) && estimate.quota >= 0 ? estimate.quota : null,
    persistent: typeof value(4) === 'boolean' ? value(4) : null,
    canPersist: typeof manager?.persist === 'function',
    errors: results.flatMap((result, index) => result.status === 'rejected' ? [labels[index] + '失败：' + (result.reason?.message || String(result.reason))] : [])
  };
}
