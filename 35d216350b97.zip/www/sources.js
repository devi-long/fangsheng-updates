export const SOURCE_TYPES = Object.freeze({
  course: '课程',
  book: '教材/书籍',
  problem: '题目集',
  code: '代码仓库',
  video: '视频课程',
  other: '其他'
});

const INPUT_FIELDS = Object.freeze(['type', 'title', 'locator', 'url', 'notes']);
const SOURCE_FIELDS = Object.freeze(['id', ...INPUT_FIELDS, 'createdAt', 'updatedAt']);
const LIMITS = Object.freeze({ id: 200, title: 200, locator: 400, url: 2048, notes: 4000 });
const MAX_SOURCES = 20000;

function plain(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
    ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw new Error(label + '必须是普通对象');
  return value;
}
function text(value, label, max, required = true) {
  if (typeof value !== 'string') throw new Error(label + '须为文本');
  const trimmed = value.trim();
  if (required && !trimmed) throw new Error('请填写' + label);
  if (trimmed.length > max) throw new Error(label + '最多 ' + max + ' 字');
  return trimmed;
}
function iso(value, label) {
  if (typeof value !== 'string' || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) {
    throw new Error(label + '时间无效');
  }
  return value;
}
function url(value) {
  const trimmed = text(value, '资料链接', LIMITS.url, false);
  if (!trimmed) return '';
  let parsed;
  try { parsed = new URL(trimmed); } catch { throw new Error('资料链接必须是有效的 http/https 地址'); }
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('资料链接必须是有效的 http/https 地址');
  return trimmed;
}

export function normalizeSourceInput(input) {
  plain(input, '资料来源');
  for (const key of Object.keys(input)) if (!INPUT_FIELDS.includes(key)) throw new Error('不允许修改资料来源字段 ' + key);
  if (typeof input.type !== 'string' || !Object.hasOwn(SOURCE_TYPES, input.type)) throw new Error('资料来源类型无效');
  const normalized = {
    type: input.type,
    title: text(input.title, '资料名称', LIMITS.title),
    locator: text(input.locator, '资料定位', LIMITS.locator),
    url: url(input.url === undefined ? '' : input.url)
  };
  const notes = text(input.notes === undefined ? '' : input.notes, '资料备注', LIMITS.notes, false);
  if (notes) normalized.notes = notes;
  if (!normalized.url) delete normalized.url;
  return normalized;
}

export function validateSource(source) {
  plain(source, '资料来源');
  if (Object.keys(source).some(key => !SOURCE_FIELDS.includes(key))) throw new Error('资料来源含不支持的字段');
  const id = text(source.id, '资料来源 ID', LIMITS.id);
  if (source.id !== id) throw new Error('资料来源 ID 含多余空白');
  const normalized = normalizeSourceInput({ type: source.type, title: source.title, locator: source.locator, url: source.url, notes: source.notes });
  const createdAt = iso(source.createdAt, '资料创建');
  const updatedAt = iso(source.updatedAt, '资料更新');
  return { id, ...normalized, createdAt, updatedAt };
}

export function validateSourceReferences(state) {
  const sources = state.sources === undefined ? [] : state.sources;
  if (!Array.isArray(sources) || sources.length > MAX_SOURCES) throw new Error('资料来源列表无效或过大');
  const ids = new Set();
  for (const source of sources) {
    const { id } = validateSource(source);
    if (ids.has(id)) throw new Error('资料来源 ID 重复');
    ids.add(id);
  }
  for (const task of state.tasks) {
    if (task?.sourceId != null && !ids.has(task.sourceId)) throw new Error('任务引用了不存在的资料来源');
  }
}

export function createSource(input, id, now) {
  const sourceId = text(id, '资料来源 ID', LIMITS.id);
  const timestamp = iso(now, '资料来源');
  return { id: sourceId, ...normalizeSourceInput(input), createdAt: timestamp, updatedAt: timestamp };
}

export function saveSource(state, input, id, now, existingId = null) {
  if (!state || !Array.isArray(state.sources)) throw new Error('资料来源状态格式无效');
  const nextSource = createSource(input, id, now);
  if (existingId === null) {
    if (state.sources.length >= MAX_SOURCES) throw new Error('资料来源已达数量上限');
    if (state.sources.some(source => source.id === nextSource.id)) throw new Error('资料来源已存在，请重新打开表单');
    return { ...state, sources: [...state.sources, nextSource] };
  }
  const current = state.sources.find(source => source.id === existingId);
  if (!current) throw new Error('资料来源不存在，请刷新后重试');
  return { ...state, sources: state.sources.map(source => source.id === existingId ? { ...nextSource, id: existingId, createdAt: source.createdAt } : source) };
}

export function sourceLabel(source) {
  if (!source || typeof source !== 'object') return '';
  return [source.title, source.locator].filter(value => typeof value === 'string' && value.trim()).join(' · ');
}
