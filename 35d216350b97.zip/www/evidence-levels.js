export const EVIDENCE_LEVELS = Object.freeze({
  guided: '参考后完成',
  independent: '独立完成',
  delayed: '延迟回忆',
  transfer: '迁移应用',
  unknown: '待核验'
});
const VALID = Object.keys(EVIDENCE_LEVELS);
export function normalizeEvidenceLevel(value) {
  if (typeof value !== 'string' || !VALID.includes(value)) throw new Error('学习证据等级无效');
  return value;
}
export function evidenceLevelLabel(value) { return EVIDENCE_LEVELS[value] ?? EVIDENCE_LEVELS.unknown; }
