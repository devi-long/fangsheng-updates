export const CORRECTION_FIELD_LABELS = {
  minutes: '实际分钟数', startupMinutes: '启动等待', result: '学习结果', blocker: '卡住原因', note: '回忆备注'
};

const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
function plain(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) &&
    [Object.prototype, null].includes(Object.getPrototypeOf(value));
}
function sessionCheck(session) {
  if (!plain(session)) throw new Error('学习记录必须是普通对象');
}
function integer(raw, label, min, max) {
  if (typeof raw !== 'string') throw new Error(label + '必须是字符串');
  const value = raw.trim();
  if (!/^\d+$/.test(value)) throw new Error(label + '必须是十进制整数');
  const number = Number(value);
  if (!Number.isInteger(number) || number < min || number > max) throw new Error(label + `必须在 ${min} 到 ${max} 之间`);
  return number;
}
function text(raw, label, max, required) {
  if (typeof raw !== 'string') throw new Error(label + '必须是字符串');
  const value = raw.trim();
  if (required && !value) throw new Error(label + '不能为空');
  if (value.length > max) throw new Error(label + `不能超过 ${max} 字符`);
  return value;
}
export function correctionFields(session) {
  sessionCheck(session);
  return session.activityType === 'review' || !!session.reviewId
    ? ['minutes', 'note'] : ['minutes', 'startupMinutes', 'result', 'blocker'];
}
export function normalizeCorrectionInput(session, input) {
  sessionCheck(session);
  if (!plain(input)) throw new Error('纠正内容必须是普通对象');
  const fields = correctionFields(session), expected = [...fields, 'reason'];
  for (const key of Object.keys(input)) {
    if (DANGEROUS_KEYS.has(key)) throw new Error('纠正内容包含危险字段 ' + key);
    if (!expected.includes(key)) throw new Error('纠正内容包含未知字段 ' + key);
  }
  for (const key of expected) if (!Object.hasOwn(input, key)) throw new Error('纠正内容缺少字段 ' + key);
  const values = {};
  for (const field of fields) {
    const label = CORRECTION_FIELD_LABELS[field];
    if (field === 'minutes') values.minutes = integer(input[field], label, 1, 720);
    else if (field === 'startupMinutes') {
      if (typeof input[field] !== 'string') throw new Error(label + '必须是字符串');
      values.startupMinutes = input[field].trim() === '' ? null : integer(input[field], label, 0, 720);
    } else if (field === 'result') values.result = text(input[field], label, 8000, true);
    else values[field] = text(input[field], label, 8000, false);
  }
  const reason = text(input.reason, '纠正原因', 1000, true);
  return { values, reason };
}
