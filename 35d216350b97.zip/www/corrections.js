import { correctionFields, normalizeCorrectionInput } from './correction-input.js';

function copy(value) { return structuredClone(value); }
function validId(value, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > 200) throw new Error(label + '无效');
}
function validTime(value) {
  if (typeof value !== 'string' || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) throw new Error('纠正时间无效');
}
function currentValue(session, field) {
  return Object.hasOwn(session, field) ? session[field] : null;
}
export function applySessionCorrection(state, sessionId, input, reason, now, correctionId) {
  if (!state || !Array.isArray(state.sessions)) throw new Error('学习记录状态无效');
  validId(sessionId, '学习记录 ID');
  validId(correctionId, '纠正 ID');
  validTime(now);
  if ((state.corrections || []).some(item => item.id === correctionId)) throw new Error('纠正记录 ID 已存在');
  const index = state.sessions.findIndex(item => item?.id === sessionId);
  if (index < 0) throw new Error('学习记录不存在');
  const session = state.sessions[index];
  const normalized = normalizeCorrectionInput(session, { ...input, reason });
  const before = {}, after = {};
  for (const field of correctionFields(session)) {
    before[field] = currentValue(session, field);
    after[field] = normalized.values[field];
  }
  if (JSON.stringify(before) === JSON.stringify(after)) throw new Error('纠正内容没有变化');
  const nextSession = copy(session);
  for (const field of correctionFields(session)) {
    if (field === 'startupMinutes' && after[field] === null) delete nextSession[field];
    else nextSession[field] = after[field];
  }
  const record = { id: correctionId, sessionId, createdAt: now, reason: normalized.reason, before, after };
  const sessions = state.sessions.slice(); sessions[index] = nextSession;
  return { ...state, sessions, corrections: [...(state.corrections || []), record] };
}
export function correctionsForSession(state, sessionId) {
  validId(sessionId, '学习记录 ID');
  return (state?.corrections || []).filter(item => item.sessionId === sessionId).map(copy);
}
