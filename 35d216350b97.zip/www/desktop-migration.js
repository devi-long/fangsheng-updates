import { DATABASE_NAME, STORE_NAME, MAIN_KEY, LEGACY_KEY, validateEnvelope, validateMetadata } from './repository.js';
import { validateDraft, draftKey } from './drafts.js';
import { validateLearningState } from './backup.js';
import { MAX_STATE_CHARS, MAX_BACKUP_CHARS, MAX_BACKUP_BYTES } from './limits.js';

const SOURCE_ORIGIN = 'http://127.0.0.1:8890';
function exact(value, keys, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)) ||
      Object.keys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value, key))) throw new Error(label + '字段不完整或格式无效');
}
function safeTree(value, depth = 0) {
  if (depth > 24) throw new Error('迁移文件嵌套过深');
  if (!value || typeof value !== 'object') return;
  if (!Array.isArray(value) && ![Object.prototype,null].includes(Object.getPrototypeOf(value))) throw new Error('迁移内容必须为普通数据');
  for (const key of Object.keys(value)) {
    if (['__proto__','constructor','prototype'].includes(key)) throw new Error('迁移文件含不支持的字段');
    const descriptor = Object.getOwnPropertyDescriptor(value,key);
    if (!Object.hasOwn(descriptor,'value')) throw new Error('迁移内容不能包含访问器');
    safeTree(descriptor.value,depth+1);
  }
}
function bounded(text) {
  if (typeof text !== 'string') throw new Error('迁移文件必须是文本');
  if (text.length > MAX_BACKUP_CHARS || new TextEncoder().encode(text).byteLength > MAX_BACKUP_BYTES) throw new Error('迁移文件超过大小上限');
}
export function parseDesktopTransfer(text, { expectedOrigin = SOURCE_ORIGIN } = {}) {
  bounded(text);
  let data;
  try { data=JSON.parse(text); } catch { throw new Error('迁移文件 JSON 解析失败'); }
  safeTree(data);
  exact(data,['format','version','capturedAt','sourceOrigin','legacyRaw','entries'],'迁移文件');
  if (data.format !== 'fangsheng-desktop-transfer' || data.version !== 1) throw new Error('不支持此迁移文件格式或版本');
  if (data.sourceOrigin !== expectedOrigin) throw new Error('迁移文件来源地址不匹配');
  if (typeof data.capturedAt !== 'string' || !Number.isFinite(Date.parse(data.capturedAt)) || new Date(data.capturedAt).toISOString() !== data.capturedAt) throw new Error('迁移时间无效');
  if (data.legacyRaw !== null && (typeof data.legacyRaw !== 'string' || data.legacyRaw.length > MAX_STATE_CHARS)) throw new Error('旧版原文类型无效或过大');
  if (!Array.isArray(data.entries)) throw new Error('迁移记录必须是列表');
  const seen=new Set();
  for (const entry of data.entries) {
    exact(entry,['key','value'],'迁移记录');
    const {key,value}=entry;
    if (typeof key !== 'string' || seen.has(key)) throw new Error('迁移记录键重复或无效');
    seen.add(key);
    if (key === MAIN_KEY) {
      exact(value,['revision','raw','legacyRaw'],'主记录');
      validateEnvelope(value);
      if (value.raw !== null) {
        let state;
        try { state=JSON.parse(value.raw); } catch { throw new Error('主记录原文 JSON 无效，请先在原网页版检查数据'); }
        validateLearningState(state);
      }
    } else if (key.startsWith('draft:')) {
      validateDraft(value);
      if (key !== draftKey(value.id)) throw new Error('草稿键与 ID 不一致');
    } else if (['backup-receipt','backup-verification'].includes(key)) validateMetadata(key,value);
    else throw new Error('迁移文件含未知记录键：'+key);
  }
  return data;
}
function checkedTransfer(transfer, options) {
  safeTree(transfer);
  return parseDesktopTransfer(JSON.stringify(transfer),options);
}
function readLegacy() {
  try { return localStorage.getItem(LEGACY_KEY); }
  catch { throw new Error('无法读取本机旧版存储，请检查存储权限'); }
}
function openDatabase(create) {
  if (!globalThis.indexedDB) return Promise.reject(new Error('当前环境无法使用本地数据库'));
  return new Promise((resolve,reject)=>{
    let missing=false, rejected=false;
    const request=indexedDB.open(DATABASE_NAME,1);
    request.onupgradeneeded=()=>{
      if (!create) { missing=true; request.transaction.abort(); return; }
      if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME);
    };
    request.onerror=()=>missing ? resolve(null) : reject(new Error('打开迁移数据库失败：'+(request.error?.message||'未知错误')));
    request.onblocked=()=>{rejected=true;reject(new Error('数据库被其他窗口占用，请关闭后重试'));};
    request.onsuccess=()=>{
      if(rejected){request.result.close();return;}
      if(!request.result.objectStoreNames.contains(STORE_NAME)){request.result.close();reject(new Error('数据库记录表缺失，请先检查原数据'));return;}
      request.result.onversionchange=()=>request.result.close();
      resolve(request.result);
    };
  });
}
export async function captureDesktopTransfer({ expectedOrigin = SOURCE_ORIGIN } = {}) {
  if(location.origin !== expectedOrigin) throw new Error('请在原网页版地址打开此迁移页面');
  const legacyRaw=readLegacy(), db=await openDatabase(false);
  let entries=[];
  if(db) {
    try {
      entries=await new Promise((resolve,reject)=>{
        const rows=[], tx=db.transaction(STORE_NAME,'readonly'), request=tx.objectStore(STORE_NAME).openCursor();
        request.onsuccess=()=>{const cursor=request.result;if(cursor){rows.push({key:cursor.key,value:cursor.value});cursor.continue();}};
        tx.oncomplete=()=>resolve(rows);
        tx.onabort=()=>reject(new Error('读取原数据失败：'+(tx.error?.message||'事务已中止')));
      });
    } finally { db.close(); }
  }
  if(readLegacy() !== legacyRaw) throw new Error('原网页版数据正在变化，请停止编辑后重新导出');
  return checkedTransfer({format:'fangsheng-desktop-transfer',version:1,capturedAt:new Date().toISOString(),sourceOrigin:expectedOrigin,legacyRaw,entries},{expectedOrigin});
}
export async function importDesktopTransfer(transfer, options = {}) {
  const data=checkedTransfer(transfer,options);
  if(readLegacy() !== null) throw new Error('桌面版已有旧版记录，不能覆盖迁移；请到数据页核对备份');
  const db=await openDatabase(true);
  try {
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_NAME,'readwrite'), store=tx.objectStore(STORE_NAME);
      let reason, wroteLegacy=false;
      const fail=error=>{reason=error;try{tx.abort();}catch{reject(error);}};
      tx.onabort=()=>{
        if(wroteLegacy) {
          try {
            if(readLegacy()===data.legacyRaw) localStorage.removeItem(LEGACY_KEY);
            else throw new Error('旧版存储已被其他窗口改变');
          } catch(error) { reject(new Error((reason?.message||'迁移失败')+'；旧版原文回滚失败：'+error.message));return; }
        }
        reject(reason||new Error('迁移保存失败：'+(tx.error?.message||'事务已中止')));
      };
      tx.oncomplete=()=>resolve();
      const count=store.count();
      count.onsuccess=()=>{
        try {
          if(count.result || readLegacy()!==null) throw new Error('桌面版已有记录，不能覆盖迁移；请到数据页核对备份');
          if(data.legacyRaw!==null) { localStorage.setItem(LEGACY_KEY,data.legacyRaw); wroteLegacy=true; }
          for(const {key,value} of data.entries) store.add(value,key);
        }catch(error){fail(error);}
      };
    });
  } finally { db.close(); }
  return summarizeDesktopTransfer(data,options);
}
export function summarizeDesktopTransfer(transfer, options = {}) {
  const data=checkedTransfer(transfer,options), main=data.entries.find(entry=>entry.key===MAIN_KEY)?.value;
  let state=null,legacyNeedsReview=false;
  const raw=main?.raw ?? data.legacyRaw;
  if(raw!==null) {
    try{state=validateLearningState(JSON.parse(raw));}catch{legacyNeedsReview=true;}
  }
  return {
    capturedAt:data.capturedAt,sourceOrigin:data.sourceOrigin,records:data.entries.length,revision:main?.revision??0,
    tasks:state?.tasks.length??(legacyNeedsReview?null:0),reviews:state?.reviews.length??(legacyNeedsReview?null:0),sessions:state?.sessions.length??(legacyNeedsReview?null:0),
    goals:state?.goals.length??(legacyNeedsReview?null:0),evidence:state?.evidence?.length??0,
    drafts:data.entries.filter(entry=>entry.key.startsWith('draft:')).length,
    metadata:data.entries.filter(entry=>['backup-receipt','backup-verification'].includes(entry.key)).length,
    hasRecovery:!!state?.recovery,hasLegacy:data.legacyRaw!==null,legacyNeedsReview
  };
}
