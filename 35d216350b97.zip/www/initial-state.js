// Known exam goals and reported starting points remain reference data.
// No daily assignments or course sequence are initialized here.
export function createInitialState() {
  const state = {capacity:480,goals:[['g1','考研初试','2028 年末','critical'],['g2','2027 年 1 月期末','离散、数据结构、Java、概率、物理、C++','high'],['g3','四级','2026-12-12','high'],['g4','CSP','2026-12，目标 200—300 分','high'],['g5','蓝桥杯','C/C++ 大学 A 组，目标国奖','medium'],['g6','XCPC','队伍与选拔待补','low']],skills:[['s1','数学：概率第4讲','数学'],['s2','英语：主语','英语'],['s3','408：图','408'],['s4','离散：主析取范式','期末'],['s5','Java：面向对象','期末'],['s6','C++：面向对象','期末'],['s7','物理：电磁、光、量子','期末'],['s8','Python：启动练习','副线'],['s9','算法：快速排序','竞赛']],tasks:[],reviews:[],sessions:[],evidence:[],corrections:[],sources:[]};
  state.capacity = 0;
  return state;
}
