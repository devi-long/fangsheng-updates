import { saveTask } from './tasks.js';

const courses = [
  ['vocab', '词汇', 10, '刘晓艳《你还在“背”单词吗？》', [
    '认词｜按本单元词表学习常考词义。',
    '回忆｜遮住释义，看英文回想中文。',
    '复习｜标出忘掉或混淆的词，留待复测。'
  ]],
  ['grammar', '语法', 6, '刘晓艳长难句', [
    '听课｜按本单元课程顺序学习。',
    '拆句｜合上讲义，独立找句子主干和修饰关系。',
    '订正｜记录拆错的句子和错因，留待复习。'
  ]]
];

export function addEnglishUnits(state, now) {
  if (!state.goals.some(goal => goal[0] === 'g1')) return state;
  const existing = new Set(state.tasks.map(task => task.id));
  let next = state;
  for (const [lane, label, count, resource, actions] of courses) {
    const skillId = 'english-' + lane;
    for (let unit = 1; unit <= count; unit++) {
      const id = skillId + '-' + unit;
      if (existing.has(id)) continue;
      if (!next.skills.some(skill => skill[0] === skillId)) {
        next = { ...next, skills: [...next.skills, [skillId, '英语：' + label, '英语']] };
      }
      next = saveTask(next, {
        title: `${label} · 第 ${unit} 单元${lane === 'grammar' && unit === 1 ? ' · 简单句' : ''}`,
        goalIds: ['g1'], skillId, minutes: 1, resource,
        position: '从本单元开头开始，分次学习时按断点接续',
        action: actions.join('\n'), stopCondition: '完成本单元三项'
      }, id, now);
      Object.assign(next.tasks.at(-1), { courseCard: true, courseLane: lane });
    }
  }
  return next;
}
