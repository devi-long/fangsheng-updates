const ALLOWED = ['title', 'goalIds', 'skillId', 'minutes', 'resource', 'sourceId', 'position', 'action', 'stopCondition'];

function text(value, label, maximum, required = true) {
  if (typeof value !== 'string') throw new Error(label + '须为文本');
  const trimmed = value.trim();
  if (required && !trimmed) throw new Error('请填写' + label);
  if (trimmed.length > maximum) throw new Error(label + '最多 ' + maximum + ' 字');
  return trimmed;
}

export function normalizeTaskInput(state, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('任务内容格式无效');
  for (const key of Object.keys(input)) {
    if (!ALLOWED.includes(key)) throw new Error('不允许修改任务字段 ' + key);
  }
  const goalMap = new Map(state.goals.map(goal => [goal[0], goal[1]]));
  const skillMap = new Map(state.skills.map(skill => [skill[0], skill[1]]));
  const sourceIds = new Set((state.sources || []).map(source => source.id));
  if (!Array.isArray(input.goalIds) || !input.goalIds.length ||
    input.goalIds.some(id => typeof id !== 'string' || !goalMap.has(id))) {
    throw new Error('请至少选择一个已有目标');
  }
  if (typeof input.skillId !== 'string' || !skillMap.has(input.skillId)) throw new Error('请选择已有能力');
  if (!Number.isInteger(input.minutes) || input.minutes < 1 || input.minutes > 480) {
    throw new Error('投入上限须为 1—480 的整数分钟');
  }
  const goalIds = [...new Set(input.goalIds)];
  const sourceId = input.sourceId === undefined ? undefined : text(input.sourceId, '资料来源 ID', 200, false);
  if (sourceId && !sourceIds.has(sourceId)) throw new Error('资料来源不存在，请先核对资料库');
  return {
    title: text(input.title, '任务标题', 160),
    goalIds, skillId: input.skillId, minutes: input.minutes,
    resource: text(input.resource, '资料位置', 1000, false),
    ...(sourceId ? { sourceId } : {}),
    position: text(input.position, '实际起点', 1000),
    action: text(input.action, '下一步动作', 2000),
    stopCondition: text(input.stopCondition, '停止条件', 2000),
    goal: goalIds.map(id => goalMap.get(id)).join(' / '),
    skill: skillMap.get(input.skillId)
  };
}

// Read old display fields without rewriting stored learning facts.
export function taskBindings(state, task) {
  const names = String(task.goal || '').split('/').map(name => name.trim());
  return {
    goalIds: task.goalIds ?? (state.goals || []).filter(goal =>
      names.includes(goal[0]) || names.includes(goal[1]) || (goal[0] === 'g2' && names.includes('期末'))).map(goal => goal[0]),
    skillId: task.skillId ?? (state.skills || []).find(skill => skill[1] === task.skill)?.[0] ?? ''
  };
}

export function hasTaskHistory(state, id) {
  return ['sessions', 'evidence', 'reviews'].some(key => (state[key] || []).some(item => item.taskId === id));
}

export function needsTaskReview(state, task) {
  const oldPresets = {
    t1: '核对 408 图的实际小节并完成一次 BFS 手推',
    t2: '从概率第4讲最后记录位置继续一个自然片段',
    t3: '用自己的例句标出英语主语并口头解释'
  };
  return Object.hasOwn(oldPresets, task.id) && oldPresets[task.id] === task.title &&
    (task.legacyReviewPending === true || (!task.createdAt && !task.updatedAt)) && !hasTaskHistory(state, task.id);
}

export function saveTask(state, input, id, now, existingId = null) {
  const normalized = normalizeTaskInput(state, input);
  if (typeof id !== 'string' || !id.trim()) throw new Error('任务 ID 无效');
  if (typeof now !== 'string' || !Number.isFinite(Date.parse(now))) throw new Error('任务时间无效');
  if (existingId === null) {
    if (state.tasks.some(task => task.id === id)) throw new Error('任务已存在，请重新打开新建表单');
    const task = { id, ...normalized, status: 'planned', kind: 'study', createdAt: now, updatedAt: now };
    return { ...state, tasks: [...state.tasks, task] };
  }
  const current = state.tasks.find(task => task.id === existingId);
  if (!current || !['planned', 'in_progress', 'blocked'].includes(current.status)) {
    throw new Error('只能调整尚未结束的任务');
  }
  if (hasTaskHistory(state, current.id)) {
    const binding = taskBindings(state, current);
    const sameGoals = [...binding.goalIds].sort().join('\n') === [...normalized.goalIds].sort().join('\n');
    if (!sameGoals || binding.skillId !== normalized.skillId) {
      throw new Error('任务已有学习记录，目标和能力归属需要保留。请另建任务');
    }
  }
  const updated = { ...current, ...normalized, ...(current.legacyReviewPending ? { legacyReviewPending: false } : {}), updatedAt: now };
  if (input.sourceId !== undefined && !normalized.sourceId) delete updated.sourceId;
  return {
    ...state,
    tasks: state.tasks.map(task => task.id === existingId ? updated : task)
  };
}

export function saveQuickTask(state, input, id, now, existingId = null) {
  const title = text(input.title, '任务标题', 160);
  const current = existingId === null ? null : state.tasks.find(task => task.id === existingId);
  if (existingId !== null) {
    if (!current?.quickTask || !['planned', 'in_progress', 'blocked'].includes(current.status)) {
      throw new Error('这项任务无法快速调整');
    }
    return { ...state, tasks: state.tasks.map(task => task === current ? { ...task, title, updatedAt: now } : task) };
  }
  if (state.tasks.some(task => task.id === id)) throw new Error('任务已存在');
  return { ...state, tasks: [...state.tasks, {
    id, title, goal: '', skill: '临时任务', goalIds: [], minutes: 30,
    status: 'planned', kind: 'study', quickTask: true, createdAt: now, updatedAt: now
  }] };
}

export function archiveTask(state, id, archive, now) {
  if (!state || !Array.isArray(state.tasks)) throw new TypeError('任务状态格式无效');
  if (typeof id !== 'string' || !id) throw new TypeError('任务 ID 无效');
  if (typeof archive !== 'boolean') throw new TypeError('归档操作无效');
  if (typeof now !== 'string' || Number.isNaN(Date.parse(now))) throw new TypeError('操作时间无效');

  const idx = state.tasks.findIndex(t => t && t.id === id);
  if (idx === -1) throw new Error('任务不存在');
  const task = state.tasks[idx];

  const valid = ['planned', 'in_progress', 'blocked', 'done', 'skipped'];
  if (archive) {
    if (task.status === 'cancelled') throw new Error('任务已归档，请刷新列表');
    if (!valid.includes(task.status)) throw new Error('任务状态无法归档');
    const next = { ...task, updatedAt: now, statusBeforeArchive: task.status, archivedAt: now, status: 'cancelled' };
    if (needsTaskReview(state, task)) {
      next.legacyReviewPending = true;
    }
    const tasks = state.tasks.slice();
    tasks[idx] = next;
    return { ...state, tasks };
  }

  if (task.status !== 'cancelled') throw new Error('任务尚未归档，请刷新列表');
  const restored = valid.includes(task.statusBeforeArchive) ? task.statusBeforeArchive : 'planned';
  const next = { ...task, status: restored, updatedAt: now };
  delete next.statusBeforeArchive;
  delete next.archivedAt;
  const tasks = state.tasks.slice();
  tasks[idx] = next;
  return { ...state, tasks };
}

export function selectTasks(state, status) {
  if (!state || !Array.isArray(state.tasks)) throw new TypeError('任务状态格式无效');
  const statuses = ['planned', 'in_progress', 'blocked', 'done', 'skipped', 'cancelled'];
  const allowed = ['active', 'all', ...statuses];
  if (!allowed.includes(status)) throw new TypeError('筛选状态无效');

  const activeSet = new Set(['planned', 'in_progress', 'blocked']);

  return state.tasks.filter(task => {
    if (!task) return false;
    if (status === 'active') return activeSet.has(task.status);
    return status === 'all' || task.status === status;
  });
}
