export const UNCLASSIFIED = '未归类';

const NON_SUBJECT_CATEGORIES = new Set(['期末', '副线', '竞赛', '其他', '通用', UNCLASSIFIED]);
const ALIASES = new Map([['离散', '离散数学'], ['物理', '大学物理']]);

function normalizeLabel(value) {
  return typeof value === 'string' ? value.trim().replace(/\s*[：:]\s*/g, '：') : '';
}

function subjectForSkill(label, category) {
  const [prefix, topic] = normalizeLabel(label).split('：');
  const fallback = normalizeLabel(category);
  if ((prefix === '408' && ['图', '数据结构'].includes(topic)) || (prefix === '图' && !topic && fallback === '408')) return '数据结构';
  const subject = prefix && topic && !NON_SUBJECT_CATEGORIES.has(prefix) ? prefix : fallback;
  return ALIASES.get(subject) || (subject && !NON_SUBJECT_CATEGORIES.has(subject) ? subject : UNCLASSIFIED);
}

function byId(items) {
  return new Map((items || []).map(item => [item.id, item]));
}

const ENGLISH_REVIEW_GROUPS = { vocab: '英语词汇', grammar: '英语语法' };

function englishReviewGroup(reference) {
  if (!reference) return undefined;
  if (reference.courseLane === 'vocab' || reference.skillId === 'english-vocab') return ENGLISH_REVIEW_GROUPS.vocab;
  if (reference.courseLane === 'grammar' || reference.skillId === 'english-grammar') return ENGLISH_REVIEW_GROUPS.grammar;
  return undefined;
}

export function createSubjectIndex(state) {
  const skillIds = new Map();
  const skillNames = new Map();
  for (const [id, label, category] of state.skills) {
    const subject = subjectForSkill(label, category);
    skillIds.set(id, subject);
    const key = normalizeLabel(label);
    if (!skillNames.has(key)) skillNames.set(key, subject);
    else if (skillNames.get(key) !== subject) skillNames.set(key, UNCLASSIFIED);
  }
  const labels = [...new Set(skillIds.values())].filter(subject => subject !== UNCLASSIFIED);
  labels.push(UNCLASSIFIED);

  function fromSkill(reference) {
    if (!reference) return undefined;
    const subject = skillIds.get(reference.skillId) ?? skillNames.get(normalizeLabel(reference.skill));
    return subject === UNCLASSIFIED ? undefined : subject;
  }
  function group(items, resolve, groupLabels = labels) {
    const buckets = new Map(groupLabels.map(subject => [subject, []]));
    for (const item of items) buckets.get(resolve(item) ?? UNCLASSIFIED).push(item);
    return [...buckets].filter(([, entries]) => entries.length).map(([subject, entries]) => ({ subject, items: entries }));
  }
  function reviews(items) {
    const evidence = byId(state.evidence);
    const sessions = byId(state.sessions);
    const tasks = byId(state.tasks);
    const englishGroups = Object.values(ENGLISH_REVIEW_GROUPS);
    const reviewLabels = [...new Set(labels.flatMap(label => label === '英语' || label === UNCLASSIFIED
      ? [...englishGroups, label] : [label]))];
    return group(items, review => {
      const proof = evidence.get(review.evidenceId);
      const session = sessions.get(review.sessionId) ?? sessions.get(proof?.sessionId);
      const references = [proof, session?.taskSnapshot, tasks.get(review.taskId),
        tasks.get(proof?.taskId), tasks.get(session?.taskId)];
      return references.map(englishReviewGroup).find(Boolean) ?? references.map(fromSkill).find(Boolean);
    }, reviewLabels);
  }
  return { tasks: items => group(items, fromSkill), reviews };
}
