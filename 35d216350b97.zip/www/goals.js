export function saveGoalSettings(state, goalId, input) {
  const ALLOWED = ['priority', 'window', 'notes', 'targetDate', 'weeklyTargetMinutes'];
  const PRIORITIES = ['critical', 'high', 'medium', 'low'];

  if (!state || typeof state !== 'object') throw new Error('目标状态格式无效');
  if (!Array.isArray(state.goals)) throw new Error('目标列表无效');
  if (typeof goalId !== 'string' || !goalId) throw new Error('目标 ID 无效');
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('设置格式无效');

  for (const key of Object.keys(input)) {
    if (!ALLOWED.includes(key)) throw new Error('不允许修改字段 ' + key);
  }

  const idx = state.goals.findIndex((g) => Array.isArray(g) && g[0] === goalId);
  if (idx === -1) throw new Error('目标不存在');

  const priority = input.priority;
  if (!PRIORITIES.includes(priority)) throw new Error('请选择目标优先级');

  const window = input.window;
  if (typeof window !== 'string') throw new Error('目标窗口须为 1—400 字文本');
  const windowTrim = window.trim();
  if (!windowTrim || windowTrim.length > 400) throw new Error('目标窗口须为 1—400 字文本');

  const notes = input.notes;
  if (typeof notes !== 'string' || notes.length > 4000) throw new Error('目标说明最多 4000 字');

  const targetDate = input.targetDate;
  if (typeof targetDate !== 'string') throw new Error('目标日期无效');
  if (targetDate !== '') {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(targetDate)) throw new Error('目标日期无效');
    const [y, m, d] = targetDate.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (
      dt.getUTCFullYear() !== y ||
      dt.getUTCMonth() !== m - 1 ||
      dt.getUTCDate() !== d
    ) {
      throw new Error('目标日期无效');
    }
  }

  const weeklyTargetMinutes = input.weeklyTargetMinutes;
  if (weeklyTargetMinutes !== null) {
    if (
      !Number.isSafeInteger(weeklyTargetMinutes) ||
      weeklyTargetMinutes < 0 ||
      weeklyTargetMinutes > 4200
    ) {
      throw new Error('每周参考投入须为 0—4200 分钟，或留空');
    }
  }

  const oldGoal = state.goals[idx];
  const newGoal = [oldGoal[0], oldGoal[1], oldGoal[2], priority];

  const newGoals = state.goals.slice();
  newGoals[idx] = newGoal;

  const goalDetails = Object.assign({}, state.goalDetails, {
    [goalId]: { window: windowTrim, notes, targetDate, weeklyTargetMinutes },
  });

  return Object.assign({}, state, { goals: newGoals, goalDetails });
}

export function createGoal(state, title, goalId, settings) {
  if (typeof title !== 'string' || !title.trim() || title.trim().length > 160) throw new Error('目标名称须为 1—160 字');
  if (typeof goalId !== 'string' || !goalId || state.goals.some(goal => goal[0] === goalId)) throw new Error('目标 ID 已存在或无效');
  const next = { ...state, goals: [...state.goals, [goalId, title.trim(), settings.window, settings.priority]] };
  return saveGoalSettings(next, goalId, settings);
}

export function goalSettings(state, goalId) {
  const goal = state.goals.find(item => item[0] === goalId);
  if (!goal) throw new Error('目标不存在');
  const defaults = {
    g1: { window: '2028 年末考研初试', notes: '数学一、英语一、408、政治构成长线。政治在后续备考阶段核对当季资料。' },
    g2: { window: '2027 年 1 月第 2—3 周，具体日期待核对', notes: '离散数学、数据结构、Java、概率论、大学物理、C++。大学物理范围为电磁学、光学、量子物理。' },
    g3: { window: '2026 年 12 月四级', notes: '本人已报名，具体准考信息以报名记录为准。' },
    g4: { window: '2026 年 12 月 CSP', notes: 'CCF 计算机软件能力认证，目标 200—300 分。报名与缴费情况待核对。' },
    g5: { window: '蓝桥杯赛事窗口待核对', notes: 'C/C++ 大学 A 组，目标国奖。' },
    g6: { window: '校内选拔与赛事窗口待核对', notes: '队伍、校内选拔安排和报名信息待补。' }
  };
  const names = { g1: '考研初试', g2: '2027 年 1 月期末', g3: '四级', g4: 'CSP', g5: '蓝桥杯', g6: 'XCPC' };
  const known = names[goalId] === goal[1] ? defaults[goalId] : null;
  return {
    priority: goal[3], window: known?.window || goal[2],
    notes: known?.notes || '', targetDate: /^\d{4}-\d{2}-\d{2}$/.test(goal[2]) ? goal[2] : '', weeklyTargetMinutes: null,
    ...state.goalDetails?.[goalId]
  };
}
