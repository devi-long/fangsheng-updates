export const MAX_STATE_CHARS = 20_000_000;
export const MAX_BACKUP_CHARS = 24_000_000;
export const MAX_BACKUP_BYTES = 64_000_000;
