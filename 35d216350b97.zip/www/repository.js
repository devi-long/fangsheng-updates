import { MAX_STATE_CHARS } from './limits.js';
import { MAX_BACKUP_BYTES } from './limits.js';
import { validateDraft, draftKey, assertDraftMatch } from './drafts.js';
export const DATABASE_NAME = 'study-app-local-v1';
export const STORE_NAME = 'records';
export const MAIN_KEY = 'main';
export const LEGACY_KEY = 'study-app-v1';
const MAX_TEXT = MAX_STATE_CHARS;

export function validateMetadata(key, value) {
  const fields = key === 'backup-receipt' ? ['revision', 'sha256', 'exportedAt', 'bytes']
    : key === 'backup-verification' ? ['sha256', 'checkedAt', 'comparison'] : null;
  if (!fields || !value || typeof value !== 'object' || Array.isArray(value) ||
    Object.keys(value).length !== fields.length || fields.some(field => !Object.hasOwn(value, field))) {
    throw new Error('备份状态标记无效');
  }
  if (value.sha256 !== null && (typeof value.sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(value.sha256))) throw new Error('备份指纹无效');
  const stamp = key === 'backup-receipt' ? value.exportedAt : value.checkedAt;
  if (typeof stamp !== 'string' || !Number.isFinite(Date.parse(stamp)) || new Date(stamp).toISOString() !== stamp) throw new Error('备份状态日期无效');
  if (key === 'backup-receipt') {
    if (!Number.isSafeInteger(value.revision) || value.revision < 0 ||
      !Number.isSafeInteger(value.bytes) || value.bytes < 1 || value.bytes > MAX_BACKUP_BYTES) throw new Error('备份状态数值无效');
  } else if (!['current', 'last-export', 'different', 'unavailable'].includes(value.comparison)) {
    throw new Error('备份核对结果无效');
  }
  return { ...value };
}

export function validateEnvelope(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('存储记录格式无效');
  if (!Number.isSafeInteger(value.revision) || value.revision < 0) throw new Error('存储版本无效');
  for (const field of ['raw', 'legacyRaw']) {
    if (value[field] !== null && typeof value[field] !== 'string') throw new Error('存储原文类型无效');
    if (typeof value[field] === 'string' && value[field].length > MAX_TEXT) throw new Error('存储内容过大');
  }
  return { revision: value.revision, raw: value.raw, legacyRaw: value.legacyRaw };
}

export function nextEnvelope(current, raw, expectedRevision, liveLegacyRaw, acceptedLegacyRaw) {
  if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 0 || expectedRevision === Number.MAX_SAFE_INTEGER) {
    throw new Error('预期版本无效或已超出上限');
  }
  if (typeof raw !== 'string' || !raw || raw.length > MAX_TEXT) throw new Error('保存原文无效或过大');
  validateEnvelope({ revision: 0, raw: liveLegacyRaw, legacyRaw: acceptedLegacyRaw });
  const previous = current === undefined || current === null ? { revision: 0 } : validateEnvelope(current);
  if (previous.revision !== expectedRevision) throw new Error('其他窗口已更新记录，请刷新后重试');
  if (liveLegacyRaw !== acceptedLegacyRaw) throw new Error('旧版记录已发生变化，请先导出两份记录并核对后恢复');
  return { revision: expectedRevision + 1, raw, legacyRaw: acceptedLegacyRaw };
}

export async function openRepository() {
  if (!globalThis.indexedDB) throw new Error('当前浏览器无法使用本地数据库，请使用支持 IndexedDB 的浏览器');
  let closed = false;
  let cached = null;
  let listener = () => {};
  const db = await new Promise((resolve, reject) => {
    let rejected = false;
    const request = indexedDB.open(DATABASE_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME);
    };
    request.onerror = () => reject(new Error('打开本地数据库失败：' + (request.error?.message || '未知错误')));
    request.onblocked = () => {
      rejected = true;
      reject(new Error('数据库被旧窗口占用，请关闭旧窗口后重试'));
    };
    request.onsuccess = () => {
      if (rejected) { request.result.close(); return; }
      resolve(request.result);
    };
  });
  const changes = typeof BroadcastChannel === 'function' ? new BroadcastChannel('study-app-records') : null;
  if (changes) changes.onmessage = event => {
    if (event.data?.revision !== cached?.revision) listener('records');
  };
  db.onversionchange = () => {
    closed = true;
    db.close();
    changes?.close();
    listener('version');
  };

  function legacyRawNow() {
    try { return localStorage.getItem(LEGACY_KEY); }
    catch { throw new Error('无法读取旧存储，请检查浏览器存储权限'); }
  }

  // All success notifications wait for the transaction to complete.
  function transaction(mode, run) {
    return new Promise((resolve, reject) => {
      if (closed) { reject(new Error('数据库连接已关闭，请刷新重试')); return; }
      let tx;
      try { tx = db.transaction(STORE_NAME, mode); }
      catch (error) { reject(new Error('无法开启本地数据库事务：' + error.message)); return; }
      let result;
      let reason;
      const fail = error => {
        reason = error;
        try { tx.abort(); } catch { reject(reason); }
      };
      tx.oncomplete = () => resolve(result);
      tx.onabort = () => reject(reason || new Error('保存失败：' + (tx.error?.message || '事务已中止')));
      try { run(tx.objectStore(STORE_NAME), value => { result = value; }, fail); }
      catch (error) { fail(new Error('保存失败：' + error.message)); }
    });
  }

  async function readEnvelope() {
    return transaction('readonly', (store, done) => {
      const request = store.get(MAIN_KEY);
      request.onsuccess = () => done(request.result);
    });
  }

  async function read() {
    let value = await readEnvelope();
    if (value === undefined) {
      const legacyRaw = legacyRawNow();
      if (legacyRaw === null) {
        cached = { revision: 0, raw: null, legacyRaw: null };
        return { ...cached };
      }
      // Copy original bytes, including malformed content, so recovery can preserve them.
      value = await transaction('readwrite', (store, done, fail) => {
        const request = store.get(MAIN_KEY);
        request.onsuccess = () => {
          try {
            if (request.result !== undefined) { done(validateEnvelope(request.result)); return; }
            if (legacyRawNow() !== legacyRaw) throw new Error('旧版记录正在变化，请刷新后重试');
            const migrated = validateEnvelope({ revision: 1, raw: legacyRaw, legacyRaw });
            store.put(migrated, MAIN_KEY);
            done(migrated);
          } catch (error) { fail(error); }
        };
      });
    }
    cached = validateEnvelope(value);
    return { ...cached };
  }

  async function commit(raw, options = {}) {
    if (!cached) throw new Error('记录尚未载入，请重新打开应用');
    const expectedRevision = cached.revision;
    const acceptedLegacyRaw = Object.hasOwn(options, 'acceptLegacyRaw') ? options.acceptLegacyRaw : cached.legacyRaw;
    const saved = await transaction('readwrite', (store, done, fail) => {
      const request = store.get(MAIN_KEY);
      request.onsuccess = () => {
        try {
          const next = nextEnvelope(request.result, raw, expectedRevision, legacyRawNow(), acceptedLegacyRaw);
          const finish = () => { store.put(next, MAIN_KEY); done(next); };
          if (options.draft) {
            const draft = options.draft;
            const draftRequest = store.get(draftKey(draft.id));
            draftRequest.onsuccess = () => {
              try {
                assertDraftMatch(draftRequest.result, draft);
                if (draftRequest.result.baseRevision !== expectedRevision) throw new Error('草稿对应的正式记录版本已变化，请先核对内容');
                store.delete(draftKey(draft.id));
                finish();
              } catch (error) { fail(error); }
            };
          } else finish();
        } catch (error) { fail(new Error('保存失败：' + error.message)); }
      };
    });
    cached = saved;
    try { changes?.postMessage({ revision: saved.revision }); }
    catch (error) { console.warn('记录已保存，跨窗口通知发送失败', error); }
    return { ...saved };
  }

  async function exportRaw() {
    const value = await readEnvelope();
    if (value === undefined) return legacyRawNow();
    return typeof value?.raw === 'string' ? value.raw : JSON.stringify(value);
  }

  async function snapshot() {
    const value = await readEnvelope();
    if (value !== undefined) return validateEnvelope(value);
    const legacyRaw = legacyRawNow();
    return { revision: 0, raw: legacyRaw, legacyRaw };
  }

  async function readMetadata(key) {
    if (!['backup-receipt', 'backup-verification'].includes(key)) throw new Error('状态标记名称无效');
    const value = await transaction('readonly', (store, done) => {
      const request = store.get(key);
      request.onsuccess = () => done(request.result);
    });
    return value === undefined ? null : validateMetadata(key, value);
  }

  async function recordMetadata(key, value) {
    const validated = validateMetadata(key, value);
    return transaction('readwrite', (store, done) => {
      store.put(validated, key);
      done(validated);
    });
  }

  async function listDrafts() {
    return transaction('readonly', (store, done) => {
      const drafts = [], errors = [];
      const request = store.openCursor(IDBKeyRange.bound('draft:', 'draft:\uffff'));
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) { done({ drafts: drafts.sort((a,b) => b.updatedAt.localeCompare(a.updatedAt)), errors }); return; }
        try {
          const draft = validateDraft(cursor.value);
          if (cursor.key !== draftKey(draft.id)) throw new Error('草稿存储键不匹配');
          drafts.push(draft);
        } catch (error) { errors.push(String(cursor.key) + '：' + error.message); }
        cursor.continue();
      };
    });
  }

  async function writeDraft(input, expectedSequence = 0) {
    const draft = validateDraft(input);
    if (!Number.isSafeInteger(expectedSequence) || expectedSequence < 0 || draft.sequence !== expectedSequence + 1) throw new Error('草稿预期版本无效');
    return transaction('readwrite', (store, done, fail) => {
      const request = store.get(draftKey(draft.id));
      request.onsuccess = () => {
        try {
          if (request.result === undefined && expectedSequence === 0) { /* new draft */ }
          else assertDraftMatch(request.result, { ...draft, sequence: expectedSequence });
          store.put(draft, draftKey(draft.id));
          done(draft);
        } catch (error) { fail(error); }
      };
    });
  }

  async function claimDraft(input, ownerId, now) {
    const previous = validateDraft(input);
    const next = validateDraft({ ...previous, ownerId, updatedAt: now, sequence: previous.sequence + 1 });
    return transaction('readwrite', (store, done, fail) => {
      const request = store.get(draftKey(previous.id));
      request.onsuccess = () => {
        try {
          assertDraftMatch(request.result, previous);
          store.put(next, draftKey(next.id));
          done(next);
        } catch (error) { fail(error); }
      };
    });
  }

  async function removeDraft(draft) {
    return transaction('readwrite', (store, done, fail) => {
      const request = store.get(draftKey(draft.id));
      request.onsuccess = () => {
        try {
          assertDraftMatch(request.result, draft);
          store.delete(draftKey(draft.id));
          done();
        } catch (error) { fail(error); }
      };
    });
  }

  return {
    read, commit, exportRaw, legacyRawNow, snapshot, readMetadata, recordMetadata,
    listDrafts, writeDraft, claimDraft, removeDraft,
    status: () => ({
      backend: 'IndexedDB', revision: cached?.revision ?? 0,
      legacyAvailable: legacyRawNow() !== null,
      legacyChanged: cached ? legacyRawNow() !== cached.legacyRaw : false
    }),
    subscribe: callback => { listener = callback; },
    close: () => { closed = true; db.close(); changes?.close(); }
  };
}
