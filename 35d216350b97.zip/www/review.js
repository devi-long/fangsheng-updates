export const OUTCOME_LABELS = { success: '独立想起', partial: '部分想起', fail: '完全不会' };

// Trial policy. Intervals are adjustable heuristics, not fitted memory probabilities.
export function adaptiveSchedule(review, outcome) {
  if (!Object.hasOwn(OUTCOME_LABELS, outcome)) throw new Error('请选择回忆结果');
  const counter = value => Number.isInteger(value) && value >= 0 ? value : 0;
  const previous = Number.isInteger(review.interval) && review.interval > 0 ? review.interval : 1;
  let interval = 1;
  if (outcome === 'success') interval = Math.min(120, Math.max(7, previous * 2));
  if (outcome === 'partial') interval = Math.max(1, Math.min(3, Math.floor(previous / 2)));
  return {
    interval,
    successStreak: outcome === 'success' ? counter(review.successStreak) + 1 : 0,
    failureStreak: outcome === 'fail' ? counter(review.failureStreak) + 1 : 0,
    reviewCount: counter(review.reviewCount) + 1
  };
}

function withRecordedHistory(review, sessions) {
  if (Number.isInteger(review.reviewCount)) return review;
  const history = sessions.filter(session => session.reviewId === review.id && Object.hasOwn(OUTCOME_LABELS, session.recall));
  let successStreak = 0;
  let failureStreak = 0;
  for (const session of history) {
    successStreak = session.recall === 'success' ? successStreak + 1 : 0;
    failureStreak = session.recall === 'fail' ? failureStreak + 1 : 0;
  }
  return { ...review, reviewCount: history.length, successStreak, failureStreak };
}

export function isDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(value + 'T00:00:00Z');
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

export function assertDate(value) {
  if (!isDate(value)) throw new Error('日期须为真实的 YYYY-MM-DD');
}

export function todayKey(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(now);
  const part = type => parts.find(value => value.type === type).value;
  return part('year') + '-' + part('month') + '-' + part('day');
}

export function addDays(date, days) {
  assertDate(date);
  const next = new Date(date + 'T00:00:00Z');
  next.setUTCDate(next.getUTCDate() + days);
  return next.toISOString().slice(0, 10);
}

export function rescheduleReview(review, outcome, today) {
  const schedule = adaptiveSchedule(review, outcome);
  return {
    ...review, ...schedule, due: addDays(today, schedule.interval),
    status: 'scheduled', lastOutcome: outcome, updatedAt: today
  };
}

function repairTask(state, review, nextReview, sessionId, now) {
  if (nextReview.failureStreak < 2) return null;
  const active = state.tasks.some(task => task.sourceReviewId === review.id &&
    !['done', 'cancelled', 'skipped'].includes(task.status));
  if (active) return null;
  const evidence = (state.evidence || []).find(item => item.id === review.evidenceId);
  const sourceSession = state.sessions.find(item => item.id === review.sessionId);
  const source = state.tasks.find(task => task.id === (review.taskId || evidence?.taskId || sourceSession?.taskId));
  const actions = {
    code: '对照来源代码找出卡住步骤，再脱离模板重写并运行一个边界案例。',
    question: '对照原题解释卡住的步骤，遮住答案重新完成关键推导。',
    quiz: '定位答错原因，核对解释后重做对应题目。',
    oral: '把说不清楚的概念拆成一个问题，用自己的例子解释。',
    note: '从来源笔记提出一个具体问题，查清后闭卷写出解释。'
  };
  return {
    id: 'repair:' + sessionId, title: '补理解或补练习 · ' + review.title,
    kind: 'repair', status: 'planned', minutes: 30,
    goal: source?.goal || '', skill: source?.skill || evidence?.skill || '',
    sourceReviewId: review.id, evidenceId: review.evidenceId || null,
    action: actions[evidence?.kind] || '定位一个不会的步骤，核对原资料后独立复现，并留下结果。',
    createdAt: now, updatedAt: now
  };
}

export function recordReview(state, reviewId, entry, today, id, now) {
  const review = state.reviews.find(item => item.id === reviewId);
  if (!review || ['completed', 'skipped', 'cancelled'].includes(review.status)) {
    throw new Error('这条复习已关闭或不存在');
  }
  assertDate(review.due);
  if (review.due > today) throw new Error('这条复习尚未到期，请刷新队列');
  if (!Number.isInteger(entry.minutes) || entry.minutes < 1 || entry.minutes > 720) {
    throw new Error('实际耗时须为 1—720 的整数分钟');
  }
  if (typeof entry.note !== 'string' || entry.note.length > 4000) throw new Error('复习备注过长');
  if (!id || state.sessions.some(session => session.id === id)) throw new Error('这条记录已经保存');
  const nextReview = rescheduleReview(withRecordedHistory(review, state.sessions), entry.outcome, today);
  const repair = repairTask(state, review, nextReview, id, now);
  const session = {
    id, date: today, createdAt: now, minutes: entry.minutes, activityType: 'review',
    activity: '复习 · ' + review.title, result: OUTCOME_LABELS[entry.outcome],
    recall: entry.outcome, note: entry.note.trim(), reviewId,
    evidenceId: review.evidenceId || null, previousDue: review.due, nextDue: nextReview.due,
    interval: nextReview.interval, repairTaskId: repair?.id || null
  };
  return {
    ...state,
    tasks: repair ? [...state.tasks, repair] : state.tasks,
    reviews: state.reviews.map(item => item.id === reviewId ? nextReview : item),
    sessions: [...state.sessions, session]
  };
}
