import { saveTask } from './tasks.js';
import { createGoal } from './goals.js';

const python = { label: 'Python 官方教程', url: 'https://docs.python.org/zh-cn/3.12/tutorial/' };
const numpy = { label: 'NumPy 初学者指南', url: 'https://numpy.org/doc/stable/user/absolute_beginners.html' };
const plot = { label: 'Matplotlib 快速入门', url: 'https://matplotlib.org/stable/users/explain/quick_start.html' };
const digits = { label: '手写数字：数据与展示参考', url: 'https://scikit-learn.org/stable/auto_examples/classification/plot_digits_classification.html' };
const pitfalls = { label: 'scikit-learn 常见陷阱', url: 'https://scikit-learn.org/stable/common_pitfalls.html' };
const api = name => ({ label: name, url: 'https://scikit-learn.org/stable/modules/generated/' + name + '.html' });

// Reference weeks describe workload, never calendar deadlines or completed work.
export const AI_CARDS = [
  {
    title: 'Python 环境与基本表达式', reading: 'Python 教程第 2、3 章及第 12 章虚拟环境；先读数字、字符串、列表。',
    work: '建立独立虚拟环境，安装 NumPy、Matplotlib、scikit-learn；运行一个含列表与计算输出的 .py 文件，记下解释器和依赖版本。',
    check: '关闭终端后重新激活环境，修改输入并运行脚本；能说明脚本在哪个环境执行。',
    busy: '15 分钟：重新打开终端，激活环境并运行已有脚本，记下下次起点。', sources: [python]
  },
  {
    title: 'Python 分支、循环与函数', reading: 'Python 教程第 4 章 if、for、range、函数定义；第 5 章列表与字典基础。',
    work: '写函数统计一组标签的出现次数，并返回最常见类别；用 for、if 和字典完成，先用少量手工数据检查。',
    check: '换一组输入独立验证；解释参数、返回值与并列最多时采用的规则。允许查 API，不复制完整解答。',
    busy: '20 分钟：给已有函数补一组不同输入，先手算期望值，再运行比较。', sources: [python]
  },
  {
    title: 'NumPy 数组、形状与切片', reading: 'NumPy 初学者指南：创建数组、shape、索引与切片、reshape、基本运算与 axis。',
    work: '把小型二维列表转为数组；取行、取列、求均值，将一行 64 个数变为 8×8，并记录每一步形状。',
    check: '换一个二维数组，不看教程完成切片与按列均值；用自己的话解释 shape 和 axis。',
    busy: '15 分钟：预测一个切片的形状，运行后核对并记下错因。', sources: [numpy]
  },
  {
    title: '加载手写数字与可视化', reading: '手写数字示例的数据加载、展示部分；Matplotlib 快速入门的 Figure、Axes 和 imshow。示例的 SVM 不作为本阶段模型。',
    work: '用 load_digits 加载本地附带的数据，检查 images、data、target 的形状；画出若干数字及标签，理解一行特征对应一张图。',
    check: '独立换一组样本索引并画图，说明像素、特征、标签的区别。',
    busy: '20 分钟：显示一个指定索引的图像与标签，保存图并记下代码位置。', sources: [digits, plot]
  },
  {
    title: '固定训练集与验证集', reading: 'train_test_split 文档的 test_size、random_state、stratify；常见陷阱中的数据泄露。',
    work: '先固定一个分层划分（如 80%/20%、random_state=42、stratify=y），保存对应样本索引；检查两边不重叠及类别分布。',
    check: '重跑得到相同索引，解释为什么两种模型必须用同一验证集、为什么验证数据不能参与拟合。',
    busy: '20 分钟：打印已有划分的大小，并验证训练与验证索引没有交集。', sources: [api('sklearn.model_selection.train_test_split'), pitfalls]
  },
  {
    title: '多数类分类基线', reading: 'DummyClassifier 文档的 most_frequent 策略、fit、predict、score。',
    work: '仅用训练数据拟合最常见类别基线，在固定验证集上预测；记下多数类、准确率和预测分布。',
    check: '先猜这个基线会输出什么再核对；解释高准确率为什么必须结合基线和类别比例判断。',
    busy: '20 分钟：统计训练标签里最多的类别及比例，留下结果。', sources: [api('sklearn.dummy.DummyClassifier')]
  },
  {
    title: '逻辑回归与预处理流水线', reading: 'LogisticRegression 的 fit、predict、max_iter；常见陷阱中的预处理与 Pipeline。本阶段先理解用途，无须先完整推导优化算法。',
    work: '用 StandardScaler 与 LogisticRegression 组成 Pipeline，只在训练集 fit；预测同一验证集，与多数类基线比较并保留运行配置和警告。',
    check: '能指出每一步哪些数据参与拟合；解释 fit 与 predict 的区别，定位并处理实际遇到的收敛警告。',
    busy: '20 分钟：检查现有流水线的 fit 输入，确认验证集没有参与拟合，记下核对结果。', sources: [api('sklearn.linear_model.LogisticRegression'), pitfalls]
  },
  {
    title: '指标、混淆矩阵与错例', reading: 'accuracy_score、confusion_matrix 文档；回看数字图像展示方法。',
    work: '为两个模型生成同一验证集上的结果表和混淆矩阵；展示最多 5 个逻辑回归错例，标注真值与预测，区分观察与猜测。',
    check: '不看解读说明一个混淆格的含义，提出一条能验证的改进猜想；没有错例时如实记录并检查划分，不能编造错例。',
    busy: '20 分钟：选一个真实错例，记录图像、真值、预测及尚不能确定的原因。', sources: [api('sklearn.metrics.accuracy_score'), api('sklearn.metrics.confusion_matrix'), digits]
  },
  {
    title: '独立重建数字分类实验', reading: '按报错回查 Python 教程第 6、8 章的模块与异常，以及所需 API；不再逐行跟随完整实验教程。',
    work: '从空白文件重建加载、固定划分、基线、流水线、预测、评估；允许查文档，先自己尝试，向 GPT 求助时只请求检查思路和一条提示。',
    check: '换一个预先固定的随机种子，给两模型使用同一新划分重跑；能解释结果变化，保留卡住点与修复过程。',
    busy: '20 分钟：从空白文件独立写出加载与形状检查，不看原实验代码。', sources: [python, pitfalls]
  },
  {
    title: '阶段验收与可复现记录', reading: 'Python 教程第 12 章管理虚拟环境与包；回看自己的运行说明、结果和失败记录。',
    work: '整理 README、依赖版本、运行命令、划分种子、两模型结果表、错例和局限；在新虚拟环境重新安装并运行，记录实际用时。',
    check: '合上教程，可查 API，能重跑关键流程并解释 fit/predict、基线、公平比较和防泄露；遗留问题写清再补练。这是入门验收，第 36 周仍验收首个完整项目。',
    busy: '20 分钟：补全 README 的一条运行命令并实际验证；未完成其余验收时只保存进度。', sources: [python, pitfalls]
  }
].map((card, index) => ({
  ...card, id: 'ai-foundation-' + String(index + 1).padStart(2, '0'),
  referenceWeek: Math.floor(index / 2) + 1, referenceMinutes: 165
}));

export function addAICards(state, now) {
  const existing = new Set(state.tasks.map(task => task.id));
  if (AI_CARDS.every(card => existing.has(card.id))) return state;
  let next = state;
  if (!next.goals.some(goal => goal[0] === 'ai-self-study')) {
    next = createGoal(next, 'AI 自学与项目', 'ai-self-study', {
      priority: 'medium', window: '有效学习周推进，延续至 2028 年初试后', targetDate: '', weeklyTargetMinutes: 330,
      notes: [
        '完全自学，每周参考 5～6 小时，按 5.5 小时校准：阅读 1 小时、动手 3 小时、独立练习 1 小时、复盘半小时。遇期末与备考冲突顺延，不设每日配额。',
        '第 1～5 周：Python、NumPy、绘图与数字分类，比较多数类基线和逻辑回归；目前细排为 10 张顺序卡。',
        '第 6～14 周：机器学习与评估，分类、回归、线性与树模型、交叉验证、防泄露；用新数据公平比较。',
        '第 15～23 周：PyTorch、FashionMNIST，比较全连接与小 CNN，掌握训练/验证循环和模型保存加载。',
        '第 24～29 周：模型实验与 AI 应用工程各试三周；按结果选一条方向。AI 应用工程只是暂定候选。',
        '第 30～36 周：第一个完整项目；第 36 周验收干净环境重跑、结果表、README 与五分钟讲解。',
        '第 37～48 周：脚本与工程化或实验复现；第 48 周验收一条命令/接口复现、测试或多次运行对照。',
        '第 49～64 周：只选一个专项，复现、提问与对照实验；第 64 周验收报告、证据和局限。',
        '第 65 周起：每 8～12 个有效学习周做一个专题；考研冲刺暂停新专题，初试后从重启记录继续。',
        '只细排当前阶段，其余验收后再排。周数和 5.5 小时均为参考预算，不能代替掌握程度；不挤占其他学科。'
      ].join('\n')
    });
  }
  if (!next.skills.some(skill => skill[0] === 'ai-foundation')) {
    next = { ...next, skills: [...next.skills, ['ai-foundation', 'AI：Python 与机器学习', 'AI']] };
  }
  for (const card of AI_CARDS) {
    if (existing.has(card.id)) continue;
    next = saveTask(next, {
      title: 'AI · ' + card.title, goalIds: ['ai-self-study'], skillId: 'ai-foundation', minutes: 1,
      resource: card.sources.map(source => source.label).join(' / '),
      position: '从本卡开头开始，分次学习按断点接续',
      action: ['阅读｜' + card.reading, '动手｜' + card.work, '独立检验与复盘｜' + card.check].join('\n'),
      stopCondition: card.check
    }, card.id, now);
    Object.assign(next.tasks.at(-1), {
      courseCard: true, courseLane: 'ai', learningGuide: {
        referenceWeek: card.referenceWeek, referenceMinutes: card.referenceMinutes,
        reading: card.reading, busyMinimum: card.busy,
        sources: card.sources.map(source => ({ ...source }))
      }
    });
  }
  // Repair a partial import without allowing the missing earlier card to move behind later cards.
  const byId = new Map(next.tasks.map(task => [task.id, task]));
  const ids = new Set(AI_CARDS.map(card => card.id));
  let index = 0;
  return { ...next, tasks: next.tasks.map(task => ids.has(task.id) ? byId.get(AI_CARDS[index++].id) : task) };
}
