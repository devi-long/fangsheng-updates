// Reviewed from DeepSeek's bounded curriculum and score-parser drafts.
const practiceActions = [
  '独立刷题｜按章节分批作答，标记不会、做错和猜对的题。',
  '核对订正｜对照解析定位错因，补齐关键步骤与所用公式。',
  '错题复做｜合上解析重做标记题，留下仍需巩固的题号。'
].join('\n');
const paperActions = [
  '独立作答｜完成本年度题目，可分次接续，标记不会与未做题。',
  '核对订正｜对照解析补齐步骤，记录方法、计算与概念方面的错因。',
  '错题复做｜遮住解析重做标记题，整理这一年的薄弱点。'
].join('\n');
const mockActions = [
  '计时作答｜按所用试卷要求独立完成，记录中断位置与未做题。',
  '评分订正｜依据本卷评分参考核对，区分知识、计算和时间安排问题。',
  '错题复做｜合上解析重做，整理这套卷暴露的问题与处理方法。'
].join('\n');
const practiceStop = '完成本册计划范围首刷、订正与标记题复做，仍需巩固的题进入复习。';
const paperStop = '完成本卷作答、订正与标记题复做，仍需巩固的题进入复习。';
function yearCards(start, end) {
  return Array.from({ length: end - start + 1 }, (_, index) => {
    const year = start + index;
    return { id: 'math-past-' + year, title: year + '年真题 · 数学一',
      resource: '张宇《考研数学真题大全解》· ' + year + '年数学一',
      action: paperActions, stopCondition: paperStop, paperCard: true };
  });
}
export const MATH_PRACTICE_CARDS = [
  { id: 'math-practice-1000-improve', title: '1000题提高篇', resource: '张宇《1000题》· 提高篇',
    action: practiceActions, stopCondition: practiceStop, practiceCard: true, flexiblePractice: true },
  { id: 'math-practice-660', title: '李永乐660', resource: '李永乐《660题》',
    action: [
      '独立刷题｜按章节作答，写出判断依据和必要的计算过程。',
      '核对订正｜分清概念、条件与计算问题，记录易混点。',
      '错题复做｜合上答案重新判断、计算，整理需要反复回看的题。'
    ].join('\n'), stopCondition: practiceStop, practiceCard: true, flexiblePractice: true },
  ...yearCards(1987, 2000),
  ...Array.from({ length: 8 }, (_, index) => ({
    id: 'math-mock-zhangyu-' + (index + 1), title: '张宇八套卷 · 第' + (index + 1) + '套 · 数学一',
    resource: '张宇《八套模拟卷》· 数学一 · 第' + (index + 1) + '套',
    action: mockActions, stopCondition: paperStop, paperCard: true
  })),
  ...yearCards(2001, 2025)
];

export function validatePaperScore(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)) ||
      Object.keys(value).length !== 2 || !Object.hasOwn(value, 'score') || !Object.hasOwn(value, 'total')) {
    throw new Error('试卷成绩须包含得分与满分');
  }
  const { score, total } = value;
  if (!Number.isFinite(score) || !Number.isFinite(total) ||
      score < 0 || total <= 0 || total > 1000 || score > total) {
    throw new Error('得分须为 0 至满分，满分须大于 0 且不超过 1000');
  }
  return { score, total };
}
export function parseOptionalPaperScore(scoreText, totalText) {
  if (typeof scoreText !== 'string' || typeof totalText !== 'string') throw new Error('请填写有效的得分与满分');
  const score = scoreText.trim(), total = totalText.trim();
  if (!score && !total) return null;
  if (!/^\d+(?:\.\d{1,2})?$/.test(score) || !/^\d+(?:\.\d{1,2})?$/.test(total)) {
    throw new Error('得分与满分请成对填写，最多两位小数，也可以同时留空');
  }
  return validatePaperScore({ score: Number(score), total: Number(total) });
}
