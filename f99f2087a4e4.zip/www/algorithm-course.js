import { saveTask } from './tasks.js';

// Transcribed from the user's four photographed contents pages (printed pages 1–4).
// A contents entry confirms a section title/start page, not every algorithm inside it.
export const GUIDE_SECTIONS = Object.freeze({
  '00': ['基本算法', 1],
  '01': ['位运算', 2], '02': ['递推与递归', 12], '03': ['前缀和与差分', 23],
  '04': ['二分', 27], '05': ['排序', 35], '06': ['倍增', 43],
  '07': ['贪心', 46], '08': ['总结与练习', 51],
  '10': ['基本数据结构', 55],
  '11': ['栈', 56], '12': ['队列', 62], '13': ['链表与邻接表', 67],
  '14': ['Hash', 72], '15': ['字符串', 79], '16': ['Trie', 87],
  '17': ['二叉堆', 91], '18': ['总结与练习', 100],
  '20': ['搜索', 103],
  '21': ['树与图的遍历', 105], '22': ['深度优先搜索', 112],
  '23': ['剪枝', 116], '24': ['迭代加深', 122], '25': ['广度优先搜索', 125],
  '26': ['广搜变形', 133], '27': ['A*', 138], '28': ['IDA*', 143],
  '29': ['总结与练习', 146],
  '30': ['数学知识', 149],
  '31': ['质数', 150], '32': ['约数', 155], '33': ['同余', 165],
  '34': ['矩阵乘法', 173], '35': ['高斯消元与线性空间', 177],
  '36': ['组合计数', 187], '37': ['容斥原理与 Möbius 函数', 193],
  '38': ['概率与数学期望', 198], '39': ['0/1 分数规划', 204],
  '3A': ['博弈论之 SG 函数', 206], '3B': ['总结与练习', 210],
  '40': ['数据结构进阶', 213],
  '41': ['并查集', 214], '42': ['树状数组', 224], '43': ['线段树', 233],
  '44': ['分块', 246], '45': ['点分治', 253],
  '46': ['二叉查找树与平衡树初步', 256], '47': ['离线分治算法', 267],
  '48': ['可持久化数据结构', 276], '49': ['总结与练习', 284],
  '50': ['动态规划', 287],
  '51': ['线性 DP', 290], '52': ['背包', 301], '53': ['区间 DP', 310],
  '54': ['树形 DP', 316], '55': ['环形与后效性处理', 323],
  '56': ['状态压缩 DP', 328], '57': ['倍增优化 DP', 336],
  '58': ['数据结构优化 DP', 341], '59': ['单调队列优化 DP', 344],
  '5A': ['斜率优化', 352], '5B': ['四边形不等式', 360],
  '5C': ['计数类 DP', 366], '5D': ['数位统计 DP', 374], '5E': ['总结与练习', 377],
  '60': ['图论', 381],
  '61': ['最短路', 382], '62': ['最小生成树', 396],
  '63': ['树的直径与最近公共祖先', 403], '64': ['基环树', 422],
  '65': ['负环与差分约束', 426], '66': ['Tarjan 算法与无向图连通性', 430],
  '67': ['Tarjan 算法与有向图连通性', 448], '68': ['二分图的匹配', 460],
  '69': ['二分图的覆盖与独立集', 472], '6A': ['网络流初步', 480],
  '6B': ['总结与练习', 493],
  '70': ['综合技巧与实践', 497],
  '71': ['C++ STL', 498], '72': ['随机数据生成与对拍', 510], '7F': ['附录', 516]
});

// Related entries aid lookup; they do not assert that the book covers this topic.
const relatedOnly = new Map([
  ['AC 自动机', '16'], ['双向 DFS', '22'], ['拓扑排序', '21'],
  ['拓扑排序应用', '21'], ['二分图染色', '68'],
  ['记忆化搜索', '50'], ['欧拉路径与回路', '60']
]);
const notListed = new Set(['高精度加法', '高精度减法', '高精度乘法', '高精度除法',
  '双指针', '区间合并', '时空复杂度分析']);

// Reviewed/adapted from DeepSeek's narrow reference-formatting draft.
export function algorithmBookReference(title, code) {
  if (notListed.has(title)) return '';
  const related = relatedOnly.get(title);
  if (related) {
    const [label, page] = GUIDE_SECTIONS[related];
    return `相关参考 0x${related} ${label} · 第 ${page} 页`;
  }
  if (!Object.hasOwn(GUIDE_SECTIONS, code)) throw new Error('书目章节号无效：' + String(code));
  const [label, page] = GUIDE_SECTIONS[code];
  return `${/^[0-7]0$/.test(code) ? '章节参考' : '参考'} 0x${code} ${label} · 第 ${page} 页`;
}

// AcWing 基础课和提高课顺序。章节号指向上面实物目录的相关内容。
const courses = [
  ["基础课", [
    [["快速排序","05"],["归并排序","05"],["归并排序求逆序对","05"],["整数二分","04"],["浮点数二分","04"],["高精度加法",""],["高精度减法",""],["高精度乘法",""],["高精度除法",""],["前缀和","03"],["差分","03"],["双指针",""],["位运算","01"],["离散化","05"],["区间合并",""]],
    [["单链表","13"],["双链表","13"],["邻接表","13"],["栈","11"],["队列","12"],["单调栈","11"],["单调队列","12"],["KMP","15"],["Trie 字典树","16"],["并查集","41"],["二叉堆","17"],["哈希表","14"],["字符串哈希","14"]],
    [["DFS","22"],["BFS","25"],["树的遍历","21"],["图的遍历","21"],["拓扑排序","21"],["朴素 Dijkstra","61"],["堆优化 Dijkstra","61"],["Bellman–Ford","61"],["SPFA","61"],["Floyd","61"],["Prim","62"],["Kruskal","62"],["二分图染色","68"],["匈牙利算法","68"]],
    [["质数判定","31"],["分解质因数","31"],["筛质数","31"],["约数枚举","32"],["约数个数","32"],["约数之和","32"],["欧几里得算法","32"],["欧拉函数","33"],["快速幂","01"],["乘法逆元","33"],["扩展欧几里得算法","33"],["中国剩余定理","33"],["高斯消元","35"],["组合计数","36"],["容斥原理","37"],["Nim 博弈","3A"],["SG 函数","3A"]],
    [["01 背包","52"],["完全背包","52"],["多重背包","52"],["分组背包","52"],["线性 DP","51"],["区间 DP","53"],["计数 DP","5C"],["数位统计 DP","5D"],["状态压缩 DP","56"],["树形 DP","54"],["记忆化搜索","50"]],
    [["区间选点","07"],["最大不相交区间","07"],["区间分组","07"],["区间覆盖","07"],["哈夫曼合并","07"],["排序不等式","07"],["绝对值不等式","07"],["推公式贪心","07"]],
    [["时空复杂度分析",""]]
  ]],
  ["提高课", [
    [["数字三角形模型","51"],["最长上升子序列模型","51"],["背包建模","52"],["状态机 DP","51"],["状态压缩 DP 建模","56"],["区间 DP 应用","53"],["树形 DP 应用","54"],["数位 DP 应用","5D"],["单调队列优化 DP","59"],["斜率优化 DP","5A"]],
    [["Flood Fill","25"],["BFS 最短路模型","25"],["多源 BFS","26"],["最小步数搜索","25"],["双端队列 BFS","26"],["双向 BFS","26"],["A*","27"],["DFS 连通性模型","22"],["DFS 搜索顺序","22"],["搜索剪枝","23"],["迭代加深","24"],["双向 DFS","20"],["IDA*","28"]],
    [["单源最短路建模与应用","61"],["Floyd 变形","61"],["最小生成树应用","62"],["SPFA 判负环","65"],["差分约束","65"],["最近公共祖先","63"],["Tarjan 强连通分量","67"],["Tarjan 割点与桥","66"],["双连通分量","66"],["二分图匹配应用","68"],["二分图覆盖与独立集","69"],["欧拉路径与回路","60"],["拓扑排序应用","21"]],
    [["并查集应用","41"],["树状数组","42"],["线段树","43"],["可持久化数据结构","48"],["Treap","46"],["AC 自动机","40"]],
    [["筛质数应用","31"],["分解质因数应用","31"],["快速幂应用","01"],["约数个数应用","32"],["欧拉函数应用","33"],["同余方程","33"],["矩阵乘法","34"],["组合计数应用","36"],["高斯消元应用","35"],["容斥原理应用","37"],["概率与数学期望","38"],["博弈论应用","3A"]],
    [["位运算应用","01"],["递归","02"],["前缀和应用","03"],["差分应用","03"],["二分应用","04"],["排序应用","05"],["RMQ","06"]]
  ]]
];

export function addAlgorithmCards(state, now) {
  const goalIds = state.goals.filter(goal => ['g4', 'g5', 'g6'].includes(goal[0])).map(goal => goal[0]);
  const skillId = 'acwing-algorithms';
  let next = state;
  for (const [stage, [label, chapters]] of courses.entries()) {
    for (const [chapter, entries] of chapters.entries()) {
      for (const [index, [title, bookSection]] of entries.entries()) {
        const id = `acwing-${stage + 1}-${chapter + 1}-${index + 1}`;
        const prefix = `AcWing 算法${label} · 第 ${chapter + 1} 章｜《算法竞赛进阶指南》`;
        const book = algorithmBookReference(title, bookSection);
        const resource = book ? prefix + book : prefix.split('｜')[0];
        const current = next.tasks.find(task => task.id === id);
        if (current) {
          const legacyResource = prefix + (bookSection ? '参考 0x' + bookSection : '未核实对应章节');
          // Only replace the exact old generated text. User annotations and all study facts stay intact.
          if (current.courseCard === true && current.courseLane === 'algorithm' && current.title === title &&
              current.resource === legacyResource && current.resource !== resource) {
            next = { ...next, tasks: next.tasks.map(task => task.id === id ? { ...task, resource } : task) };
          }
          continue;
        }
        if (!goalIds.length) continue;
        if (!next.skills.some(skill => skill[0] === skillId)) {
          next = { ...next, skills: [...next.skills, [skillId, '算法：AcWing', '算法']] };
        }
        next = saveTask(next, {
          title, goalIds, skillId, minutes: 1,
          resource,
          position: '按上次记录的断点接续',
          action: [
            '学方法｜看对应课节，弄清适用条件。',
            '写代码｜合上模板独立实现，做对应题。',
            '复盘｜记录错因，重做代表题。'
          ].join('\n'),
          stopCondition: '完成本项学习、练习和订正'
        }, id, now);
        Object.assign(next.tasks.at(-1), { courseCard: true, courseLane: 'algorithm' });
      }
    }
  }
  return next;
}
