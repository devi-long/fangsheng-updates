import { DRAFT_FIELDS, DRAFT_LABELS, FIELD_LABELS, draftResumeReason } from './drafts.js';

const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function capture(form) {
  return Object.fromEntries(Object.keys(DRAFT_FIELDS[form.id]).map(name => [name, name === 'goalIds'
    ? [...form.querySelectorAll('[name="goalIds"]:checked')].map(input => input.value)
    : form.elements[name].value]));
}
function apply(form, fields) {
  for (const name of Object.keys(DRAFT_FIELDS[form.id])) {
    if (name === 'goalIds') {
      form.querySelectorAll('[name="goalIds"]').forEach(input => { if (!input.disabled) input.checked = fields[name].includes(input.value); });
    } else {
      const input = form.elements[name];
      if (input.readOnly || input.disabled) continue;
      if (input.tagName === 'SELECT' && ![...input.options].some(option => option.value === fields[name])) throw new Error('草稿选项已变化，请查看内容后重新核对');
      input.value = fields[name];
    }
  }
  for (const name of ['evidenceType','outcome','activity']) form.elements[name]?.dispatchEvent(new Event('change', { bubbles:true }));
}

export function createDraftController({ repository, getDate, getSaving, onMessage, onResume, describe }) {
  const ownerId = crypto.randomUUID();
  const sessions = new Map();
  const center = document.querySelector('#draft-center');
  const dialog = document.querySelector('#drafts-dialog');
  const list = document.querySelector('#draft-list');
  let rows = [], refreshId = 0;

  function status(form, session, text) {
    if (sessions.get(form) !== session) return;
    form.querySelector('[data-draft-status]').textContent = text;
    form.querySelector('[data-retry-draft]').hidden = !session.error;
    form.querySelector('[data-retry-draft]').textContent = session.conflicted ? '另存草稿副本' : '重试暂存';
  }
  async function refresh() {
    const request = ++refreshId;
    try {
      const result = await repository.listDrafts();
      if (request !== refreshId) return;
      rows = result.drafts;
      center.hidden = !rows.length && !result.errors.length;
      center.querySelector('[data-draft-count]').textContent = `未完成草稿 ${rows.length} 份${result.errors.length ? ' · 有无法读取的草稿，原文已保留' : ''}`;
      list.innerHTML = rows.map(draft => {
        const reason = draftResumeReason(draft, repository.status().revision, getDate());
        return `<article class="draft-item"><h3>${esc(DRAFT_LABELS[draft.formId])} · ${esc(describe(draft))}</h3>
          <p class="muted">${esc(new Date(draft.updatedAt).toLocaleString('zh-CN'))} · 原日期 ${esc(draft.openedDate)}</p>
          ${reason ? `<p class="muted">${esc(reason)}</p>` : ''}
          <div class="card-actions"><button data-resume-draft="${esc(draft.id)}" ${reason ? 'disabled' : ''}>继续编辑</button>
          <button data-view-draft="${esc(draft.id)}">查看内容</button><button data-export-draft="${esc(draft.id)}">导出草稿</button>
          <button data-remove-draft="${esc(draft.id)}">丢弃草稿</button></div></article>`;
      }).join('') || '<p class="muted">没有未完成草稿。</p>';
      if (result.errors.length) list.innerHTML += `<p class="form-error">${esc(result.errors.join('；'))}</p>`;
    } catch (error) {
      if (request !== refreshId) return;
      center.hidden = false;
      center.querySelector('[data-draft-count]').textContent = '草稿读取失败：' + error.message;
      list.textContent = '草稿读取失败：' + error.message;
    }
  }
  function begin(form, context, draft = null) {
    const fields = capture(form);
    const session = {
      id:draft?.id ?? crypto.randomUUID(), ownerId, formId:form.id, ...context,
      baseRevision:draft?.baseRevision ?? repository.status().revision,
      openedDate:draft?.openedDate ?? getDate(), sequence:draft?.sequence ?? 0,
      lastQueued:JSON.stringify(fields), queue:Promise.resolve(), pending:0, error:null, conflicted:false, saving:false
    };
    sessions.set(form, session);
    status(form, session, draft ? '已恢复草稿，保存后才写入正式记录。' : '更改后自动暂存；正式记录在点击保存后写入。');
  }
  function enqueue(form, force = false) {
    const session = sessions.get(form);
    if (!session || session.saving) return Promise.resolve();
    const fields = capture(form), serialized = JSON.stringify(fields);
    if (!force && session.lastQueued === serialized) return session.queue;
    session.lastQueued = serialized;
    session.pending++;
    status(form, session, '正在本机暂存…');
    session.queue = session.queue.then(async () => {
      try {
        if (session.conflicted) throw session.error;
        const first = session.sequence === 0;
        const draft = await repository.writeDraft({
          version:1, id:session.id, ownerId, formId:form.id, targetId:session.targetId, entityId:session.entityId,
          baseRevision:session.baseRevision, openedDate:session.openedDate, updatedAt:new Date().toISOString(),
          sequence:session.sequence + 1, fields
        }, session.sequence);
        session.sequence = draft.sequence;
        session.error = null;
        if (first) refresh();
      } catch (error) {
        session.error = error;
        session.conflicted = error.code === 'DRAFT_CONFLICT';
      } finally {
        session.pending--;
        status(form, session, session.error ? '草稿未暂存，输入仍在当前表单：' + session.error.message
          : session.pending ? '正在本机暂存…' : '已在本机暂存。最后输入须等此提示后再关闭页面。');
      }
    });
    return session.queue;
  }
  async function closeForm(form, discard = false) {
    const session = sessions.get(form);
    if (getSaving()) return;
    if (!session) { form.closest('dialog').close(); return; }
    if (!discard) await enqueue(form);
    await session.queue;
    if (!discard && session.error) throw session.error;
    if (discard && session.sequence && !session.conflicted) await repository.removeDraft(session);
    sessions.delete(form);
    form.closest('dialog').close();
    refresh();
  }

  for (const formId of Object.keys(DRAFT_FIELDS)) {
    const form = document.getElementById(formId);
    const line = document.createElement('p');
    line.className = 'muted draft-status'; line.dataset.draftStatus = ''; line.setAttribute('role','status');
    const retry = document.createElement('button'); retry.type = 'button'; retry.dataset.retryDraft = ''; retry.hidden = true;
    form.querySelector('h2').after(line, retry);
    const close = form.querySelector('[data-close]');
    close.textContent = '暂存并关闭';
    const discard = document.createElement('button'); discard.type = 'button'; discard.dataset.discardDraft = ''; discard.textContent = '放弃修改';
    close.before(discard);
    for (const type of ['input','change']) form.addEventListener(type, () => enqueue(form));
    form.closest('dialog').addEventListener('cancel', event => {
      event.preventDefault();
      closeForm(form).catch(error => onMessage('暂存未完成：' + error.message));
    });
  }
  document.addEventListener('click', async event => {
    const form = event.target.closest('form');
    const localClose = event.target.closest('[data-close], [data-discard-draft]');
    if (localClose && form && Object.hasOwn(DRAFT_FIELDS,form.id)) {
      event.preventDefault(); event.stopImmediatePropagation();
      try { await closeForm(form, event.target.closest('[data-discard-draft]') !== null); }
      catch (error) { onMessage('草稿操作未完成：' + error.message); }
      return;
    }
    try {
      if (event.target.closest('[data-retry-draft]') && form) {
        const session = sessions.get(form);
        if (session.conflicted) { session.id = crypto.randomUUID(); session.sequence = 0; session.conflicted = false; }
        await enqueue(form, true);
      }
      if (event.target.closest('[data-open-drafts]')) {
        await refresh(); document.querySelector('#draft-preview').hidden = true; dialog.showModal();
      }
      const button = event.target.closest('[data-resume-draft], [data-view-draft], [data-export-draft], [data-remove-draft]');
      if (!button) return;
      const id = button.dataset.resumeDraft || button.dataset.viewDraft || button.dataset.exportDraft || button.dataset.removeDraft;
      const draft = rows.find(row => row.id === id);
      if (!draft) throw new Error('草稿已变化，请重新打开列表');
      if (button.hasAttribute('data-view-draft')) {
        const preview = document.querySelector('#draft-preview');
        preview.hidden = false;
        preview.querySelector('pre').textContent = `${DRAFT_LABELS[draft.formId]} · ${describe(draft)}\n原日期：${draft.openedDate}\n\n` +
          Object.entries(draft.fields).map(([key,value]) => `${FIELD_LABELS[key]}：\n${Array.isArray(value) ? value.join(' / ') : value}`).join('\n\n');
      } else if (button.hasAttribute('data-export-draft')) {
        const url = URL.createObjectURL(new Blob([JSON.stringify(draft,null,2)],{type:'application/json'}));
        const link = document.createElement('a'); link.href = url; link.download = 'study-app-draft-' + draft.id + '.json'; link.click();
        setTimeout(()=>URL.revokeObjectURL(url),1000);
      } else if (button.hasAttribute('data-remove-draft')) {
        await repository.removeDraft(draft); document.querySelector('#draft-preview').hidden = true; await refresh();
      } else {
        if (getSaving()) return;
        if ([...sessions.keys()].some(open => open.closest('dialog').open)) throw new Error('请先暂存并关闭当前表单');
        const snapshot = await repository.snapshot();
        if (snapshot.revision !== repository.status().revision) throw new Error('其他窗口已更新正式记录，请刷新后核对草稿');
        const reason = draftResumeReason(draft, snapshot.revision, getDate());
        if (reason) throw new Error(reason);
        const claimed = await repository.claimDraft(draft, ownerId, new Date().toISOString());
        dialog.close();
        let restored;
        try {
          restored = onResume(claimed);
          apply(restored, claimed.fields);
          begin(restored, {targetId:claimed.targetId,entityId:claimed.entityId}, claimed);
        } catch (error) { restored?.closest('dialog').close(); throw error; }
        refresh();
      }
    } catch (error) { onMessage('草稿操作未完成：' + error.message); refresh(); }
  }, true);
  window.addEventListener('focus', refresh);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') for (const form of sessions.keys()) if (form.closest('dialog').open) enqueue(form);
  });
  refresh();
  return {
    begin, refresh,
    async beforeSave(form) {
      const session = sessions.get(form);
      if (!session) return null;
      session.saving = true;
      await session.queue;
      if (session.conflicted) throw session.error;
      return session.sequence ? {id:session.id,ownerId,sequence:session.sequence} : null;
    },
    saved(form) { sessions.delete(form); refresh(); },
    saveFailed(form, error) {
      const session=sessions.get(form);
      if (!session) return;
      session.saving=false;
      if (error.code === 'DRAFT_CONFLICT') {
        session.error=error; session.conflicted=true;
        status(form,session,'草稿已在其他窗口处理，输入仍在。可另存副本后再保存。');
      }
    }
  };
}
