// Beginner-facing content adapted from DeepSeek drafts and reviewed against official references.
// These are learning steps, not completed work or fixed-duration promises.
export const AI_BEGINNER_CONTENT = [
  {
    title: 'AI 入门与 Python 环境',
    reading: '先读本卡概念提示和机器学习简介；Python 教程第 2、3、12 章只看运行脚本、基本表达式和虚拟环境。',
    work: '先画一张 6 个样本的小表，标出特征和标签；再建虚拟环境，用 .py 输出列表与计算结果，记下解释器版本。',
    check: '用自己的例子区分分类与回归、训练与预测；关闭终端重开后能运行自己的脚本。',
    busy: '15 分钟：用一个生活例子写出要预测的标签和可用特征，留下下一步。',
    explanation: 'AI 是研究和构建智能系统的领域；机器学习是其中从数据学习模型的方法，深度学习是机器学习中的一类方法。本阶段先做数字分类，理解从数据到预测的过程。\n样本是一条记录，特征是输入，标签是希望预测的答案。例如花朵表中每行是一朵花、长宽是特征、品种是标签。分类预测类别，回归预测连续数值。\n训练用已知样本调整模型；预测用学到的模型处理输入。本卡先说明任务，再运行最小脚本，无须一次安装所有 AI 工具。',
    sources: [
      { label: 'Python 官方教程', url: 'https://docs.python.org/zh-cn/3.12/tutorial/' },
      { label: '机器学习简介：概念补充', url: 'https://developers.google.com/machine-learning/intro-to-ml?hl=zh-cn' }
    ]
  },
  {
    title: 'Python 函数、导入与基础调试',
    reading: 'Python 教程第 4 章 if、for、函数和关键字参数；第 5 章列表、字典；第 6 章导入及第 8.1～8.2 节报错。',
    work: '写一个小函数统计标签次数，换输入手算核对；再放入模块，尝试 import、from、as，并用 print、type、len 检查数据。',
    check: '能导入自己的函数，解释参数和返回值；遇到一个报错能找到类型、行号和出错变量，再改正重跑。',
    busy: '20 分钟：给已有函数换一组输入，先手算期望结果，再运行核对。',
    explanation: '函数封装一段操作；模块是可以导入的 .py 文件，as 用来起别名。先会导入自己的函数，再读 import numpy as np 就更容易。\n对象.方法表示调用这个对象提供的功能，例如列表的 append；现在会识别和调用即可，完整的类与继承在深度学习前补。报错先看最后的错误说明，再看回溯中的文件与行号，不靠反复粘贴整段代码修复。'
  },
  {
    title: 'NumPy 数组与最小数学直觉',
    reading: 'NumPy 初学者指南：安装、数组创建、shape、索引、切片、reshape、axis、按条件筛选、均值与标准差。',
    work: '安装 NumPy；用 3 行 2 列小表练习取行、取列、筛选和变形，计算每列均值，先预测再打印形状。',
    check: '换一张小表独立完成操作；说明哪一维是样本、哪一维是特征，以及 reshape 为什么不能改变元素总数。',
    busy: '15 分钟：预测一个切片的形状，运行后核对，记下理解错的地方。',
    explanation: '本实验把一条样本写成一行向量，多条样本组成矩阵；行数是样本数，列数是特征数。axis 指沿哪个维度计算，不必把它背成固定口诀。\n均值表示中心，标准差描述分散程度；缩放是调整数值尺度。先用小数组理解运算意义，后面再学习在训练集上拟合缩放参数。此时不要求矩阵分解或微积分推导。'
  },
  {
    title: '手写数字数据与绘图',
    reading: '数字示例只看 load_digits 与图像展示；Matplotlib 快速入门看 Figure、Axes、imshow。原示例的 SVM 不在本卡学习。',
    work: '安装 scikit-learn、Matplotlib；加载 digits，打印 data、target、images 的形状，选一个索引画图并标注真实标签。',
    check: '换索引独立画图；解释一张 8×8 图像为何对应 64 个输入特征，以及 X 与 y 如何逐行对应。',
    busy: '20 分钟：在已有环境里画一个指定索引的数字，核对标签并保存图。',
    explanation: 'digits 是 scikit-learn 附带的小数据集。X 存特征，y 存真实类别；images 把同一份像素排成便于观看的图像。\n本卡先看清输入与答案，后面才训练模型。安装包名是 scikit-learn，代码导入名是 sklearn，两者不要混用。默认数据与小模型可在 CPU 上练习。'
  },
  {
    title: '训练、验证与数据划分',
    reading: 'train_test_split 的 test_size、random_state、stratify；常见陷阱的数据泄露部分，并结合本卡提示理解泛化与过拟合。',
    work: '固定一个分层划分，例如 80%/20%、种子 42；保存样本索引，检查两边无交集、特征与标签对应、类别比例接近。',
    check: '重跑能得到相同划分；解释模型在哪一部分学习，两模型怎样公平比较，以及为什么不能先用全部数据拟合预处理。',
    busy: '20 分钟：检查已有训练与验证索引没有交集，并记录核对结果。',
    explanation: '训练集提供学习材料；验证集帮助检查、比较和选择模型。泛化关心未参与训练的数据，过拟合的一种表现是训练表现很好而新数据较差，但差距本身不是唯一诊断证据。\n这次的随机划分只针对当前入门数据。验证集反复用于改模型后，分数不能冒充独立最终测试结果。分组、时间划分与最终测试集在下一阶段学习。'
  },
  {
    title: '多数类基线与 fit/predict',
    reading: 'DummyClassifier 的 most_frequent 策略、fit、predict；先读本卡例子，再查 API 参数。',
    work: '先对一小组标签手算多数类，再统计完整训练标签；用 DummyClassifier 拟合训练集，在固定验证集预测并计算正确数/总数。',
    check: '说明基线为什么总猜同一类，手算几个预测是否正确；区分训练集多数类比例与验证集上的实际准确率。',
    busy: '20 分钟：给一小组标签手算多数类，写出这个基线将作出的预测。',
    explanation: '基线提供一个简单参照：most_frequent 在 fit 时找出训练标签里最多的类别，predict 时总输出这一类，不利用输入特征区分样本。\n验证准确率等于验证集中这个预测类别所占比例，不一定等于它在训练集的比例。例如训练标签 [0,0,0,1]、验证标签 [0,1,1,1]，总猜 0 在验证集仅答对 1/4。结果先如实记录，再比较更复杂模型。'
  },
  {
    title: '逻辑回归分类与流水线',
    reading: '先看本卡解释和 scikit-learn 入门的预处理、流水线部分，再查 LogisticRegression 的 fit、predict、max_iter。',
    work: '把 StandardScaler 与 LogisticRegression 组成 Pipeline，仅在训练集 fit；在同一验证集预测，与基线比较并记录配置和警告。',
    check: '说明缩放、模型各负责什么，哪些参数是学习到的；区分 fit、transform、predict，并能检查实际出现的警告。',
    busy: '20 分钟：检查已有流水线的 fit 输入，确认验证集没有参与拟合，记录结果。',
    explanation: '逻辑回归虽然名字含“回归”，这里用于分类：训练调整特征权重等参数，根据输入给出类别判断。先理解加权得分与预测概率的含义，完整推导以后补。\nStandardScaler 从训练数据学习缩放所需的统计量；Pipeline 串联缩放与模型，预测时沿用已学处理。max_iter 是人为设置的迭代上限，权重是训练学到的参数。遇收敛警告先检查数据、缩放和设置，再参考文档修改。',
    sources: [
      { label: 'scikit-learn 入门：预处理与流水线', url: 'https://scikit-learn.org/stable/getting_started.html' },
      { label: 'LogisticRegression', url: 'https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html' },
      { label: 'scikit-learn 常见陷阱', url: 'https://scikit-learn.org/stable/common_pitfalls.html' }
    ]
  },
  {
    title: '准确率、混淆矩阵与错例',
    reading: 'accuracy_score、confusion_matrix 的定义和示例；先用本卡解释读懂行列，再看自己的数字图像。',
    work: '两模型用同一验证集与标签顺序生成结果表、混淆矩阵；展示最多 5 个真实错例，标真值与预测，并写一条待验证的猜想。',
    check: '说明准确率的分子、分母和一个混淆格的含义；区分观察与错因猜测。零错例时核对划分和预测，不编造错误。',
    busy: '20 分钟：解释一个真实错例；若没有错例，就核对一个预测及其原始样本索引。',
    explanation: '准确率是预测正确数除以评估样本总数。scikit-learn 混淆矩阵的行是真实类别，列是预测类别；对角线计正确分类，非对角线计混淆。\n看到“3 被预测成 8”只是观察，不能直接证明原因是图像模糊。零错例也只说明本次结果，仍应核对是否误用训练集或错配标签；后续再系统学习 precision、recall、F1 和不平衡数据。'
  },
  {
    title: '按自己的提纲独立重建',
    reading: '先写自己的流程提纲；按需查 Python 第 6 章模块、第 7 章输入输出、第 8 章错误，以及实际使用的 API。',
    work: '从空文件逐步重建加载、划分、基线、流水线、评估，每段先跑通再组合；允许查 API，卡住时先写自己的尝试与预期。',
    check: '用自己的提纲重跑流程并解释关键输入输出；给两模型换成同一预先固定的新划分，记录结果变化和仍不理解的步骤。',
    busy: '20 分钟：不看原实验代码，独立写出加载与形状检查这一个步骤。',
    explanation: '独立完成允许查语法、参数和自己的提纲；先尝试，再请 GPT 审查思路并给一条提示，最后自己修改并解释。\n换随机种子仍是在同一数据集重复实验，不代表换到陌生任务，也不能凭一次涨分证明改进有效。新数据迁移练习放在下一阶段。遇报错先保存原文、最小相关代码与预期结果。'
  },
  {
    title: '入门验收与重启记录',
    reading: '回看自己的运行命令、依赖版本、结果与失败记录；Python 教程第 12 章只补当前环境管理所需部分。',
    work: '在自己的环境关闭、重开终端并重跑实验；整理 README：命令、版本、数据划分、两模型结果、错例、失败尝试和局限。',
    check: '可查 API 和自己的提纲，能重跑关键步骤，解释特征/标签、fit/predict、基线、公平比较与防泄露；未掌握处补练后再完成。',
    busy: '20 分钟：补全 README 的一条运行命令，并在现有环境实际验证。',
    explanation: '这一阶段先要求自己能重新启动、跑出结果并解释过程。新建干净虚拟环境重装依赖是选做，第 36 周完整项目再正式验收干净环境复现。\n完成卡片不等于长期掌握；之后复习先空白重做一个关键步骤，再对照记录。每次写清停在哪、为什么卡住、下次先做什么，让间隔一段时间也能接着学。'
  }
];
