import { isDate } from './review.js';
import { correctionFields } from './correction-input.js';
import { MAX_STATE_CHARS, MAX_BACKUP_CHARS, MAX_BACKUP_BYTES } from './limits.js';
import { normalizeEvidenceLevel } from './evidence-levels.js';
import { validateSourceReferences } from './sources.js';
import { validatePracticeCounts } from './calculus-course.js';
import { validatePaperScore } from './math-practice-course.js';

const ROOT_FIELDS = new Set(['schemaVersion', 'capacity', 'goals', 'skills', 'tasks', 'reviews', 'sessions', 'evidence',
  'corrections', 'sources', 'capacityByDate', 'reviewBudgetMinutes', 'reviewBudgetByDate', 'skillHandoffs', 'goalDetails', 'recovery']);

function plain(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
    ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw new Error(label + ' 必须是普通对象');
  return value;
}
function text(value, label, max = 8000, required = false) {
  if (typeof value !== 'string' || value.length > max || (required && !value.trim())) throw new Error(label + ' 文本无效');
  return value;
}
function integer(value, label, min, max) {
  if (!Number.isSafeInteger(value) || value < min || value > max) throw new Error(label + ' 数值无效');
}
function ids(items, label, limit = 20000) {
  if (!Array.isArray(items) || items.length > limit) throw new Error(label + ' 列表无效或过大');
  const seen = new Set();
  for (const item of items) {
    plain(item, label);
    text(item.id, label + '.id', 200, true);
    if (seen.has(item.id)) throw new Error(label + ' ID 重复');
    seen.add(item.id);
  }
  return seen;
}
function link(value, allowed, label) {
  if (value === undefined || value === null) return;
  text(value, label, 200, true);
  if (!allowed.has(value)) throw new Error(label + ' 引用了不存在的记录');
}
function links(values, allowed, label) {
  if (values === undefined) return;
  if (!Array.isArray(values) || new Set(values).size !== values.length) throw new Error(label + ' 列表无效');
  for (const value of values) {
    if (typeof value !== 'string') throw new Error(label + ' ID 类型无效');
    link(value, allowed, label);
  }
}
function dateMap(value, label) {
  if (value === undefined) return;
  plain(value, label);
  for (const [date, minutes] of Object.entries(value)) {
    if (!isDate(date)) throw new Error(label + ' 日期无效');
    integer(minutes, label, 0, 600);
  }
}
function safeTree(value, depth = 0) {
  if (depth > 20) throw new Error('备份嵌套过深');
  if (!value || typeof value !== 'object') return;
  for (const key of Object.keys(value)) {
    if (['__proto__', 'constructor', 'prototype'].includes(key)) throw new Error('备份包含不支持的字段 ' + key);
    safeTree(value[key], depth + 1);
  }
}
export function stripRecovery(state) {
  const { recovery, ...rest } = state;
  return rest;
}

export function validateLearningState(state, allowRecovery = true) {
  plain(state, 'state');
  safeTree(state);
  for (const key of Object.keys(state)) if (!ROOT_FIELDS.has(key)) throw new Error('state 含不支持的字段 ' + key);
  if (state.schemaVersion !== undefined && state.schemaVersion !== 1) throw new Error('不支持的 schemaVersion');
  integer(state.capacity, 'capacity', 0, 600);
  const tupleIds = (items, length, label) => {
    if (!Array.isArray(items) || items.length > 2000) throw new Error(label + ' 列表无效');
    const seen = new Set();
    for (const tuple of items) {
      if (!Array.isArray(tuple) || tuple.length !== length) throw new Error(label + ' 结构无效');
      for (let i = 0; i < tuple.length; i++) text(tuple[i], label, i === 0 ? 200 : 4000, i < 2);
      if (seen.has(tuple[0])) throw new Error(label + ' ID 重复');
      seen.add(tuple[0]);
    }
    return seen;
  };
  const goalIds = tupleIds(state.goals, 4, 'goals');
  for (const goal of state.goals) if (!['critical', 'high', 'medium', 'low'].includes(goal[3])) throw new Error('目标优先级无效');
  const skillIds = tupleIds(state.skills, 3, 'skills');
  const taskIds = ids(state.tasks, 'tasks');
  const reviewIds = ids(state.reviews, 'reviews');
  const sessionIds = ids(state.sessions, 'sessions', 100000);
  const evidenceIds = ids(state.evidence || [], 'evidence');
  const correctionIds = ids(state.corrections || [], 'corrections', 100000);
  validateSourceReferences(state);
  for (const task of state.tasks) {
    text(task.title, '任务标题', 400, true);
    text(task.goal, '任务目标', 4000);
    text(task.skill, '任务能力', 1000);
    integer(task.minutes, '任务投入', 1, 480);
    if (!['planned', 'in_progress', 'blocked', 'done', 'cancelled', 'skipped'].includes(task.status)) throw new Error('任务状态无效');
    links(task.goalIds, goalIds, '任务目标');
    link(task.skillId, skillIds, '任务能力');
    link(task.sourceReviewId, reviewIds, '补练习来源');
    link(task.evidenceId, evidenceIds, '任务证据');
    for (const key of ['resource', 'position', 'action', 'stopCondition']) if (task[key] !== undefined) text(task[key], key);
  }
  for (const session of state.sessions) {
    if (!isDate(session.date)) throw new Error('学习记录日期无效');
    integer(session.minutes, '实际学习分钟', 1, 720);
    text(session.activity, '学习活动', 4000, true);
    for (const key of ['result', 'evidence', 'note', 'blocker']) if (session[key] !== undefined) text(session[key], key);
    if (session.evidenceLevel !== undefined) normalizeEvidenceLevel(session.evidenceLevel);
    if (session.startupMinutes !== undefined) integer(session.startupMinutes, '启动等待', 0, 720);
    if (session.practiceCounts !== undefined) validatePracticeCounts(session.practiceCounts);
    if (session.paperScore !== undefined) validatePaperScore(session.paperScore);
    link(session.taskId, taskIds, '学习记录任务');
    link(session.reviewId, reviewIds, '学习记录复习');
    link(session.evidenceId, evidenceIds, '学习记录证据');
    if (session.taskSnapshot !== undefined) plain(session.taskSnapshot, '任务快照');
  }
  for (const correction of state.corrections || []) {
    text(correction.sessionId, '纠正来源记录', 200, true);
    if (!sessionIds.has(correction.sessionId)) throw new Error('纠正来源记录引用了不存在的学习记录');
    text(correction.createdAt, '纠正时间', 40, true);
    if (!Number.isFinite(Date.parse(correction.createdAt)) || new Date(correction.createdAt).toISOString() !== correction.createdAt) throw new Error('纠正时间无效');
    text(correction.reason, '纠正原因', 1000, true);
    plain(correction.before, '纠正前内容'); plain(correction.after, '纠正后内容');
    const source = state.sessions.find(session => session.id === correction.sessionId);
    const fields = correctionFields(source);
    for (const section of [correction.before, correction.after]) {
      if (Object.keys(section).length !== fields.length || fields.some(field => !Object.hasOwn(section, field))) throw new Error('纠正字段不完整');
      for (const field of fields) {
        const value = section[field];
        if (field === 'minutes') integer(value, '纠正分钟数', 1, 720);
        else if (field === 'startupMinutes') { if (value !== null) integer(value, '纠正启动等待', 0, 720); }
        else text(value, '纠正' + field, 8000);
      }
    }
  }
  for (const evidence of state.evidence || []) {
    text(evidence.kind, '证据类型', 40, true);
    if (evidence.level !== undefined) normalizeEvidenceLevel(evidence.level);
    text(evidence.title, '证据标题', 400, true);
    text(evidence.content, '证据内容', 8000, true);
    text(evidence.skill, '证据能力', 1000);
    link(evidence.taskId, taskIds, '证据任务');
    link(evidence.sessionId, sessionIds, '证据来源记录');
    link(evidence.skillId, skillIds, '证据能力');
    links(evidence.goalIds, goalIds, '证据目标');
  }
  for (const review of state.reviews) {
    text(review.title, '复习标题', 400, true);
    if (!isDate(review.due)) throw new Error('复习日期无效');
    if (review.interval !== undefined) integer(review.interval, '复习间隔', 1, 36500);
    if (review.minutes !== undefined) integer(review.minutes, '复习投入', 1, 480);
    if (review.status !== undefined && !['pending', 'scheduled', 'completed', 'cancelled', 'skipped'].includes(review.status)) throw new Error('复习状态无效');
    link(review.taskId, taskIds, '复习任务');
    link(review.sessionId, sessionIds, '复习来源记录');
    link(review.evidenceId, evidenceIds, '复习证据');
  }
  dateMap(state.capacityByDate, '每日容量');
  dateMap(state.reviewBudgetByDate, '复习预算');
  if (state.reviewBudgetMinutes !== undefined) integer(state.reviewBudgetMinutes, '复习预算', 0, 600);
  if (state.skillHandoffs !== undefined) {
    plain(state.skillHandoffs, '学习交接');
    for (const [skillId, handoff] of Object.entries(state.skillHandoffs)) {
      link(skillId, skillIds, '学习交接能力');
      plain(handoff, '学习交接');
      if (!['unconfirmed', 'confirmed', 'deferred'].includes(handoff.status)) throw new Error('交接状态无效');
      for (const key of ['resource', 'position', 'action', 'stopCondition', 'note']) text(handoff[key], '学习交接 ' + key, 4000);
      link(handoff.lastSessionId, sessionIds, '交接来源记录');
    }
  }
  if (state.goalDetails !== undefined) {
    plain(state.goalDetails, '目标设置');
    for (const [goalId, detail] of Object.entries(state.goalDetails)) {
      link(goalId, goalIds, '目标设置');
      plain(detail, '目标设置');
      text(detail.window, '目标窗口', 400);
      text(detail.notes, '目标说明', 4000);
      if (detail.targetDate !== undefined && (typeof detail.targetDate !== 'string' || (detail.targetDate && !isDate(detail.targetDate)))) throw new Error('目标日期无效');
      if (detail.weeklyTargetMinutes !== null && detail.weeklyTargetMinutes !== undefined) integer(detail.weeklyTargetMinutes, '每周参考投入', 0, 4200);
    }
  }
  if (state.recovery !== undefined) {
    if (!allowRecovery) throw new Error('恢复快照只能保留一层');
    plain(state.recovery, '恢复快照');
    const keys = Object.keys(state.recovery);
    if (keys.length !== 1 || !['state', 'raw'].includes(keys[0])) throw new Error('恢复快照结构无效');
    if (keys[0] === 'state') validateLearningState(state.recovery.state, false);
    else text(state.recovery.raw, '恢复前原始数据', MAX_STATE_CHARS);
  }
  return state;
}

export function createBackup(state, now) {
  const copy = structuredClone(stripRecovery(state));
  copy.evidence ??= [];
  validateLearningState(copy);
  if (typeof now !== 'string' || !Number.isFinite(Date.parse(now)) || new Date(now).toISOString() !== now) throw new Error('exportedAt 无效');
  return { format: 'study-app', version: 1, exportedAt: now, state: copy };
}

export function parseBackup(input) {
  if (typeof input !== 'string') throw new Error('备份必须是字符串');
  if (input.length > MAX_BACKUP_CHARS || new TextEncoder().encode(input).byteLength > MAX_BACKUP_BYTES) throw new Error('备份文件超过大小上限');
  let data;
  try { data = JSON.parse(input); } catch { throw new Error('备份 JSON解析失败'); }
  plain(data, '备份内容');
  let state = data;
  if (['format', 'version', 'exportedAt', 'state'].some(key => Object.hasOwn(data, key))) {
    if (data.format !== 'study-app') throw new Error('备份 format 不支持');
    if (data.version !== 1) throw new Error('备份 version 不支持');
    if (!Object.hasOwn(data, 'state')) throw new Error('备份缺少state');
    if (typeof data.exportedAt !== 'string' || !Number.isFinite(Date.parse(data.exportedAt)) ||
      new Date(data.exportedAt).toISOString() !== data.exportedAt) throw new Error('exportedAt 无效');
    state = data.state;
  }
  validateLearningState(state);
  const copy = structuredClone(stripRecovery(state));
  copy.evidence ??= [];
  return copy;
}

export function serializeBackup(state, now) {
  const serialized = JSON.stringify(createBackup(state, now));
  if (serialized.length > MAX_BACKUP_CHARS || new TextEncoder().encode(serialized).byteLength > MAX_BACKUP_BYTES) {
    throw new Error('备份文件超过大小上限');
  }
  return serialized;
}

export function stateForRestore(current, incoming, rawCurrent = null) {
  const restored = structuredClone(stripRecovery(incoming));
  restored.evidence ??= [];
  validateLearningState(restored);
  restored.sources ??= [];
  if (current) {
    const previous = structuredClone(stripRecovery(current));
    validateLearningState(previous);
    restored.recovery = { state: previous };
  } else if (typeof rawCurrent === 'string') {
    restored.recovery = { raw: rawCurrent };
  }
  validateLearningState(restored);
  return restored;
}
