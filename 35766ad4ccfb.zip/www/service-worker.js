'use strict';

const CACHE_NAME = 'study-app-shell-20261104-15';
const CACHE_PREFIX = 'study-app-shell-';
const ASSETS = [
  './', './index.html', './app.js', './styles.css', './initial-state.js', './repository.js',
  './planner.js', './tasks.js', './calculus-course.js', './evidence.js', './review.js', './trial.js', './backup.js',
  './goals.js', './handoffs.js', './offline.js', './manifest.webmanifest', './icon.svg',
  './limits.js', './data-health.js', './drafts.js', './draft-controller.js', './correction-input.js', './corrections.js', './evidence-levels.js', './sources.js', './subjects.js'
];
const SCOPE = new URL(self.registration.scope);
const assetURLs = new Set(ASSETS.map(path => new URL(path, SCOPE).href));

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      cache.addAll(ASSETS.map((url) => new Request(new URL(url, SCOPE), { cache: 'reload' })))
    )
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  const isNavigation = request.mode === 'navigate';
  const isRootOrIndex = isNavigation && (url.href === SCOPE.href || url.pathname === new URL('index.html', SCOPE).pathname);

  if (isRootOrIndex) {
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) =>
        cache.match(new URL('index.html', SCOPE).href).then((cached) => cached || fetch(request))
      )
    );
    return;
  }

  url.search = '';
  if (assetURLs.has(url.href)) {
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) =>
        cache.match(url.href).then((cached) => cached || fetch(request))
      )
    );
  }
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'ACTIVATE_UPDATE') {
    self.skipWaiting();
  }
});
